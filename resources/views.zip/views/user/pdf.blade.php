<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tunjagan Kinerja</title>
    <link rel="stylesheet" href="{{ public_path('css') }}/bootstrap.min.css">

    <style>
        
    .hurufT {
        font-family: 'Times New Roman';
        font-size: 13px;
    }
    </style>
</head>
<body>

<div class="container-fluid">
    <center><h5>Laporan Detail Harian<h5></center>
    
        <table>
            <tbody>
                <tr>
                    <td colspan="3">Bukti Pembayaran Tunjangan Kinerja</td>
                    <td></td>
                    <td>Juli</td>
                    <td>2022</td>
                </tr>

                <tr>
                    <td colspan="2">Kode</td>
                    <td colspan="4">-</td>
                </tr>

                <tr>
                    <td colspan="2">Nama</td>
                    <td colspan="4">ADITYA CAHYA KURNIAWAN</td>
                </tr>

                <tr>
                    <td colspan="2">NIP</td>
                    <td colspan="4">19970223 202204 1 001</td>
                </tr>

                <tr>
                    <td colspan="2">Jabatan</td>
                    <td colspan="4">Calon Petugas Ukur</td>
                </tr>

                <tr>
                    <td colspan="2">Kelas Jabatan</td>
                    <td colspan="4">6</td>
                </tr>

                <tr>
                    <td colspan="2">Besar Tunjangan</td>
                    <td></td>
                    <td >2,161,600</td>
                </tr>
            </tbody>
        </table>
</div>

</body>
</html>