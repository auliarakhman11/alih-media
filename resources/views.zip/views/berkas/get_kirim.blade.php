<div class="row">

    <div class="col-6">
        <div class="form-group">
            <label for="">Proses</label>
            <p><b>{{ $proses }}</b></p>
        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <label for="">Proses</label>
            <p><b>{{ $proses }}</b></p>
        </div>
    </div>
    
    
</div>