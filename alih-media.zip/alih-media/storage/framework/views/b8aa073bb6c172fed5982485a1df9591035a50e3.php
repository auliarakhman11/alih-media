

<?php $__env->startSection('content'); ?>
    <!-- Content -->

<style>
    .th-atas {
	    position: -webkit-sticky; /* Safari */
        position: sticky;
        top:0;
        z-index: 9999;
		}

        .th-middle {
	    position: -webkit-sticky; /* Safari */
        position: sticky;
        top:40px;
        z-index: 9999;
		}

        div.scroll_horizontal {
            overflow-y: scroll;
            overflow-x: auto;
            white-space: nowrap;
            height:520px;
        }
  
</style>


<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
      <div class="col-lg-12 mb-4 order-0">
        <div class="card">
          <div class="d-flex align-items-end row">
            <div class="col-12">
              <div class="card-header">
                <div class="row">

                  <div class="col-md-6 col-12"><h4 class="text-primary">Data Penilaian</h4></div>

                  <div class="col-md-4 col-6">

                    <div class="navbar-nav align-items-center">
                      <div class="nav-item d-flex align-items-center">
                        <i class="bx bx-search fs-4 lh-0"></i>
                        <input
                          type="text"
                          class="form-control border-0 shadow-none"
                          placeholder="Search..."
                          aria-label="Search..."
                          id="search_penilaian"
                        />
                      </div>
                    </div>

                  </div>

                  <div class="col-md-2 col-6">
                    <a href="<?php echo e(route('exportDataPenilaian')); ?>" class="btn btn-sm btn-primary float-end"><i class='bx bxs-file-export'></i> Export</a>
                  </div>

                </div>
                
                
               
              </div>
              <div class="scroll_horizontal" id="dt_penilaian">
                
              </div>
                


            </div>

          </div>
        </div>
      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->
<form  class="form_skp">

  <div class="modal fade" id="modal_skp" style="z-index: 10001;" tabindex="-1" aria-labelledby="modal_skpLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal_skpLabel">Input SKP</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="pegawai_id" id="pegawai_id">
          <input type="hidden" name="seksi_id" id="seksi_id">
          <input type="hidden" name="skp_id" id="skp_id">
          <div class="form-group">
            <label for="">Nilai SKP</label>
            <input type="number" name="nilai" step=".01" class="form-control" id="nilai">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_save_skp">Save</button>
        </div>
      </div>
    </div>
  </div>

</form>

<form  class="form_skp">

  <div class="modal fade" id="modal_skp" style="z-index: 10001;" tabindex="-1" aria-labelledby="modal_skpLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal_skpLabel">Input SKP</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="pegawai_id" id="pegawai_id">
          <input type="hidden" name="seksi_id" id="seksi_id">
          <input type="hidden" name="skp_id" id="skp_id">
          <div class="form-group">
            <label for="">Nilai SKP</label>
            <input type="number" name="nilai" step=".01" class="form-control" id="nilai">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_save_skp">Save</button>
        </div>
      </div>
    </div>
  </div>

</form>

<form  id="form_edit">

  <div class="modal fade" id="modal_edit" style="z-index: 10001;" tabindex="-1" aria-labelledby="modal_editLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal_editLabel">Edit Nilai</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="data_edit">
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_edit_nilai">Edit</button>
        </div>
      </div>
    </div>
  </div>

</form>
  

  

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

          function getDataPenilaian(){
            $('#dt_penilaian').html('<div class="col-12">"<div class="spinner-border spinner-border-lg text-primary ml-5" role="status"><span class="visually-hidden">Loading...</span></div></div>');
            $.get('get-dt-penilaian', function (data) {
                      $('#dt_penilaian').html(data);
                      
                  });

                  $('#search_penilaian').val('');
          }

          getDataPenilaian();

          $(document).on('keyup', '#search_penilaian', function(){
            var value = $(this).val().toLowerCase();
            $("#tb_penilaian tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        $(document).on('click', '.btn_edit', function() {

        $('#data_edit').html('<div class="col-12">"<div class="spinner-border spinner-border-lg text-primary ml-5" role="status"><span class="visually-hidden">Loading...</span></div></div>');
        var pegawai_id = $(this).attr('pegawai_id');
        var nm_pegawai = $(this).attr('nm_pegawai');
        var jenis_penilai = $(this).attr('jenis_penilai');

        
        $('#modal_editLabel').html('Edit nilai '+ nm_pegawai);

        $.get('get-nilai/'+pegawai_id+'/'+jenis_penilai, function (data) {
                      $('#data_edit').html(data);
                  });


        });

          $(document).on('click', '.input_skp', function() {

            var pegawai_id = $(this).attr('pegawai_id');
            var nm_pegawai = $(this).attr('nm_pegawai');
            var seksi_id = $(this).attr('seksi_id');

            $('#pegawai_id').val(pegawai_id);
            $('#seksi_id').val(seksi_id);

            $('.form_skp').attr('id','form_input_skp');
            $('#modal_skpLabel').html('Input SKP '+ nm_pegawai);

          });

          $(document).on('click', '.edit_skp', function() {

          var pegawai_id = $(this).attr('pegawai_id');
          var nm_pegawai = $(this).attr('nm_pegawai');
          var seksi_id = $(this).attr('seksi_id');

          $('#pegawai_id').val(pegawai_id);
          $('#seksi_id').val(seksi_id);

          $('.form_skp').attr('id','form_edit_skp');
          $('#modal_skpLabel').html('Edit SKP '+ nm_pegawai);

          $.get('get-skp/'+pegawai_id, function (data) {
                      $('#nilai').val(data.nilai);
                      $('#skp_id').val(data.id);
                  });

          });

          $(document).on('submit', '#form_edit', function(event) {
                event.preventDefault();
                    $('#btn_edit_nilai').attr('disabled',true);
                    $('#btn_edit_nilai').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editPenilaian')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_edit_nilai").removeAttr("disabled");
                                $('#btn_edit_nilai').html('Edit'); //tombol simpan
                  
                                $('#modal_edit').modal('hide'); //modal show

                                getDataPenilaian();

                                $('#form_edit').trigger("reset");

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_edit_nilai').html('Edit');
                                $("#btn_edit_nilai").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_edit_nilai').html('Edit');
                                    $("#btn_edit_nilai").removeAttr("disabled");

                                    $('#modal_edit').modal('hide'); //modal show
                                }
                    });
          });


          $(document).on('submit', '#form_input_skp', function(event) {
                event.preventDefault();
                    $('#btn_save_skp').attr('disabled',true);
                    $('#btn_save_skp').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('inputSkp')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_save_skp").removeAttr("disabled");
                                $('#btn_save_skp').html('Edit'); //tombol simpan
                  
                                $('#modal_skp').modal('hide'); //modal show

                                getDataPenilaian();

                                $('#form_input_skp').trigger("reset");

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_save_skp').html('Edit');
                                $("#btn_save_skp").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_save_skp').html('Edit');
                                    $("#btn_save_skp").removeAttr("disabled");

                                    $('#modal_skp').modal('hide'); //modal show
                                }
                    });
          });



          $(document).on('submit', '#form_edit_skp', function(event) {
                event.preventDefault();
                    $('#btn_save_skp').attr('disabled',true);
                    $('#btn_save_skp').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editSkp')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_save_skp").removeAttr("disabled");
                                $('#btn_save_skp').html('Edit'); //tombol simpan
                  
                                $('#modal_skp').modal('hide'); //modal show

                                getDataPenilaian();

                                $('#form_edit_skp').trigger("reset");

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_save_skp').html('Edit');
                                $("#btn_save_skp").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_save_skp').html('Edit');
                                    $("#btn_save_skp").removeAttr("disabled");

                                    $('#modal_skp').modal('hide'); //modal show
                                }
                    });
          });


        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/administrator/index.blade.php ENDPATH**/ ?>