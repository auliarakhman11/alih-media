<table class="table table-sm">
    <thead>
        <tr>
            <th>#</th>
            <th>Barang</th>
            <th>Sisa Stok</th>
            <th>Expired Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dt_stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            if ($d->sisa_box == 0 && $d->sisa_pak == 0 && $d->sisa_kg == 0 ) {
                continue;
            }
        ?>
        <tr>
            <td><?php echo e($index+1); ?></td>
            <td><?php echo e($d->barang->nm_barang); ?></td>
            <td><?php echo e($d->sisa_box); ?> Box<br><?php echo e($d->sisa_pak); ?> Pak<br><?php echo e($d->sisa_kg); ?> Kg</td>
            <td><?php echo e(date("d/M/Y", strtotime($d->tgl_exp))); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table><?php /**PATH D:\programming\Laravel\aplikasilayout\resources\views/dashboard/detail_block.blade.php ENDPATH**/ ?>