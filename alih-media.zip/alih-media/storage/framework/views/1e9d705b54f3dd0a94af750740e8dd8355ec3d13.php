<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>
        
        .hurufT {
            font-family: 'Times New Roman';
            font-size: 13px;
        }
        
        table, td, th {
        border: 1px solid;
        }
    
        table {
        border-collapse: collapse;
        }
        </style>
</head>
<body>
    <div class="content">
        <center><h4><b>PENILAIAN KINERJA PEGAWAI PEMERINTAH NON PEGAWAI NEGERI <br> ASPEK PEMBELAJARAN</b></h4></center>
    <br>
    <table style="border: none;"">
        <tr>
            <td style="border: none;">Nama PPNPN</td>
            <td style="border: none;">: &nbsp;&nbsp; <?php echo e($dt_penilaian[0]->pegawai->nama); ?></td>
        </tr>
        <tr>
            <td style="border: none;">Jabatan</td>
            <td style="border: none;">: &nbsp;&nbsp; <?php echo e($dt_penilaian[0]->pegawai->jabatan); ?></td>
        </tr>
    </table>
    <br>

    <table width="100%">
        <thead>
            <tr>
                <th width="5%">NO</th>
                <th width="75%">PERTANYAAN</th>
                <th width="30%">NILAI</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i = 1;
                $tnilai = 0;
            ?>
            <?php for($count = 0; $count<count($dt_penilaian); $count++): ?>
            <tr>
                <td style="text-align:center;"><?php echo e($i++); ?></td>
                <td style="text-align: justify;"><?php echo e($dt_penilaian[$count]->pertanyaanAspek->pertanyaan); ?></td>
                <td style="text-align:center;"><b><?php echo e(($dt_penilaian[$count]->nilai + $dt_penilaian2[$count]->nilai)/2); ?></b></td>
            </tr>
            <?php
                $tnilai += ($dt_penilaian[$count]->nilai + $dt_penilaian2[$count]->nilai)/2;
            ?>
            <?php endfor; ?>
            
            <tr>
                <td style="text-align:center;"></td>
                <td style="text-align: center;"><b>Jumlah</b></td>
                <td style="text-align:center;"><b><?php echo e($tnilai); ?></b></td>
            </tr>
            
        </tbody>
    </table>

    <br>
    <br>

    <div class="ttd" style="float: right;">
        <table style="border: none; margin-right: 30px;">
            <tr>
                <td style="text-align: center; border: none;">Martapura, <?php echo e($tanggal); ?></td>
            </tr>
            <tr>
                <td style="text-align: center; border: none;"><?php echo e($perihal); ?></td>
            </tr>
            
            <?php if($dt_penilaian[0]->user->tanda_tangan): ?>
            <tr>
                <td style="border:none;"><center><img src="<?php echo e(public_path('tanda_tangan')); ?>/<?php echo e($dt_penilaian[0]->user->tanda_tangan); ?>" alt="" width="100px;"></center></td>
            </tr>
            <?php else: ?>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <?php endif; ?>

            <tr>
                <td style="text-align: center; border: none;"><?php echo e($dt_penilaian[0]->user->name); ?></td>
            </tr>
            <tr>
                <td style="text-align: center; border: none;"><?php echo e($dt_penilaian[0]->user->nip); ?></td>
            </tr>
            
        </table>
        
    </div>

    </div>
</body>
</html><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/administrator/pdfPembelajaran2.blade.php ENDPATH**/ ?>