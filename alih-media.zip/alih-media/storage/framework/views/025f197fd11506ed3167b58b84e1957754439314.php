<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0">Data Korsub & Kegiatan</h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">

            <div class="col-12">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="klasifikasi-tab" data-toggle="tab" href="#klasifikasi" role="tab" aria-controls="klasifikasi" aria-selected="true">Klasifikasi</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="korsub-tab" data-toggle="tab" href="#korsub" role="tab" aria-controls="korsub" aria-selected="false">Korsub</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="kegiatan-tab" data-toggle="tab" href="#kegiatan" role="tab" aria-controls="kegiatan" aria-selected="false">Kegiatan</a>
                    </li>
                  </ul>

                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="klasifikasi" role="tabpanel" aria-labelledby="klasifikasi-tab">
                        <div class="card">                  
                            <div class="card-header">
                                <h5 class="float-left">Data Klasifikasi</h5>
                                <button type="button" id="btn-add-klasifikasi" class="btn btn-sm btn-primary float-right" data-toggle="modal" data-target="#modal-add-klasifikasi">
                                    <i class="fas fa-plus-circle"></i> 
                                    Tambah Klasifikasi
                                  </button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm" id="table_klasifikasi" width="100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Klasifikasi</th>
                                                <th>Seksi</th>
                                                <th>Kode</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="korsub" role="tabpanel" aria-labelledby="korsub-tab">
                        <div class="card">                  
                            <div class="card-header">
                                <h5 class="float-left">Data Korsub</h5>
                                <button type="button" id="btn-add-korsub" class="btn btn-sm btn-primary float-right" data-toggle="modal" data-target="#modal-add-korsub">
                                    <i class="fas fa-plus-circle"></i> 
                                    Tambah Korsub
                                  </button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm" id="table_korsub" width="100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Korsub</th>
                                                <th>Klasifikasi</th>                 
                                                <th>Kode</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="kegiatan" role="tabpanel" aria-labelledby="kegiatan-tab">
                        <div class="card">

                              <div class="card-header">
                                  <h5 class="float-left">Data Kegiatan</h5>
                                  <button type="button" id="btn-add-kegiatan" class="btn btn-sm btn-primary float-right" data-toggle="modal" data-target="#modal-add-kegiatan">
                                      <i class="fas fa-plus-circle"></i> 
                                      Tambah Kegiatan
                                    </button>
                              </div>
                              <div class="card-body">
                                  <div class="table-responsive">
                                      <table class="table table-sm" id="table_kegiatan" width="100%">
                                          <thead>
                                              <tr>
                                                  <th>#</th>
                                                  <th>Klasifikasi</th>
                                                  <th>Korsub</th>             
                                                  <th>Kegiatan</th>
                                                  <th>Kode</th>
                                                  <th>Aksi</th>
                                              </tr>
                                          </thead>
                                          <tbody>
                                            
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                    </div>
                </div>

                
            </div>

        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <form id="form-add-klasifikasi">
    <div class="modal fade" id="modal-add-klasifikasi" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Tambah klasifikasi</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <label>Seksi</label>
                        <select name="seksi_id" class="form-control select2bs4" id="seksi_id" required>
                            <option value="" >-Pilih seksi-</option>
                            <?php $__currentLoopData = $seksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($o->id); ?>" ><?php echo e($o->nm_seksi); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Klasifikasi</label>
                            <input type="text" class="form-control" name="nm_klasifikasi" id="nm_klasifikasi" required>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Kode</label>
                            <input type="text" class="form-control" name="kode" id="kode_klasifikasi" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-input-klasifikasi">Tambah</button>
            </div>
        </div>
        </div>
    </div>
</form>

<form id="form-edit-klasifikasi">
    <div class="modal fade" id="modal-edit-klasifikasi" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Edit Klasifikasi</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <input type="hidden" name="id" id="id_klasifikasi">
                        <label>Seksi</label>
                        <select name="seksi_id" class="form-control select2bs4" id="seksi_id_e" required>
                            <option value="" >-Pilih seksi-</option>
                            <?php $__currentLoopData = $seksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($o->id); ?>" ><?php echo e($o->nm_seksi); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Klasifikasi</label>
                            <input type="text" class="form-control" name="nm_klasifikasi" id="nm_klasifikasi_e" required>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Kode</label>
                            <input type="text" class="form-control" name="kode" id="kode_klasifikasi_e" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-edit-klasifikasi">Edit</button>
            </div>
        </div>
        </div>
    </div>
</form>

  <!-- Modal -->
  <form id="form-add-korsub">
    <div class="modal fade" id="modal-add-korsub" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Korsub</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <label>Klasifikasi</label>
                        <select name="klasifikasi_id" class="form-control select2bs4" id="klasifikasi_id" required>
                            <option value="" >-Pilih Klasifikasi-</option>
                            <?php $__currentLoopData = $klasifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($o->id); ?>" >(<?php echo e($o->kode); ?>) <?php echo e($o->nm_klasifikasi); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Nama Korsub</label>
                            <input type="text" class="form-control" name="nm_korsub" id="nm_korsub" required>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Kode</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="klasifikasi_kode"></span>
                                </div>
                                <input type="text" class="form-control" name="kode" id="kode_korsub" required>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-input-korsub">Tambah</button>
            </div>
        </div>
        </div>
    </div>
    </form>

    <form id="form-edit-korsub">
        <div class="modal fade" id="modal-edit-korsub" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Edit Korsub</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <input type="hidden" name="id" id="id_korsub">
                        <div class="col-12">
                            <label>Klasifikasi</label>
                            <select name="klasifikasi_id" class="form-control select2bs4" id="klasifikasi_id_e" required>
                                <option value="" >-Pilih Klasifikasi-</option>
                                <?php $__currentLoopData = $klasifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($o->id); ?>" >(<?php echo e($o->kode); ?>) <?php echo e($o->nm_klasifikasi); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="">Nama Korsub</label>
                                <input type="text" class="form-control" name="nm_korsub" id="nm_korsub_e" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="">Kode</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="klasifikasi_kode_e"></span>
                                    </div>
                                    <input type="text" class="form-control" name="kode" id="kode_korsub_e" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="btn-edit-korsub">Edit</button>
                </div>
            </div>
            </div>
        </div>
        </form>

        <!-- Modal add kegiatan -->
  <form id="form-add-kegiatan">
    <div class="modal fade" id="modal-add-kegiatan" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Kegiatan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <label>Korsub</label>
                        <select name="korsub_id" class="form-control select2bs4" id="korsub_id" required>
                            <option value="" >-Pilih Korsub-</option>
                            <?php $__currentLoopData = $korsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($o->id); ?>" >(<?php echo e($o->klasifikasi->kode.'.'.$o->kode); ?>) <?php echo e($o->nm_korsub); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Nama kegiatan</label>
                            <input type="text" class="form-control" name="nm_kegiatan" id="nm_kegiatan" required>
                        </div>
                    </div>
                    <div class="col-12">
                        
                        <div class="form-group">
                            <label for="">Kode</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="korsub_kode"></span>
                                </div>
                                <input type="text" class="form-control" name="kode" id="kode_kegiatan" required>
                            </div>                            
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-input-kegiatan">Tambah</button>
            </div>
        </div>
        </div>
    </div>
    </form>

    <form id="form-edit-kegiatan">
        <div class="modal fade" id="modal-edit-kegiatan" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Edit Kegiatan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <input type="hidden" name="id" id="id_kegiatan">
                        <div class="col-12">
                            <label>Korsub</label>
                            <select name="korsub_id" class="form-control select2bs4" id="korsub_id_e" required>
                                <option value="" >-Pilih Korsub-</option>
                                <?php $__currentLoopData = $korsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($o->id); ?>" >(<?php echo e($o->klasifikasi->kode.'.'.$o->kode); ?>) <?php echo e($o->nm_korsub); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="">Nama kegiatan</label>
                                <input type="text" class="form-control" name="nm_kegiatan" id="nm_kegiatan_e" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="">Kode</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="korsub_kode_e"></span>
                                    </div>
                                    <input type="text" class="form-control" name="kode" id="kode_kegiatan_e" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="btn-edit-kegiatan">Edit</button>
                </div>
            </div>
            </div>
        </div>
        </form>

    

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {

    $('#table_klasifikasi').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataKlasifikasi')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    
                    {
                        data: 'nm_klasifikasi',
                        name: 'nm_klasifikasi'
                    },
                    {
                        data: 'seksi.nm_seksi',
                        name: 'seksi'
                    },
                    {
                        data: 'kode',
                        name: 'kode'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: [
                    [0, 'asc']
                ]
            });

            $(document).on('submit', '#form-add-klasifikasi', function(event) {
                event.preventDefault();
                    $('#btn-input-klasifikasi').attr('disabled',true);
                    $('#btn-input-klasifikasi').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addKlasifikasi')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            
                            if(data){
                                $('#nm_klasifikasi').val(""); //form reset
                                $('#kode_klasifikasi').val(""); //form reset
                                $('#modal-add-klasifikasi').modal('hide'); //modal hide
                                $("#btn-input-klasifikasi").removeAttr("disabled");
                                $('#btn-input-klasifikasi').html('Tambah'); //tombol simpan

                                var oTable = $('#table_klasifikasi').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable
                                
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Nama klasifikasi sudah ada'
                                });
                                $('#btn-input-klasifikasi').html('Tambah');
                                $("#btn-input-klasifikasi").removeAttr("disabled");
                            }
                                                        
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log(data);
                                    $('#btn-input-klasifikasi').html('Tambah');
                                    $("#btn-input-klasifikasi").removeAttr("disabled");
                                }
                    });

                });

                $(document).on('click', '.edit_klasifikasi', function() {
            var id = $(this).data('id');

            // console.log(id);
            
            $.get('get-klasifikasi/' + id, function (data) {
                //set value masing-masing id berdasarkan data yg diperoleh dari ajax get request diatas               
                $('#id_klasifikasi').val(data.id);
                $('#seksi_id_e').val(data.seksi_id);
                $('#seksi_id_e').select2({theme: 'bootstrap4', tags: true,}).trigger('change');
                $('#nm_klasifikasi_e').val(data.nm_klasifikasi);
                $('#kode_klasifikasi_e').val(data.kode);
                
            });
        });

        $(document).on('submit', '#form-edit-klasifikasi', function(event) {
        event.preventDefault();
            $('#btn-edit-klasifikasi').attr('disabled',true);
            $('#btn-edit-klasifikasi').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
            $.ajax({
                url:"<?php echo e(route('editKlasifikasi')); ?>",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                success: function(data) {
                    
                    $('#form-edit-klasifikasi').trigger("reset"); //form reset
                    $('#modal-edit-klasifikasi').modal('hide'); //modal hide
                    $("#btn-edit-klasifikasi").removeAttr("disabled");
                    $('#btn-edit-klasifikasi').html('Edit'); //tombol simpan

                    var oTable = $('#table_klasifikasi').dataTable(); //inialisasi datatable
                    oTable.fnDraw(false); //reset datatable

                    Swal.fire({
                      toast: true,
                      position: 'top-end',
                      showConfirmButton: false,
                      timer: 3000,
                      icon: 'success',
                      title: 'Data berhasil diedit'
                    });

                    
                },
                error: function (data) { //jika error tampilkan error pada console
                            alert('Error:', data);
                            $('#btn-edit-klasifikasi').html('Edit');
                            $("#btn-edit-klasifikasi").removeAttr("disabled");
                        }
            });

        });

//korsub
    $('#table_korsub').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataKorsub')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'klasifikasi.kode',
                        name: 'klasifikasi'
                    },
                    {
                        data: 'nm_korsub',
                        name: 'nm_korsub'
                    },                    
                    {
                        data: 'code',
                        name: 'code'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: [
                    [0, 'asc']
                ]
            });

            $(document).on('submit', '#form-add-korsub', function(event) {
                event.preventDefault();
                    $('#btn-input-korsub').attr('disabled',true);
                    $('#btn-input-korsub').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addKorsub')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            
                            if(data){
                                $('#nm_korsub').val(""); //form reset
                                $('#kode_korsub').val(""); //form reset
                                $('#modal-add-korsub').modal('hide'); //modal hide
                                $("#btn-input-korsub").removeAttr("disabled");
                                $('#btn-input-korsub').html('Tambah'); //tombol simpan

                                var oTable = $('#table_korsub').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable
                                
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Nama korsub sudah ada'
                                });
                                $('#btn-input-korsub').html('Tambah');
                                $("#btn-input-korsub").removeAttr("disabled");
                            }
                                                        
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log(data);
                                    $('#btn-input-korsub').html('Tambah');
                                    $("#btn-input-korsub").removeAttr("disabled");
                                }
                    });

                });

        $(document).on('click', '.edit_korsub', function() {
            var id = $(this).data('id');

            // console.log(id);
            
            $.get('get-korsub/' + id, function (data) {
                //set value masing-masing id berdasarkan data yg diperoleh dari ajax get request diatas               
                $('#id_korsub').val(data.id);
                $('#klasifikasi_id_e').val(data.klasifikasi_id);
                $('#klasifikasi_id_e').select2({theme: 'bootstrap4', tags: true,}).trigger('change');
                $('#nm_korsub_e').val(data.nm_korsub);
                $('#kode_korsub_e').val(data.kode);

                $('#klasifikasi_kode_e').text(data.klasifikasi.kode+'.');
                
            });
        });

        $(document).on('submit', '#form-edit-korsub', function(event) {
        event.preventDefault();
            $('#btn-edit-korsub').attr('disabled',true);
            $('#btn-edit-korsub').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
            $.ajax({
                url:"<?php echo e(route('editKorsub')); ?>",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                success: function(data) {
                    
                    $('#form-edit-korsub').trigger("reset"); //form reset
                    $('#modal-edit-korsub').modal('hide'); //modal hide
                    $("#btn-edit-korsub").removeAttr("disabled");
                    $('#btn-edit-korsub').html('Edit'); //tombol simpan

                    var oTable = $('#table_korsub').dataTable(); //inialisasi datatable
                    oTable.fnDraw(false); //reset datatable

                    Swal.fire({
                      toast: true,
                      position: 'top-end',
                      showConfirmButton: false,
                      timer: 3000,
                      icon: 'success',
                      title: 'Data berhasil diedit'
                    });

                    
                },
                error: function (data) { //jika error tampilkan error pada console
                            alert('Error:', data);
                            $('#btn-edit-korsub').html('Edit');
                            $("#btn-edit-korsub").removeAttr("disabled");
                        }
            });

        });

        $(document).on('change', '#klasifikasi_id', function() {
            var id = $(this).val();
            
            $.get('get-kode-klasifikasi/' + id, function (data) {
                $('#klasifikasi_kode').text(data);
            });
        });

        $(document).on('change', '#klasifikasi_id_e', function() {
            var id = $(this).val();
            
            $.get('get-kode-klasifikasi/' + id, function (data) {
                $('#klasifikasi_kode_e').text(data);
            });
        });

    //end korsub

    //kegiatan
    $('#table_kegiatan').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataKegiatan')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'korsub.klasifikasi.kode',
                        name: 'klasifikasi'
                    },  
                    {
                        data: 'korsub.nm_korsub',
                        name: 'nm_korsub'
                    },                                           
                    {
                        data: 'nm_kegiatan',
                        name: 'nm_kegiatan'
                    },
                    {
                        data: 'code',
                        name: 'code'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: [
                    [0, 'asc']
                ]
            });

            $(document).on('submit', '#form-add-kegiatan', function(event) {
                event.preventDefault();
                    $('#btn-input-kegiatan').attr('disabled',true);
                    $('#btn-input-kegiatan').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addKegiatan')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $('#nm_kegiatan').val(""); //form reset
                                $('#kode_kegiatan').val(""); //form reset
                                $('#modal-add-kegiatan').modal('hide'); //modal hide
                                $("#btn-input-kegiatan").removeAttr("disabled");
                                $('#btn-input-kegiatan').html('Tambah'); //tombol simpan

                                var oTable = $('#table_kegiatan').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Data kegiatan sudah ada'
                                });
                                $('#btn-input-kegiatan').html('Tambah');
                                $("#btn-input-kegiatan").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn-input-kegiatan').html('Tambah');
                                    $("#btn-input-kegiatan").removeAttr("disabled");
                                }
                    });

                });
        
        $(document).on('change', '#korsub_id', function() {
            var id = $(this).val();
            
            $.get('get-kode-korsub/' + id, function (data) {
                $('#korsub_kode').text(data);
            });
        });

        $(document).on('change', '#korsub_id_e', function() {
            var id = $(this).val();
            
            $.get('get-kode-korsub/' + id, function (data) {
                $('#korsub_kode_e').text(data);
            });
        });

        $(document).on('click', '.edit_kegiatan', function() {
            var id = $(this).data('id');
            
            $.get('get-kegiatan/' + id, function (data) {
                //set value masing-masing id berdasarkan data yg diperoleh dari ajax get request diatas               
                $('#id_kegiatan').val(data.id);
                // $('#kecamatan_id_e').val(data.kecamatan_id);

                $('#korsub_id_e').val(data.korsub_id);
                $('#korsub_id_e').select2({theme: 'bootstrap4', tags: true,}).trigger('change');
                
                $('#nm_kegiatan_e').val(data.nm_kegiatan);
                $('#kode_kegiatan_e').val(data.kode);

                $('#korsub_kode_e').text(data.korsub.klasifikasi.kode+'.'+data.korsub.kode+'.');
            });
        });

        $(document).on('submit', '#form-edit-kegiatan', function(event) {
        event.preventDefault();
            $('#btn-edit-kegiatan').attr('disabled',true);
            $('#btn-edit-kegiatan').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
            $.ajax({
                url:"<?php echo e(route('editKegiatan')); ?>",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                success: function(data) {
                    
                    $('#form-edit-kegiatan').trigger("reset"); //form reset
                    $('#modal-edit-kegiatan').modal('hide'); //modal hide
                    $("#btn-edit-kegiatan").removeAttr("disabled");
                    $('#btn-edit-kegiatan').html('Edit'); //tombol simpan

                    var oTable = $('#table_kegiatan').dataTable(); //inialisasi datatable
                    oTable.fnDraw(false); //reset datatable

                    Swal.fire({
                      toast: true,
                      position: 'top-end',
                      showConfirmButton: false,
                      timer: 3000,
                      icon: 'success',
                      title: 'Data berhasil diedit'
                    });

                    
                },
                error: function (data) { //jika error tampilkan error pada console
                            alert('Error:', data);
                            $('#btn-edit-kegiatan').html('Edit');
                            $("#btn-edit-kegiatan").removeAttr("disabled");
                        }
            });

        });
    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/korsub_kegiatan/index.blade.php ENDPATH**/ ?>