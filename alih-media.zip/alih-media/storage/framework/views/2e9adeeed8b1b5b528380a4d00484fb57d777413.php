<!DOCTYPE html>
<html lang="en">
<head>
	<title>Surat</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
<link rel="icon" type="image/png" href="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png"/>

<!-- Font Awesome -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>
<!-- Google Fonts -->
<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>
<!-- MDB -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.3.0/mdb.min.css"
  rel="stylesheet"
/>


</head>
<body>
	
	<section class="vh-100">
		<div class="container-fluid h-custom">
		  <div class="row d-flex justify-content-center align-items-center h-100">
			<div class="col-md-9 col-lg-6 col-xl-5">
			  <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp"
				class="img-fluid" alt="Sample image">
			</div>
			<div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
			  <form method="POST" id="form_login" action="<?php echo e(route('login')); ?>">
				<?php echo csrf_field(); ?>
				<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="alert alert-danger" role="alert">
							<?php echo e($message); ?>

						</div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					
					<?php if(session('success')): ?>
					<div class="alert alert-success" role="alert">
						<?php echo e(session('success')); ?>

					</div>
					<?php endif; ?>
				<div class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
				  <p class="lead fw-normal mb-0 me-3">Login Surat</p>
				  
				</div>
	  
				<div class="divider d-flex align-items-center my-4">
				  <p class="text-center fw-bold mx-3 mb-0"></p>
				</div>
	  
				<!-- Email input -->
				<div class="form-outline mb-4">
				  <input type="text" id="form3Example3" class="form-control form-control-lg"
					placeholder="Masukan Username" name="username" value="<?php echo e(old('username')); ?>" />
				  <label class="form-label" for="form3Example3">Username</label>
				</div>
	  
				<!-- Password input -->
				<div class="form-outline mb-3">
				  <input type="password" name="password" id="form3Example4" class="form-control form-control-lg"
					placeholder="Masukan Password" />
				  <label class="form-label" for="form3Example4">Password</label>
				</div>
	  
				
	  
				<div class="text-center text-lg-start mt-4 pt-2">
				  <button type="submit" class="btn btn-primary btn-lg" id="btn_login"
					>Login</button>
				  
				</div>
	  
			  </form>
			</div>
		  </div>
		</div>
		<div
		  class="d-flex flex-column flex-md-row text-center text-md-start justify-content-between py-4 px-4 px-xl-5 bg-primary">
		  <!-- Copyright -->
		  <div class="text-white mb-3 mb-md-0"> 
			Copyright © 2022. Kantor Pertanahan Kabupaten Banjar All rights reserved.
		  </div>
		  <!-- Copyright -->
	  
		  <!-- Right -->
		  
		  <!-- Right -->
		</div>
	  </section>
	
	

	
<!--===============================================================================================-->	
	<script src="<?php echo e(asset('auth')); ?>/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	
<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.3.0/mdb.min.js"
></script>

	<script>
		$(document).ready(function() {

			$(document).on('submit', '#form_login', function(event) {
                    $('#btn_login').attr('disabled',true);
                                       

                });

		});
	</script>

</body>
</html><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/auth/login.blade.php ENDPATH**/ ?>