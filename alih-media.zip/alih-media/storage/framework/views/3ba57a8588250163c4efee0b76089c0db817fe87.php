

<?php $__env->startSection('content'); ?>


<!-- Content -->



<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">

    <div class="col-12 mb-4 order-0">
      
      <div class="card">
          <div class="card-header">
              <h5 class="float-start">Input Stok keluar</h5>

              <button type="button" class="btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#modal_cari_barang"><i class='bx bx-search-alt'></i> Cari Barang</button>
              
          </div>
          
          <div class="card-body">

            

          </div>
          
        </div>

        <div class="card">
          <div class="card-header">
              <h5 class="float-start">Batch Stok Masuk</h5>
              
          </div>
          <div class="card-body" id="cart">

          </div>
          <div class="card-footer">
            <button type="button" id="btn_input_data" class="btn btn-sm btn-primary float-end"><i class="bx bxs-save"></i> Input Stok</button>
          </div>
        </div>


    </div>

    <!-- Total Revenue -->

    <!--/ Total Revenue -->
    
  </div>

</div>
<!-- / Content -->

    

  <!-- Modal -->


<form id="form_input_penilaian">
  <div class="modal fade" id="modal_cari_barang" tabindex="-1" aria-labelledby="modal_cari_barangLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal_cari_barangLabel">Cari Barang</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          
            <div class="row">
                <div class="col-12 col-md-4">
                    <div class="form-group">
                        <select name="barang_id" class="form-control" id="select_barang" required>
                          <option value="">Pilih Barang</option>
                          <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($b->id); ?>"><?php echo e($b->nm_barang); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                </div>
            </div>

            <div id="table_barang"></div>
          
  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_simpan_penilaian">Simpan</button>
        </div>
      </div>
    </div>
  </div>
</form>





  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

            <?php if(session('success')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: '<?= session('success'); ?>'
            });            
            <?php endif; ?>

            <?php if(session('error')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: '<?= session('error'); ?>'
            });            
            <?php endif; ?>

            $(document).on('change', '.terima', function() {
                if ($(this).is(':checked')) {

                  var checker_id = $(this).attr("checker_id");
                    
                    $(".input_barang_"+checker_id).removeAttr("disabled");
                    

                } else {
                  
                  var checker_id = $(this).attr("checker_id");
                  $(".input_barang_"+checker_id).attr('disabled',true);

                }
              

            });

            function getCart() {
              $.get('get-cart-masuk', function (data) {        
                  $('#cart').html(data);
                });
            }

            getCart();

            $(document).on('change', '#select_barang', function() {
              var barang_id = $(this).val();
              
              $.get('get-detail-barang/'+barang_id, function (data) {        
                  $('#table_barang').html(data);
                });

            });

            $(document).on('change', '#cell', function() {
              var cell_id = $(this).val();
              $('#rak').html('');
              $.get('get-rak/'+cell_id, function (data) {        
                  $('#rak').html(data);
                });

            });

            $(document).on('click', '.btn_hapus_cart', function() {
              var id = $(this).attr('cart_id');

              $.get('delete-cart-masuk/'+id, function (data) {        
                  getCart();
                });

            });

            $(document).on('click', '#btn_input_data', function() {

              $.get('save-stok-masuk', function (data) {        
                  getCart();

                  Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Stok Masuk Berhasil Diinput'
                                });

                });

            });

            

            

            $(document).on('submit', '#form_input_stok_masuk', function(event) {
                event.preventDefault();

                    $('#btn_add_cart').attr('disabled',true);
                    $('#btn_add_cart').html('Loading..');

                    
                    $.ajax({
                        url:"<?php echo e(route('addCartMasuk')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            
                            
                            $('#btn_add_cart').html('<i class="bx bxs-right-arrow-circle"></i> Lanjut'); //tombol
                            getCart();
 
                            
                            $('.select2bs4').val('');
                            $('.select2bs4').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                            $("#qty_box").val('');
                            $("#qty_pak").val('');
                            $("#qty_kg").val('');

                            $("#block").val('');

                            $("#cell").html('<option value="">Pilih Cell</option>');
                            $("#rak").html('<option value="">Pilih Rak</option>');

                            Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data Berhasil Diinput'
                                });
                                                        
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    alert('Error:', data);
                                    $("#btn_add_cart").removeAttr("disabled");
                            $('#btn_add_cart').html('<i class="bx bxs-right-arrow-circle"></i> Lanjut'); //tombol
                                }
                    });

                });


        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\warehouse\resources\views/stok_keluar/input_stok_keluar.blade.php ENDPATH**/ ?>