  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/" class="brand-link">
      <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp" alt="AdminLTE Logo" class="brand-image elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">ATR-BPN</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          

          <li class="nav-item <?php echo e(Request::is(['surat-tugas']) ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is(['surat-tugas']) ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-envelope-open-text"></i>
              <p>
                Surat Tugas
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo e(route('suratTugas')); ?>" class="nav-link <?php echo e(Request::is('surat-tugas') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Data Surat tugas</p>
                </a>
              </li>
              
            </ul>
          </li>

          
          
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH /media/rahman/DATA D1/Programming/laravel/surat-keuar/resources/views/template/_sidebar_st.blade.php ENDPATH**/ ?>