<style>
    .tabbable .nav-tabs {
      overflow-x: auto;
      overflow-y:hidden;
      flex-wrap: nowrap;
    }
    .tabbable .nav-tabs .nav-link {
      white-space: nowrap;
    }
  </style>

<div class="container-fluid">
    <nav class="tabbable">
      <div class="nav nav-tabs" id="nav-tab" role="tablist">
          <?php $__currentLoopData = $dt_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a class="nav-item nav-link detail_tukin <?php echo e($p->pegawai_id == $id_pegawai ? 'active' : ''); ?>" data-toggle="tab" href="javascript:void(0)" data-id="<?php echo e($id); ?>" id_pegawai = "<?php echo e($p->pegawai_id); ?>" role="tab" aria-controls="nav-home" aria-selected="true"><?php echo e($p->pegawai->nama); ?></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
      </div>
    </nav>
    
  </div>
  <div id="table_detail_tukin" class="scroll">
      <table class="table table-sm">
    <input type="hidden" name="id" value="<?php echo e($id); ?>">
    <input type="hidden" name="id_pegawai" value="<?php echo e($id_pegawai); ?>">
    <input type="hidden" name="tunjangan" value="<?php echo e($tunjangan); ?>">
          <thead>
              <tr>
                  <th class="sticky-top th-atas">Tanggal</th>
                  <th class="sticky-top th-atas">Jam Masuk</th>
                  <th class="sticky-top th-atas">Jam Keluar</th>
                  <th class="sticky-top th-atas">Scan Masuk</th>
                  <th class="sticky-top th-atas">Scan Keluar</th>
                  <th class="sticky-top th-atas">Keterangan</th>
              </tr>
          </thead>
          <tbody>
              <?php for($i=1; $i <= $last_day; $i++): ?>
            <?php
                $tanggal = date("Y-m-d", strtotime($bulan_tahun.$i));
            ?>
              <?php if(date('N', strtotime($tanggal)) >= 6): ?>
                      <tr>
                        <td><?php echo e(date("d/M/Y", strtotime($tanggal))); ?></td>
                        <td>08:30</td>
                        <td>16:30</td>
                        <?php if(date('N', strtotime($tanggal)) == 6): ?>
                        <td><center>SABTU</center></td>
                        <td><center>SABTU</center></td>
                        <?php else: ?>
                        <td><center>MINGGU</center></td>
                        <td><center>MINGGU</center></td>
                        <?php endif; ?>
                        <td></td>
                      </tr>                  
              <?php else: ?>
                  <?php $__currentLoopData = $dt_absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($da->tgl == $tanggal): ?>
                    <?php if($da->luar_kota): ?>
                    <tr>
                        <td><?php echo e(date("d/M/Y", strtotime($tanggal))); ?></td>
                        <td><?php echo e(date('H:i', strtotime($da->jam_masuk))); ?></td>
                        <td><?php echo e(date('H:i', strtotime($da->jam_pulang))); ?></td>
                        <td>DINAS</td>
                        <td>LUAR</td>
                        <td></td>
                      </tr>
                    <?php else: ?>
                    
                    <input type="hidden" name="detail_id[]" value="<?php echo e($da->id); ?>">
                    <input type="hidden" name="tgl[]" value="<?php echo e($da->tgl); ?>">
                    <input type="hidden" name="jam_masuk[]" value="<?php echo e($da->jam_masuk); ?>">
                    <input type="hidden" name="jam_pulang[]" value="<?php echo e($da->jam_pulang); ?>">
                    <tr>
                        <td><?php echo e(date("d/M/Y", strtotime($tanggal))); ?></td>
                        <td><?php echo e(date('H:i', strtotime($da->jam_masuk))); ?></td>
                        <td><?php echo e(date('H:i', strtotime($da->jam_pulang))); ?></td>
                        <td><input type="time" name="scan_masuk[]" class="form-control form-control-sm <?php echo e((!$da->scan_masuk || $da->scan_masuk > $da->jam_masuk) && (!$da->ket && !$da->luar_kota) ? 'is-invalid' : ''); ?>" value="<?php echo e($da->scan_masuk); ?>"></td>
                        <td><input type="time" name="scan_pulang[]" class="form-control form-control-sm <?php echo e((!$da->scan_pulang || $da->scan_pulang < $da->jam_pulang) && (!$da->ket && !$da->luar_kota) ? 'is-invalid' : ''); ?>" value="<?php echo e($da->scan_pulang); ?>"></td>
                        <td><input type="text" name="ket[]" class="form-control form-control-sm" value="<?php echo e($da->ket); ?>"></td>
                      </tr>
                    <?php endif; ?>
                           
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
                  
              <?php endfor; ?>
          </tbody>
      </table>
  </div>
<?php /**PATH /media/rahman/DATA D1/Programming/laravel/surat-keuar/resources/views/tukin/detail.blade.php ENDPATH**/ ?>