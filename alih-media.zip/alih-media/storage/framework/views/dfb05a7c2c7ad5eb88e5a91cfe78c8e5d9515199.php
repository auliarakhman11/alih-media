<?php if(empty($dtBarang)): ?>
    <h5>Stok kosong!!</h5>
<?php else: ?>
<div class="scrollme">
  <table class="table table-sm" width="100%">
    <thead>
      <tr>
          <th>#</th>
          <th>Barang</th>
          <th>Tanggal Exprired</th>
          <th>QTY</th>
          <th>Lokasi</th>
          <th>Pilih</th>
      </tr>
    </thead>
    <tbody class="table-border-bottom-0">
      <?php $__currentLoopData = $dtBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($index+1); ?></td>
      <td><?php echo e($d->barang->nm_barang); ?></td>
        <td><?php echo e(date("d/M/Y", strtotime($d->tgl_exp))); ?></td>
        <td  width="30%">
            <div class="input-group">
                <input type="number" class="form-control form-control-sm input_barang_<?php echo e($d->id); ?>" name="kredit_box[]" value="<?php echo e($d->sisa_box); ?>" max="<?php echo e($d->sisa_box); ?>" disabled>
                <span class="input-group-text" style="font-size: 10px;">Box</span>
            </div>
            <div class="input-group">
                <input type="number" class="form-control form-control-sm input_barang_<?php echo e($d->id); ?>" name="kredit_pak[]" value="<?php echo e($d->sisa_pak); ?>" max="<?php echo e($d->sisa_pak); ?>" disabled>
                <span class="input-group-text" style="font-size: 10px;">Pack</span>
            </div>
            <div class="input-group">
                <input type="number" class="form-control form-control-sm input_barang_<?php echo e($d->id); ?>" name="kredit_kg[]" value="<?php echo e($d->sisa_kg); ?>" max="<?php echo e($d->sisa_kg); ?>" disabled>
                <span class="input-group-text" style="font-size: 10px;">KG</span>
            </div>
            
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="barang_id[]" value="<?php echo e($d->barang_id); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="block_id[]" value="<?php echo e($d->block_id); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="cell_id[]" value="<?php echo e($d->cell_id); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="rak_id[]" value="<?php echo e($d->rak_id); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="pallet_id[]" value="<?php echo e($d->pallet_id); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="barang[]" value="<?php echo e($d->barang->nm_barang); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="block[]" value="<?php echo e($d->block->nm_block); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="cell[]" value="<?php echo e($d->cell->nm_cell); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="rak[]" value="<?php echo e($d->rak->nm_rak); ?>" disabled>
            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="pallet[]" value="<?php echo e($d->pallet->nm_pallet); ?>" disabled>

            <input type="hidden" class="input_barang_<?php echo e($d->id); ?>" name="tgl_exp[]" value="<?php echo e($d->tgl_exp); ?>" disabled>
            
        </td>              
        <td><?php echo e($d->block->nm_block); ?><br><?php echo e($d->cell->nm_cell); ?><br><?php echo e($d->rak->nm_rak); ?><br><?php echo e($d->pallet->nm_pallet); ?></td>

        <td>
            <div class="form-check form-switch mb-2">
                <input class="form-check-input terima" checker_id="<?php echo e($d->id); ?>" value="<?php echo e($d->id); ?>" type="checkbox">
              </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php endif; ?><?php /**PATH D:\programming\Laravel\aplikasilayout\resources\views/stok_keluar/pilih_barang.blade.php ENDPATH**/ ?>