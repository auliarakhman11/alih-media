  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/" class="brand-link">
      <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp" alt="AdminLTE Logo" class="brand-image elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">ATR-BPN</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          
         
          
          <?php if(Auth::user()->seksi_id == 1): ?>
          <li class="nav-item <?php echo e(Request::is(['tunjangan-kinerja']) ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is(['tunjangan-kinerja']) ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>
                Absensi & Tunjangan
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo e(route('tukin')); ?>" class="nav-link <?php echo e(Request::is('tunjangan-kinerja') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Absensi & Tunjangan</p>
                </a>
              </li>
              
            </ul>
          </li>

          <li class="nav-item <?php echo e(Request::is(['user','korsub-kegiatan','jenis-surat','pegawai']) ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is(['user','korsub-kegiatan','jenis-surat','pegawai']) ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-database"></i>
              <p>
                Data
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo e(route('korsubKegiatan')); ?>" class="nav-link <?php echo e(Request::is('korsub-kegiatan') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Korsub & Kegiatan</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('jenisSurat')); ?>" class="nav-link <?php echo e(Request::is('jenis-surat') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Jenis Surat</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('pegawai')); ?>" class="nav-link <?php echo e(Request::is('pegawai') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Pegawai</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('user')); ?>" class="nav-link <?php echo e(Request::is('user') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>User</p>
                </a>
              </li>
              
            </ul>
          </li>
          <?php endif; ?>

          

          

          
          
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>