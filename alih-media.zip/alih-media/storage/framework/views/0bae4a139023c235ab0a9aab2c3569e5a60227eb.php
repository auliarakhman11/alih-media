<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">

            <div class="col-8">
                <div class="card">
                  
                    <div class="card-header">
                        <h4 class="float-left">Data Surat Kosong</h4>
                        
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm" id="table_surat_kosong" width="100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Tanggal</th>
                                        <th>Urutan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <form id="form-edit-surat-kosong">
    <div class="modal fade" id="modal-edit-surat-kosong" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Edit surat Surat</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div id="message_error" style="display:none"></div>
                <div class="row">
                    
                    <input type="hidden" name="id" id="id_surat">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Korsub</label>
                            <select class="form-control select2bs4" name="korsub_id" id="korsub_id" required>
                                <option value="">Pilih korsub..</option>      
                                <?php $__currentLoopData = $korsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->klasifikasi->kode); ?>.<?php echo e($d->kode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                            </select>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Kegiatan</label>
                            <select class="form-control select2bs4" name="kegiatan_id" id="kegiatan_id" required>
                                <option value="">Pilih kegiatan..</option>                         
                            </select>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Tujuan</label>
                            <input type="text" class="form-control" name="tujuan" required>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Perihal</label>
                            <input type="text" class="form-control" name="perihal" required>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Keterangan</label>
                            <input type="text" class="form-control" name="keterangan" >
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Jenis Surat</label>
                            <select class="form-control select2bs4" name="jenis_surat" id="jenis_surat" required>
                                <option value="">Pilih jenis surat..</option>
                                <?php $__currentLoopData = $jenis_surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->nm_jenis); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </select>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group">
                            <label for="">File PDF</label>
                            <input type="file" class="form-control" name="file_name" id="file_pdf">
                        </div>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-edit-surat-kosong">Edit</button>
            </div>
        </div>
        </div>
    </div>
    </form>

    <div class="modal fade" id="modal_no_surat" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <h5>Nomor surat : <b id="generate_no_surat"></b></h5>
              <h5 id="file_kosong" class="text-warning"></h5>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="modal_file_pdf" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Scan Surat</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body" id="display_file_pdf">
           
                
                
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {

    $(document).on('change', '#file_pdf', function() {

        $('#message_error').hide();

      const [file] = file_pdf.files
      if (file) {
        var url = URL.createObjectURL(file)
      }else{
        var url = '';
      }
            var pdf = '<object data="'+url+'" type="application/pdf" width="780" height="500"></object>';
            $("#display_file_pdf").html(pdf);

            $('#modal_file_pdf').modal('show'); //modal show

            $('#message_error_pdf').hide();
            
    });
    
    $('#table_surat_kosong').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getListSuratKosong')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'tgl',
                        name: 'tgl'
                    }, 
                    {
                        data: 'urutan',
                        name: 'urutan'
                    },  
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: [
                    [0, 'asc']
                ]
            });

            $(document).on('change', '#korsub_id', function() {
                    var id = $(this).val();
                    
                    $.get('get-list-kegiatan/' + id, function (data) {
                        $('#kegiatan_id').html(data);
                    });
            });

            $(document).on('submit', '#form-edit-surat-kosong', function(event) {
                event.preventDefault();
                    $('#btn-edit-surat-kosong').attr('disabled',true);
                    $('#btn-edit-surat-kosong').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editSuratKosong')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data.status == 'success'){
                                $("#btn-edit-surat-kosong").removeAttr("disabled");
                                $('#btn-edit-surat-kosong').html('Edit'); //tombol simpan

                                $('#modal-edit-surat-kosong').modal('hide'); //modal hide

                                $('#form_surat').trigger("reset");
                                $('#kegiatan_id').html('<option value="">Pilih Kegiatan..</option>');
                                $('.select2bs4').val('');
                                $('.select2bs4').select2({theme: 'bootstrap4', tags: true,}).trigger('change');
                                
                                $('#generate_no_surat').html(data.dt_surat.no_surat);

                                if(!data.dt_surat.file_name){
                                    $('#file_kosong').html("File PDF belum diupload, Harap upload PDF sebelum 3 hari !!");
                                }else{
                                    $('#file_kosong').html("");
                                }

                                $('#modal_no_surat').modal('show'); //modal show

                                var oTable = $('#table_surat_kosong').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn-edit-surat-kosong').html('Edit');
                                $("#btn-edit-surat-kosong").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);

                                    var dt_error = '<div class="alert alert-danger">';
                                    jQuery.each(data.responseJSON.errors, function(key, message){
                                        
                                    dt_error += '<p>'+message+'</p>';
                                    // $('.alert-danger').append('<p>'+message+'</p>');
                                    });
                                    dt_error += '</div>';
                                    $('#message_error').html(dt_error);
                                    $('#message_error').show();

                                    $('#btn-edit-surat-kosong').html('Edit');
                                    $("#btn-edit-surat-kosong").removeAttr("disabled");
                                }
                    });

            });

            $(document).on('click', '.edit_surat', function() {
                var id = $(this).data('id');

                // console.log(id);
                
                $.get('get-surat/' + id, function (data) {
                    //set value masing-masing id berdasarkan data yg diperoleh dari ajax get request diatas
                    

                    $('#id_surat').val(data.dt_surat.id);

                   
                    
                    
                });
            });
    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master_sk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rahman/DATA D1/Programming/laravel/surat-keuar/resources/views/surat/surat_kosong.blade.php ENDPATH**/ ?>