<table class="table table-bordered table-striped">
    <thead class="text-center">
      <tr>
        <th rowspan="2" class="th-atas" style="background-color: white; white-space: nowrap;position: sticky; left: 0; z-index: 10000;">Pegawai</th>
        <th colspan="3" class="th-atas" style="background-color: white;">Penilaian</th>
        <th rowspan="2" class="th-atas" style="background-color: white;">Input Terbaik</th>
        <th rowspan="2" class="th-atas" style="background-color: white;">Input Terburuk</th>
        <th rowspan="2" class="th-atas" style="background-color: white;">SKP</th>
        <th rowspan="2" class="th-atas" style="background-color: white;">Cetak</th>
      </tr>
      <tr>
          <th class="th-middle" style="background-color: white;">Atasan</th>
          <th class="th-middle" style="background-color: white;">Rekan Kerja<br>1 (Korsub)</th>
          <th class="th-middle" style="background-color: white;">Rekan Kerja<br>2 (PPNPN)</th>
      </tr>
    </thead>
    <tbody id="tb_penilaian">
      <?php $__currentLoopData = $dt_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td style="white-space: nowrap;position: sticky; left: 0; z-index: 9998; background-color: white;"><?php echo e($dp->nama); ?></td>
          <td class="text-center">
              <?php if($dp->jml_penilai1 > 0): ?>                       

              <button
                  type="button"
                  class="btn btn-xs rounded btn-info btn_edit"
                  data-bs-toggle="modal" data-bs-target="#modal_edit" pegawai_id="<?php echo e($dp->id); ?>" nm_pegawai="<?php echo e($dp->nama); ?>" jenis_penilai="1"
              >
              <i class='bx bxs-badge-check'></i>
              </button>

              <?php else: ?>
              

              <button
                  style="border: none;"
                  type="button"
                  data-bs-toggle="tooltip"
                  data-bs-offset="0,4"
                  data-bs-placement="top"
                  data-bs-html="true"
                  title="<?php echo e($dp->kasi->name); ?>"
              >
              <i class='text-danger bx bxs-x-circle'></i>
              </button>
              <?php endif; ?>
          </td>
          <td class="text-center">
              <?php if($dp->jml_penilai2 > 0): ?>
              <button
                  type="button"
                  class="btn btn-xs rounded btn-info btn_edit"
                  data-bs-toggle="modal" data-bs-target="#modal_edit" pegawai_id="<?php echo e($dp->id); ?>" nm_pegawai="<?php echo e($dp->nama); ?>" jenis_penilai="2"
              >
              <i class='bx bxs-badge-check'></i>
              </button>
              <?php else: ?>
              <button
                  style="border: none;"
                  type="button"
                  data-bs-toggle="tooltip"
                  data-bs-offset="0,4"
                  data-bs-placement="top"
                  data-bs-html="true"
                  title="<?php echo e($dp->korsub->name); ?>"
              >
              <i class='text-danger bx bxs-x-circle'></i>
              </button>
              <?php endif; ?>
          </td>
          <td class="text-center">
              <?php if($dp->jml_penilai3 > 0): ?>
              <button
                  type="button"
                  class="btn btn-xs rounded btn-info btn_edit"
                  data-bs-toggle="modal" data-bs-target="#modal_edit" pegawai_id="<?php echo e($dp->id); ?>" nm_pegawai="<?php echo e($dp->nama); ?>" jenis_penilai="3"
              >
              <i class='bx bxs-badge-check'></i>
              </button>
              <?php else: ?>
              <i class='text-danger bx bxs-x-circle'></i>
              <?php endif; ?>
          </td>
          <td class="text-center">
              <?php if($dp->jml_baik > 0): ?>
              <i class='text-info bx bxs-badge-check'></i>
              <?php else: ?>
              <i class='text-danger bx bxs-x-circle'></i>
              <?php endif; ?>
          </td>
          <td class="text-center">
              <?php if($dp->jml_buruk > 0): ?>
              <i class='text-info bx bxs-badge-check'></i>
              <?php else: ?>
              <i class='text-danger bx bxs-x-circle'></i>
              <?php endif; ?>
          </td>
          <td>
            <?php if($dp->n_skp > 0): ?>
            <button type="button" class="btn btn-sm btn-success edit_skp" data-bs-toggle="modal" data-bs-target="#modal_skp" pegawai_id="<?php echo e($dp->id); ?>" nm_pegawai="<?php echo e($dp->nama); ?>" seksi_id="<?php echo e($dp->seksi_id); ?>" ><i class='bx bxs-file-find'></i></button>
            <?php else: ?>
            <button type="button" class="btn btn-sm btn-primary input_skp" data-bs-toggle="modal" data-bs-target="#modal_skp" pegawai_id="<?php echo e($dp->id); ?>" nm_pegawai="<?php echo e($dp->nama); ?>" seksi_id="<?php echo e($dp->seksi_id); ?>"><i class='bx bx-plus-medical'></i></button>
            <?php endif; ?>
            
          </td>
          <td>
            <?php if($dp->jml_penilai1 > 0 && $dp->jml_penilai2 > 0 && $dp->jml_penilai3 > 0 && $dp->jml_penilai3 > 0  && $dp->n_skp > 0): ?>
            <a target="_blank" href="/pdf-pembelajaran/<?php echo e($dp->id); ?>" class="btn btn-sm btn-primary"><i class='bx bxs-printer'></i></a>  
            
            <?php endif; ?>
            
            
          </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
    </tbody>
  </table><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/administrator/dt_penilaian.blade.php ENDPATH**/ ?>