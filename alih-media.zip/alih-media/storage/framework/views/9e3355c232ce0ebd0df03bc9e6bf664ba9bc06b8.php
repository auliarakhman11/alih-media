<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <div class="app-brand demo">
    <a href="" class="app-brand-link">
      <span class="app-brand-logo demo">
        <img src="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png" alt="" width="30"
        viewBox="0 0 25 42"
        version="1.1">

        
          
      </span>
      <span class="app-brand-text demo menu-text fw-bolder ms-2">KANTAH BANJAR</span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
      <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    


  

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text"><i class='bx bxs-user-pin'></i> <?php echo e(Auth::user()->name); ?></span>
    </li>
    <li class="menu-item <?php echo e(Request::is(['/','penilaian-pegawai']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bx-dock-top"></i>
        <div data-i18n="Penilaian">Penilaian</div>
      </a>
      <ul class="menu-sub">

        <?php if(in_array(Auth::user()->role_id, [1,2,3])): ?>
        <li class="menu-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('penilaian')); ?>" class="menu-link">
            <div data-i18n="Input Penilaian">Input Penilaian</div>
          </a>
        </li>
        <?php endif; ?>
        
        <?php if(Auth::user()->role_id == 4): ?>
        <li class="menu-item <?php echo e(Request::is('penilaian-pegawai') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('penilaianPegawai')); ?>" class="menu-link">
            <div data-i18n="Input Penilaian">Input Penilaian</div>
          </a>
        </li>
        <?php endif; ?>

        
        
        
      </ul>
    </li>

    <?php if(Auth::user()->role_id == 1): ?>
    <li class="menu-item <?php echo e(Request::is(['data-penilaian','baik-buruk','pegawai','user']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-user-detail"></i>
        <div data-i18n="Administrator">Administrator</div>
      </a>
      <ul class="menu-sub">


        <li class="menu-item <?php echo e(Request::is('data-penilaian') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('dataPenilaian')); ?>" class="menu-link">
            <div data-i18n="Data penilaian">Data penilaian</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('baik-buruk') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('baikBuruk')); ?>" class="menu-link">
            <div data-i18n="PPNPN Terbaik dan Terburuk">PPNPN Terbaik<br>dan Terburuk</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('pegawai') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('pegawai')); ?>" class="menu-link">
            <div data-i18n="Data PPNPN">Data PPNPN</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('user') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('user')); ?>" class="menu-link">
            <div data-i18n="Data User">Data User</div>
          </a>
        </li>
        
        
        
      </ul>
    </li>
    <?php endif; ?>


    <li class="menu-item">
      <a href="<?php echo e(route('gantiPassword')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bxs-lock-alt'></i>
        <div data-i18n="Analytics">Ganti Password</div>
      </a>
    </li>

    <li class="menu-item">
      <a href="<?php echo e(route('logout')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-log-out-circle'></i>
        <div data-i18n="Analytics">Logout</div>
      </a>
    </li>

    




  </ul>
</aside><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>