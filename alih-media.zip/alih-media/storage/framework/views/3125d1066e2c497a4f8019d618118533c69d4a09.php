  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-dark">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      

      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle text-light" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user text-light"></i> <?php echo e(Auth::user()->name); ?>

        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" href="<?php echo e(route('gantiPassword')); ?>">Ganti Password</a>
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
        </div>
      </div>
      
      
      
    </ul>
  </nav>
  <!-- /.navbar --><?php /**PATH /media/rahman/DATA D1/Programming/laravel/arsip/resources/views/template/_navbar.blade.php ENDPATH**/ ?>