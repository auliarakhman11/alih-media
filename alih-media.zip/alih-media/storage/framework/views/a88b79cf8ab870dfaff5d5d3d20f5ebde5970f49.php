<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">

            <div class="col-8">
                <div class="card">
                  
                    <div class="card-header">
                        <h4 class="float-left">Data Jenis Surat</h4>
                        <button type="button" id="btn-add-jenis-surat" class="btn btn-sm btn-primary float-right" data-toggle="modal" data-target="#modal-add-jenis">
                            <i class="fas fa-plus-circle"></i> 
                            Tambah Jenis Surat
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm" id="table_jenis">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Jenis Surat</th>
                                        <th>Kode</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <form id="form-add-jenis">
    <div class="modal fade" id="modal-add-jenis" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">add Jenis Surat</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Jenis</label>
                            <input type="text" class="form-control" name="nm_jenis" required>
                        </div>
                    </div>

                    <div class="col-12">
                      <div class="form-group">
                          <label for="">Kode</label>
                          <input type="text" class="form-control" name="kode" >
                      </div>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-input-jenis">Tambah</button>
            </div>
        </div>
        </div>
    </div>
    </form>

  <form id="form-edit-jenis">
    <div class="modal fade" id="modal-edit-jenis" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Edit Jenis Surat</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <input type="hidden" name="id" id="id_jenis">
                    
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Jenis</label>
                            <input type="text" class="form-control" name="nm_jenis" id="nm_jenis_e" required>
                        </div>
                    </div>

                    <div class="col-12">
                      <div class="form-group">
                          <label for="">Kode</label>
                          <input type="text" class="form-control" name="kode" id="kode_e" >
                      </div>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-edit-jenis">Edit</button>
            </div>
        </div>
        </div>
    </div>
    </form>

          

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {
    
    $('#table_jenis').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataJenisSurat')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'nm_jenis',
                        name: 'nm_jenis'
                    },  
                    {
                        data: 'kode',
                        name: 'kode'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: [
                    [0, 'asc']
                ]
            });

        $(document).on('click', '.edit_jenis', function() {
            var id = $(this).data('id');

            // console.log(id);
            
            $.get('get-jenis-surat/' + id, function (data) {
                //set value masing-masing id berdasarkan data yg diperoleh dari ajax get request diatas               
                $('#id_jenis').val(data.id);
                $('#nm_jenis_e').val(data.nm_jenis);
                $('#kode_e').val(data.kode);
                
            });
        });

        $(document).on('submit', '#form-add-jenis', function(event) {
                event.preventDefault();
                    $('#btn-input-jenis').attr('disabled',true);
                    $('#btn-input-jenis').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addJenis')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            
                            if(data){
                                $('#nm_jenis').val(""); //form reset
                                $('#kode_jenis').val(""); //form reset
                                $('#modal-add-jenis').modal('hide'); //modal hide
                                $("#btn-input-jenis").removeAttr("disabled");
                                $('#btn-input-jenis').html('Tambah'); //tombol simpan

                                var oTable = $('#table_jenis').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable
                                
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Nama jenis sudah ada'
                                });
                                $('#btn-input-jenis').html('Tambah');
                                $("#btn-input-jenis").removeAttr("disabled");
                            }
                                                        
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log(data);
                                    $('#btn-input-jenis').html('Tambah');
                                    $("#btn-input-jenis").removeAttr("disabled");
                                }
                    });

                });

        $(document).on('submit', '#form-edit-jenis', function(event) {
            event.preventDefault();
                $('#btn-edit-jenis').attr('disabled',true);
                $('#btn-edit-jenis').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                $.ajax({
                    url:"<?php echo e(route('editJenis')); ?>",
                    method: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        
                        $('#form-edit-jenis').trigger("reset"); //form reset
                        $('#modal-edit-jenis').modal('hide'); //modal hide
                        $("#btn-edit-jenis").removeAttr("disabled");
                        $('#btn-edit-jenis').html('Edit'); //tombol simpan

                        var oTable = $('#table_jenis').dataTable(); //inialisasi datatable
                        oTable.fnDraw(false); //reset datatable

                        Swal.fire({
                          toast: true,
                          position: 'top-end',
                          showConfirmButton: false,
                          timer: 3000,
                          icon: 'success',
                          title: 'Data berhasil diedit'
                        });

                        
                    },
                    error: function (data) { //jika error tampilkan error pada console
                                alert('Error:', data);
                                $('#btn-edit-jenis').html('Edit');
                                $("#btn-edit-jenis").removeAttr("disabled");
                            }
                });

            });
    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rahman/DATA D1/Programming/laravel/surat-keuar/resources/views/jenis_surat/index.blade.php ENDPATH**/ ?>