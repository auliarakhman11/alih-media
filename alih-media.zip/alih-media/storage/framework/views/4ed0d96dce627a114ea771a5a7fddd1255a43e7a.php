

<?php $__env->startSection('content'); ?>
    <!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
      <div class="col-lg-12 mb-4 order-0">
        <div class="card">
          <div class="d-flex align-items-end row">
            <div class="col-12">
              <div class="card-header">
                <div class="row">

                  <div class="col-md-6 col-12"><h4 class="text-primary">Penilaian Rekan Kerja</h4></div>

                  <div class="col-md-6 col-12">
                    

                    
                  </div>

                </div>
                
                
               
              </div>

              <div class="row" id="data_penilaian">
                
                
                
              </div>

            </div>

          </div>
        </div>
      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->

  <form id="form_edit_penilaian">
    <div class="modal fade" id="edit_penilaian" tabindex="-1" aria-labelledby="edit_penilaianLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="edit_penilaianLabel">Edit Penilaian</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" id="editPenilaian">
              
    
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn_ubah_penilaian">Save</button>
          </div>
        </div>
      </div>
    </div>
  </form>


  <form id="form_input_terbaik" class="terbaik">
    <div class="modal fade" id="modal_terbaik" aria-labelledby="input_terbaikLabel" aria-hidden="true">
      <div class="modal-dialog ">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="input_terbaikLabel">Input pegawai kinerja terbaik</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              
            <div class="row">

              <div class="col-12 mb-2">

                <input type="hidden" name="id" id="terbaik_id">

                <div class="form-group">
                  <label for="">Pegawai</label>
                  <select name="pegawai_id" id="pegawai_id_edit" class="form-control select2bs4" required>
                    <option value="">Pilih pegawai</option>
                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

              </div>
              
              

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn_input_terbaik">Save</button>
          </div>
        </div>
      </div>
    </div>
  </form>


  <form id="form_input_terburuk" class="terburuk">
    <div class="modal fade" id="modal_terburuk" tabindex="-1" aria-labelledby="input_terburukLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="input_terburukLabel">Input pegawai kinerja terendah</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
              
            <div class="row">
              <input type="hidden" name="id" id="terburuk_id">

              <div class="col-12">
                <div class="form-group">
                  <label for="">Pegawai</label>
                  <select name="pegawai_id" id="pegawai_id_terburuk" class="form-control select2bs4" required>
                    <option value="">Pilih pegawai</option>
                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>                
              </div>

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn_input_terburuk">Save</button>
          </div>
        </div>
      </div>
    </div>
  </form>

  

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {


            function getDataPenilaian(){
            $('#data_penilaian').html('<div class="col-12">"<div class="spinner-border spinner-border-lg text-primary ml-5" role="status"><span class="visually-hidden">Loading...</span></div></div>');
            $.get('get-data-penilaian-pegawai', function (data) {
                      $('#data_penilaian').html(data);
                      
                  });

                  
          }

          getDataPenilaian();

          //terbaik
          $(document).on('click', '.btn_input_terbaik', function() {
            $('.terbaik').attr('id','form_input_terbaik');
            $('#input_terbaikLabel').html('Input pegawai terbaik');
            
          });

          $(document).on('click', '.btn_edit_terbaik', function() {
            $('.terbaik').attr('id','form_edit_terbaik');

            $('#input_terbaikLabel').html('Edit pegawai terbaik');

            var terbaik_id = $(this).attr('terbaik_id');

            $.get('get-data-terbaik/'+terbaik_id, function (data) {
                        
                $('#terbaik_id').val(data.id);
                $('#nilai_terbaik').val(data.nilai);
                $('#pegawai_id_edit').val(data.pegawai_id);
                

                $("#pegawai_id_edit").select2({
                    dropdownParent: $('#modal_terbaik .modal-content'),
                    theme: 'bootstrap4',
                    tags: true,
                }).trigger('change');
                        
              });

          });

          $(document).on('submit', '#form_input_terbaik', function(event) {
                event.preventDefault();
                    $('#btn_input_terbaik').attr('disabled',true);
                    $('#btn_input_terbaik').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addTerbaik')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terbaik").removeAttr("disabled");
                                $('#btn_input_terbaik').html('Edit'); //tombol simpan
                  
                                $('#modal_terbaik').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terbaik').html('Edit');
                                $("#btn_input_terbaik").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terbaik').html('Edit');
                                    $("#btn_input_terbaik").removeAttr("disabled");

                                    $('#modal_terbaik').modal('hide'); //modal show
                                }
                    });
          });


          $(document).on('submit', '#form_edit_terbaik', function(event) {
                event.preventDefault();
                    $('#btn_input_terbaik').attr('disabled',true);
                    $('#btn_input_terbaik').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editTerbaik')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terbaik").removeAttr("disabled");
                                $('#btn_input_terbaik').html('Edit'); //tombol simpan
                  
                                $('#modal_terbaik').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terbaik').html('Edit');
                                $("#btn_input_terbaik").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terbaik').html('Edit');
                                    $("#btn_input_terbaik").removeAttr("disabled");

                                    $('#modal_terbaik').modal('hide'); //modal show
                                }
                    });
          });

          $("#pegawai_id_edit").select2({
              dropdownParent: $('#modal_terbaik .modal-content'),
              theme: 'bootstrap4',
              tags: true,
          });

          //endterbaik

          //terburuk

          $(document).on('click', '.btn_input_terburuk', function() {
            $('.terburuk').attr('id','form_input_terburuk');
            $('#input_terburukLabel').html('Input pegawai terburuk');
            
          });

          $(document).on('click', '.btn_edit_terburuk', function() {
            $('.terburuk').attr('id','form_edit_terburuk');

            $('#input_terburukLabel').html('Edit pegawai terburuk');

            var terburuk_id = $(this).attr('terburuk_id');

            $.get('get-data-terburuk/'+terburuk_id, function (data) {
                        
                $('#terburuk_id').val(data.id);
                $('#pegawai_id_terburuk').val(data.pegawai_id);
                

                $("#pegawai_id_terburuk").select2({
                    dropdownParent: $('#modal_terburuk .modal-content'),
                    theme: 'bootstrap4',
                    tags: true,
                }).trigger('change');
                        
              });

          });


          $(document).on('submit', '#form_input_terburuk', function(event) {
                event.preventDefault();
                    $('#btn_input_terburuk').attr('disabled',true);
                    $('#btn_input_terburuk').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addTerburuk')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terburuk").removeAttr("disabled");
                                $('#btn_input_terburuk').html('Edit'); //tombol simpan
                  
                                $('#modal_terburuk').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terburuk').html('Edit');
                                $("#btn_input_terburuk").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terburuk').html('Edit');
                                    $("#btn_input_terburuk").removeAttr("disabled");

                                    $('#modal_terburuk').modal('hide'); //modal show
                                }
                    });
          });


          $(document).on('submit', '#form_edit_terburuk', function(event) {
                event.preventDefault();
                    $('#btn_input_terburuk').attr('disabled',true);
                    $('#btn_input_terburuk').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editTerburuk')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terburuk").removeAttr("disabled");
                                $('#btn_input_terburuk').html('Edit'); //tombol simpan
                  
                                $('#modal_terburuk').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terburuk').html('Edit');
                                $("#btn_input_terburuk").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terburuk').html('Edit');
                                    $("#btn_input_terburuk").removeAttr("disabled");

                                    $('#modal_terburuk').modal('hide'); //modal show
                                }
                    });
          });


          $("#pegawai_id_terburuk").select2({
              dropdownParent: $('#modal_terburuk .modal-content'),
              theme: 'bootstrap4',
              tags: true,
          });
          //endterbaik

          

            $(document).on('click', '.btn_edit_penilaian', function() {

            var pegawai_id = $(this).attr('pegawai_id');

            $('#editPenilaian').html('<div class="col-12">"<div class="spinner-border spinner-border-lg text-primary ml-5" role="status"><span class="visually-hidden">Loading...</span></div></div>');
            $.get('get-edit-penilaian/'+pegawai_id, function (data) {
                        $('#editPenilaian').html(data);
                        
                    });

            });

            $(document).on('submit', '#form_edit_penilaian', function(event) {
                event.preventDefault();
                    $('#btn_ubah_penilaian').attr('disabled',true);
                    $('#btn_ubah_penilaian').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editPenilaian')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_ubah_penilaian").removeAttr("disabled");
                                $('#btn_ubah_penilaian').html('Edit'); //tombol simpan
                  
                                $('#edit_penilaian').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_ubah_penilaian').html('Edit');
                                $("#btn_ubah_penilaian").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_ubah_penilaian').html('Edit');
                                    $("#btn_ubah_penilaian").removeAttr("disabled");

                                    $('#edit_penilaian').modal('hide'); //modal show
                                }
                    });
          });
          

        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/penilaian_pegawai/index.blade.php ENDPATH**/ ?>