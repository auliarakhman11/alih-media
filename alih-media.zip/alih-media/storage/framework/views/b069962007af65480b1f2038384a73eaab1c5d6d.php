

<?php $__env->startSection('content'); ?>


<!-- Content -->



<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">

    <div class="col-12 mb-4 order-0">
      
      <div class="card">
          <div class="card-header">
              <h5 class="float-start">Input Stok Masuk</h5>
              <button type="button" class="btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#modal_tambah_barang"><i class='bx bxs-plus-circle'></i> Tambah Data</button>
          </div>
          
          <div class="card-body">

            <div class="row">

              <div class="col-4">
                <div class="form-group">
                  <label for="">Tanggal</label>
                  <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Barang</label>
                  <select name="barang_id" class="form-control select2bs4">
                    <option value="">Pilih Barang</option>
                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->id); ?>"><?php echo e($b->nm_barang); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Exprired Date</label>
                  <input type="date" name="tgl_exp" class="form-control" required>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Jumlah Box</label>
                  <input type="number" name="debit_box" class="form-control" required>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Jumlah PAK</label>
                  <input type="number" name="debit_pak" class="form-control" required>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Jumlah KG</label>
                  <input type="number" name="debit_kg" class="form-control" required>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Block</label>
                  <select name="block_id" class="form-control" id="block">
                    <option value="">Pilih Block</option>
                    <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->id); ?>|<?php echo e($b->nm_block); ?>"><?php echo e($b->nm_block); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Cell</label>
                  <select name="cell_id" class="form-control" id="cell">
                    <option value="">Pilih Cell</option>
                  </select>
                </div>
              </div>

              <div class="col-4">
                <div class="form-group">
                  <label for="">Rak</label>
                  <select name="rak_id" class="form-control" id="rak">
                    <option value="">Pilih Rak</option>
                  </select>
                </div>
              </div>
              
            </div>

          </div>
          
        </div>


    </div>

    <!-- Total Revenue -->

    <!--/ Total Revenue -->
    
  </div>

</div>
<!-- / Content -->

    

  <!-- Modal -->


<form id="form_input_penilaian">
  <div class="modal fade" id="input_penilaian" tabindex="-1" aria-labelledby="input_penilaianLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="input_penilaianLabel">Input Penilaian <span id="nm_pegawai_input"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
  
          
  
          
  
          
          
          
  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_simpan_penilaian">Simpan</button>
        </div>
      </div>
    </div>
  </div>
</form>





  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

            <?php if(session('success')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: '<?= session('success'); ?>'
            });            
            <?php endif; ?>

            <?php if(session('error')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: '<?= session('error'); ?>'
            });            
            <?php endif; ?>

            $(document).on('change', '#block', function() {
              var block_id = $(this).val();
              $('#cell').html('');
              $.get('get-cell/'+block_id, function (data) {        
                  $('#cell').html(data);
                });

            });

            $(document).on('change', '#cell', function() {
              var cell_id = $(this).val();
              $('#rak').html('');
              $.get('get-rak/'+cell_id, function (data) {        
                  $('#rak').html(data);
                });

            });

        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\warehouse\resources\views/stok_masuk/index.blade.php ENDPATH**/ ?>