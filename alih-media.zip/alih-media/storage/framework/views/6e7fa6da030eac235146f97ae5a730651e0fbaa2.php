<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <div class="app-brand demo">
    <a href="" class="app-brand-link">
      <span class="app-brand-logo demo">
        <img src="<?php echo e(asset('img')); ?>/cp.jpeg" alt="" width="30"
        viewBox="0 0 25 42"
        version="1.1">

        
          
      </span>
      <span class="demo menu-text fw-bolder ms-2" style="font-size: 11px;">PT CHAROEN POKHPAND INDONESIA PLANT BANDUNG WAREHOUSE CR01</span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
      <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    


  

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text"><i class='bx bxs-user-pin'></i> <?php echo e(Auth::user()->name); ?></span>
    </li>

    <li class="menu-item <?php echo e(Request::is(['input-stok-masuk','checker-masuk','list-stok-masuk']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-package"></i>
        <div data-i18n="Penerimaan">Penerimaan</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('input-stok-masuk') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('inputStokMasuk')); ?>" class="menu-link">
            <div data-i18n="Input Stok Masuk">Input Stok Masuk</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('checker-masuk') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('checkerMasuk')); ?>" class="menu-link">
            <div data-i18n="Checker">Checker Penerimaan</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('list-stok-masuk') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('listStokMasuk')); ?>" class="menu-link">
            <div data-i18n="Checker">List Stok Masuk</div>
          </a>
        </li>




      </ul>
    </li>

    <li class="menu-item <?php echo e(Request::is(['data-block','data-stok','return-barang','list-stok-hold']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-component"></i>
        <i class=''></i>
        <div data-i18n="Penyimpanan">Penyimpanan</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('data-block') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('dataBlock')); ?>" class="menu-link">
            <div data-i18n="Data Layout">Data Layout</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('data-stok') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('dataStok')); ?>" class="menu-link">
            <div data-i18n="Data Stok">Data Stok</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('return-barang') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('returnBarang')); ?>" class="menu-link">
            <div data-i18n="Return Barang">Input Barang Hold</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('list-stok-hold') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('listStokHold')); ?>" class="menu-link">
            <div data-i18n="Return Barang">List Barang Hold</div>
          </a>
        </li>



      </ul>
    </li>

    <li class="menu-item <?php echo e(Request::is(['input-stok-keluar','checker-keluar','list-stok-keluar']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-truck"></i>
        <div data-i18n="Pendistribusian">Pendistribusian</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('input-stok-keluar') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('inputStokKeluar')); ?>" class="menu-link">
            <div data-i18n="Input Stok Keluar">Input Stok Keluar</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('checker-keluar') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('checkerKeluar')); ?>" class="menu-link">
            <div data-i18n="Checker">Checker Pendistribusian</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('list-stok-keluar') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('listStokKeluar')); ?>" class="menu-link">
            <div data-i18n="Checker">List Stok Keluar</div>
          </a>
        </li>


      </ul>
    </li>

    <li class="menu-item <?php echo e(Request::is(['laporan-stok-masuk','laporan-stok-keluar','laporan-penerimaan-pengiriman','laporan-stok-kadaluarsa']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-report"></i>
        <div data-i18n="Laporan">Laporan</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('laporan-stok-masuk') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('laporanStokMasuk')); ?>" class="menu-link">
            <div data-i18n="Laporan Stok Masuk">Laporan Stok Masuk</div>
          </a>
        </li>
        <li class="menu-item <?php echo e(Request::is('laporan-stok-keluar') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('laporanStokKeluar')); ?>" class="menu-link">
            <div data-i18n="Laporan Stok Keluar">Laporan Stok Keluar</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('laporan-penerimaan-pengiriman') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('laporanPenerimaanPengiriman')); ?>" class="menu-link">
            <div data-i18n="Laporan Penerimaan dan Pengiriman">Laporan Penerimaan dan Pengiriman</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('laporan-stok-kadaluarsa') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('laporanStokKadaluarsa')); ?>" class="menu-link">
            <div data-i18n="Laporan Stok Kadaluarsa">Laporan Stok Kadaluarsa</div>
          </a>
        </li>

        


      </ul>
    </li>

    <li class="menu-item <?php echo e(Request::is(['user','barang','mitra']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-data"></i>
        <div data-i18n="Data Master">Data Master</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('barang') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('barang')); ?>" class="menu-link">
            <div data-i18n="Data Barang">Data Barang</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('user') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('user')); ?>" class="menu-link">
            <div data-i18n="Data User">Data User</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('mitra') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('mitra')); ?>" class="menu-link">
            <div data-i18n="Data mitra">Data mitra</div>
          </a>
        </li>

      </ul>
    </li>

    


    

    <li class="menu-item">
      <a href="<?php echo e(route('logout')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-log-out-circle'></i>
        <div data-i18n="Analytics">Logout</div>
      </a>
    </li>

    




  </ul>
</aside><?php /**PATH /home/u376106710/domains/cpibandung.com/aplikasilayout/resources/views/template/_sidebar.blade.php ENDPATH**/ ?>