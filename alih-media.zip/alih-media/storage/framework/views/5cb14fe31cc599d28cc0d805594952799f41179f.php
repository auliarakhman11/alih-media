<?php $__env->startSection('content'); ?>

<style>
  .blink {
  animation: blink 1s steps(1, end) infinite;
}

@keyframes  blink {
  0% {
    background-color: red;
    color: white;
  }
  50% {
    background-color: orange;
  }
  100% {
    background-color: yellow;
  }
}

.dropdown-item:hover {
  background-color: #007BFF;
  color: white;
}
</style>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <form id="form_surat">
        <div class="row justify-content-center">

            <div class="col-12">
                <div class="card">
                  
                    <div class="card-header">
                        <h4 class="float-left">Tambah Surat Keluar</h4>

                        <?php if(Auth::user()->seksi_id == 1): ?>
                        <div class="dropdown float-right dropleft">
                          <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-folder"></i>  Backup
                          </button>
                          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="<?php echo e(route('backupFileSurat')); ?>"><i class="fas fa-file-archive"></i> File Zip</a>
                            <a class="dropdown-item" href="<?php echo e(route('backupExcelSurat')); ?>"><i class="fas fa-file-excel"></i> Excel</a>
                          </div>
                        </div>
                        <?php endif; ?>

                    </div>
                    <div class="card-body">
                      <div id="message_error_pdf" style="display:none"></div>
                        <div class="row">

                          <div class="col-6 mb-2">
                              <div class="row">
                                  <div class="col-3">
                                      <label for="" class="float-right">Korsub</label>
                                  </div>
                                  <div class="col-9">
                                      <select name="korsub_id" id="korsub_id" class="form-control select2bs4" required>
                                        <option value="">Pilih Korsub..</option>
                                          <?php $__currentLoopData = $korsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($k->id); ?>" ><?php echo e($k->kode_klasifikasi.'.'.$k->kode); ?>|<?php echo e($k->nm_korsub); ?></option> 
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                  </div>
                              </div>
                          </div>

                          <div class="col-6 mb-2">
                            <div class="row">
                                <div class="col-3">
                                    <label for="" class="float-right">Kegiatan</label>
                                </div>
                                <div class="col-9">
                                    <select name="kegiatan_id" id="kegiatan_id" class="form-control select2bs4" required>
                                      <option value="">Pilih Kegiatan..</option>
                                      </select>
                                </div>
                            </div>
                          </div>

                          <div class="col-6 mb-2">
                            <div class="row">
                              <div class="col-3">
                                <label for="" class="float-right">Tujuan</label>
                              </div>
                              <div class="col-9">
                                <input type="text" class="form-control" name="tujuan" required>
                              </div>
                            </div>
                          </div>

                          <div class="col-6 mb-2">
                            <div class="row">
                              <div class="col-3">
                                <label for="" class="float-right">Perihal</label>
                              </div>
                              <div class="col-9">
                                <input type="text" class="form-control" name="perihal" required>
                              </div>
                            </div>
                          </div>

                          <div class="col-6 mb-2">
                            <div class="row">
                              <div class="col-3">
                                <label for="" class="float-right">Keterangan</label>
                              </div>
                              <div class="col-9">
                                <input type="text" class="form-control" name="keterangan">
                              </div>
                            </div>
                          </div>

                          <div class="col-6 mb-2">
                            <div class="row">
                              <div class="col-3">
                                <label for="" class="float-right">Jenis Surat</label>
                              </div>
                              <div class="col-9">
                                <select name="jenis_surat" class="form-control select2bs4" required>
                                  <option value="">Pilih Jenis Surat..</option>
                                  <?php $__currentLoopData = $jenis_surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($d->id); ?>"><?php echo e($d->nm_jenis); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                          </div>

                          <?php if(Auth::user()->seksi_id == 1): ?>
                          <div class="col-6 mb-2">
                            <div class="row">
                              <div class="col-3">
                                <label for="" class="float-right">Tanggal</label>
                              </div>
                              <div class="col-9">
                                
                                  <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><input type="checkbox" id="hari_sebelumnya"></span>
                                        </div>
                                        <input type="date" min="<?php echo e($start_time->tgl); ?>" max="<?php echo e(date('Y-m-d', strtotime("-1 day", strtotime(date("Y-m-d"))))); ?>" id="input_tgl_sebelumnya" class="form-control" name="tgl" disabled>
                                    </div>                            
                                  </div>                                    
                                                            
                              </div>
                            </div>
                          </div>
                          <?php endif; ?>

                          <div class="col-6">
                            <div class="row">

                              <div class="col-3">
                                <label for="" class="float-right">File PDF</label>
                              </div>

                              <div class="col-9">
                                <input type="file" name="file_name" class="form-control" id="file_pdf">
                              </div>

                            </div>
                          </div>
  
                          <div class="col-12 mb-2">
                                <button type="submit" id="save" class="btn btn-sm btn-primary float-right">
                                  <i class="fas fa-envelope"></i> 
                                  Buat No Surat
                              </button>
                          </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
      </form>

      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <?php if(Auth::user()->seksi_id == 1): ?>
                    <a href="#modal_export" data-toggle="modal" class="btn btn-primary btn-sm float-right"><i class="fas fa-file-excel"></i> Export</a>
                    <?php endif; ?>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-sm" id="table_surat" width="100%">
                  <thead>
                    <tr>
                      
                      <th>Tanggal</th>
                      <th>Nomor Surat</th>
                      <th>Tujuan</th>
                      <th>Perihal</th>
                      <th>Keterangan</th>
                      <th width="7%">Aksi</th>
                    </tr>
                  </thead>
                  <tbody style="font-size: 14px;"></tbody>
                </table>
              </div>                    
            </div>
          </div>
        </div>
      </div>

      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <form id="form-edit-surat">
    <div class="modal fade" id="modal-edit-surat" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Edit Surat</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <input type="hidden" name="id" id="id_surat">
                    <div class="col-12">
                        <label>Korsub</label>
                        <select name="korsub_id" class="form-control" id="korsub_id_e" required>
                            <?php $__currentLoopData = $korsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($o->id); ?>" >(<?php echo e($o->klasifikasi->kode.'.'.$o->kode); ?>) <?php echo e($o->nm_korsub); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Kegiatan</label>
                            <select name="kegiatan_id" class="form-control select2bs4" id="kegiatan_id_e" required>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="">Tujuan</label>
                            <input type="text" name="tujuan" id="tujuan_e" class="form-control" required>
                        </div>
                    </div>

                    <div class="col-12">
                      <div class="form-group">
                          <label for="">Perihal</label>
                          <input type="text" name="perihal" id="perihal_e" class="form-control" required>
                      </div>
                    </div>

                    <div class="col-12">
                      <div class="form-group">
                          <label for="">Keterangan</label>
                          <input type="text" name="keterangan" id="keterangan_e" class="form-control">
                      </div>
                    </div>

                    <div class="col-12">
                      <div class="form-group">
                          <label for="">Jenis Surat</label>
                          <select name="jenis_surat" id="jenis_surat_e" class="form-control" required>
                            <?php $__currentLoopData = $jenis_surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($d->id); ?>"><?php echo e($d->nm_jenis); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-edit-surat">Edit</button>
            </div>
        </div>
        </div>
    </div>
    </form>


  <div class="modal fade" id="modal_no_surat" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <h5>Nomor surat : <b id="generate_no_surat"></b></h5>
          <h5 id="file_kosong" class="text-warning"></h5>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  
    <div class="modal fade" id="modal-scan" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Scan Surat</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
              
              

            <div id="message_error" style="display:none"></div>
            <div id="div_form_scan">
              <form id="form-scan-surat" enctype="multipart/form-data">
                <div class="row">
                    <input type="hidden" name="id" id="id_surat_scan">
                    <div class="col-10">
                        <div class="form-group">
                            <input type="file" name="file_name" id="input_file" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-2">
                      <button type="submit" class="btn btn-primary" id="btn-scan-surat"><i class="fas fa-upload"></i> Upload 
                      </button>
                      
                    </div>
                </div>
              </form>
            </div>
            
            
          
            <div id="display_pdf"></div>
                
                
            </div>
        </div>
        </div>
    </div>
    

    <div class="modal fade" id="modal_file_pdf" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
          <div class="modal-header bg-primary">
          <h5 class="modal-title" id="exampleModalLabel">Scan Surat</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
          </div>
          <div class="modal-body" id="display_file_pdf">
         
              
              
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
      </div>
      </div>
  </div>


  <form action="<?php echo e(route('exportLaporanSurat')); ?>">
    <div class="modal fade" id="modal_export" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header bg-primary">
          <h5 class="modal-title" id="exampleModalLabel">Export</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-6">
                <div class="form-group">
                  <label for="">Dari</label>
                  <input type="date" name="tgl1" class="form-control" required>
                </div>
              </div>
              <div class="col-6">
                <div class="form-group">
                  <label for="">Sampai</label>
                  <input type="date" name="tgl2" class="form-control" required>
                </div>
              </div>
            </div>          
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" >Export</button>
          </div>
      </div>
      </div>
    </div>
    </form>

          

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {

    $(document).on('change', '#file_pdf', function() {
      const [file] = file_pdf.files
      if (file) {
        var url = URL.createObjectURL(file)
      }else{
        var url = '';
      }
            var pdf = '<object data="'+url+'" type="application/pdf" width="780" height="500"></object>';
            $("#display_file_pdf").html(pdf);

            $('#modal_file_pdf').modal('show'); //modal show

            $('#message_error_pdf').hide();
            
    });

    $(document).on('change', '#input_file', function() {
      $('#message_error').hide();
      const [file] = input_file.files
      if (file) {
        var url = URL.createObjectURL(file)
      }else{
        var url = '';
      }
            // var url = $(this).val();
            var pdf = '<object data="'+url+'" type="application/pdf" width="780" height="500"></object>';
            $("#display_pdf").html(pdf);
            
    });

    $(document).on('click', '.btn_scan', function() {
            $('#message_error').hide();
            $('#input_file').val('');
            var id = $(this).data('id');
            $("#id_surat_scan").val(id);

            var seksi_id = "<?php echo e(Auth::user()->seksi_id); ?>"

            var file_name = $(this).attr('file_name');
            var url = "<?php echo e(asset('scan')); ?>/";
            var pdf = '<object data="'+url+file_name+'" type="application/pdf" width="780" height="500"></object>';

            

            if(!file_name || seksi_id == 1){
              $('#div_form_scan').show();
            }else{
              $('#div_form_scan').hide();
            }


            if(file_name){
              $("#display_pdf").html(pdf);
            }else{
              $("#display_pdf").html('');
            }
            
          });

          $(document).on('submit', '#form-scan-surat', function(event) {
                event.preventDefault();
                    $('#btn-scan-surat').attr('disabled',true);
                    $('#btn-scan-surat').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('uploadScan')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn-scan-surat").removeAttr("disabled");
                                $('#btn-scan-surat').html('<i class="fas fa-upload"></i> Upload'); //tombol simpan

                                $('#modal-scan').modal('hide'); //modal hide

                                $('#form-scan-surat').trigger("reset");
                                

                                var oTable = $('#table_surat').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data scan berhasil diupload'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn-scan-surat').html('<i class="fas fa-upload"></i> Upload');
                                $("#btn-scan-surat").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);

                                    var dt_error = '<div class="alert alert-danger">';
                                    jQuery.each(data.responseJSON.errors, function(key, message){
                                        
                                    dt_error += '<p>'+message+'</p>';
                                    // $('.alert-danger').append('<p>'+message+'</p>');
                                    });
                                    dt_error += '</div>';
                                    $('#message_error').html(dt_error);
                                    $('#message_error').show();
                                    $('#btn-scan-surat').html('<i class="fas fa-upload"></i> Upload');
                                    $("#btn-scan-surat").removeAttr("disabled");
                                }
                    });

    });

    $('#table_surat').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataSurat')); ?>",
                    type: 'GET'
                },
                columns: [
                    // {
                    //     data: 'DT_RowIndex',
                    //     name: 'DT_RowIndex'
                    // },
                    {
                        data: 'tgl',
                        name: 'tgl'
                    },  
                    {
                        data: 'no_surat',
                        name: 'no_surat'
                    },                                           
                    {
                        data: 'tujuan',
                        name: 'tujuan'
                    },
                    {
                        data: 'perihal',
                        name: 'perihal'
                    },
                    {
                        data: 'keterangan',
                        name: 'keterangan'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: []
            });

    $(document).on('change', '#korsub_id', function() {
            var id = $(this).val();
            
            $.get('get-list-kegiatan/' + id, function (data) {
                $('#kegiatan_id').html(data);
            });
    });

    $(document).on('change', '#korsub_id_e', function() {
            var id = $(this).val();
            
            $.get('get-list-kegiatan/' + id, function (data) {
                $('#kegiatan_id_e').html(data);
            });
    });

    $(document).on('click', '.edit_surat', function() {
            var id = $(this).data('id');

            // console.log(id);
            
            $.get('get-surat/' + id, function (data) {
                //set value masing-masing id berdasarkan data yg diperoleh dari ajax get request diatas
                

                $('#id_surat').val(data.dt_surat.id);

                $('#korsub_id_e').val(data.dt_surat.korsub_id);
                

                $('#tujuan_e').val(data.dt_surat.tujuan);
                $('#perihal_e').val(data.dt_surat.perihal);
                $('#keterangan_e').val(data.dt_surat.keterangan);

                $('#jenis_surat_e').val(data.dt_surat.jenis_surat);
                $('#jenis_surat_e').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                var kegiatan = '';
                $.each(data.dt_kegiatan, function(key,value) {
                  kegiatan += '<option value="'+value.id+'">'+value.korsub.klasifikasi.kode+'.'+value.korsub.kode+'.'+value.kode+'|'+value.nm_kegiatan+'</option>';
                });

                $('#kegiatan_id_e').html(kegiatan);

                $('#kegiatan_id_e').val(data.dt_surat.kegiatan_id);
                $('#kegiatan_id_e').select2({theme: 'bootstrap4', tags: true,}).trigger('change');
                
                
            });
        });

    $(document).on('submit', '#form_surat', function(event) {
                event.preventDefault();
                    $('#save').attr('disabled',true);
                    $('#save').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addNoSurat')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data.status == 'success'){
                                $("#save").removeAttr("disabled");
                                $('#save').html('<i class="fas fa-envelope"></i> Buat No Surat'); //tombol simpan

                                $('#form_surat').trigger("reset");
                                $('#kegiatan_id').html('<option value="">Pilih Kegiatan..</option>');
                                $('.select2bs4').val('');
                                $('.select2bs4').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                                $('#input_tgl_sebelumnya').attr('disabled',true);
                                
                                $('#generate_no_surat').html(data.dt_surat.no_surat);

                              if(!data.dt_surat.file_name){
                                $('#file_kosong').html("- File PDF belum diupload, Harap upload PDF sebelum 3 hari !! <br> - File surat yang di upload <span class'text-danger'><b>WAJIB</b></span> surat yang sudah bertandatangan !!");
                              }else{
                                $('#file_kosong').html("");
                              }

                                $('#modal_no_surat').modal('show'); //modal show

                                var oTable = $('#table_surat').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });

                                $('#message_error_pdf').hide();
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#save').html('<i class="fas fa-envelope"></i> Buat No Surat');
                                $("#save").removeAttr("disabled");
                                
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                  console.log('Error:', data);

                                  var dt_error = '<div class="alert alert-danger">';
                                  jQuery.each(data.responseJSON.errors, function(key, message){
                                      
                                  dt_error += '<p>'+message+'</p>';
                                  // $('.alert-danger').append('<p>'+message+'</p>');
                                  });
                                  dt_error += '</div>';
                                  $('#message_error_pdf').html(dt_error);
                                  $('#message_error_pdf').show();
                                  $('#save').html('<i class="fas fa-envelope"></i> Buat No Surat');
                                  $("#save").removeAttr("disabled");
                                }
                    });

    });

    $(document).on('change', '#hari_sebelumnya', function() {
        if ($(this).is(':checked')) {
          $("#input_tgl_sebelumnya").removeAttr("disabled");
        }else{
          $('#input_tgl_sebelumnya').attr('disabled',true);
        }
    });


    $(document).on('submit', '#form-edit-surat', function(event) {
                event.preventDefault();
                    $('#btn-edit-surat').attr('disabled',true);
                    $('#btn-edit-surat').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editNoSurat')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data.status == 'success'){
                                $("#btn-edit-surat").removeAttr("disabled");
                                $('#btn-edit-surat').html('Edit'); //tombol simpan
                                
                                $('#modal-edit-surat').modal('hide');
                                $('#form_surat').trigger("reset");
                                $('#kegiatan_id').html('<option value="">Pilih Kegiatan..</option>');
                                $('.select2bs4').val('');
                                $('.select2bs4').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                                $('#input_tgl_sebelumnya').attr('disabled',true);
                                
                                $('#generate_no_surat').html(data.dt_surat.no_surat);

                                $('#modal_no_surat').modal('show'); //modal show


                                var oTable = $('#table_surat').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn-edit-surat').html('Edit');
                                $("#btn-edit-surat").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn-edit-surat').html('Edit');
                                    $("#btn-edit-surat").removeAttr("disabled");
                                }
                    });

    });

    $(document).on('click', '.btn_delete', function() {

if (confirm('Apakah anda yakin ingin menghapus data surat?')) {
    var id = $(this).data('id');
    $.get('drop-surat-keluar/' + id, function (data) {
        var oTable = $('#table_surat').dataTable(); //inialisasi datatable
            oTable.fnDraw(false); //reset datatable

        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: 'Data berhasil dihapus'
            });
    });
}  

});
    
    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master_sk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/surat/index.blade.php ENDPATH**/ ?>