<div class="row">
    <input type="hidden" name="id" value="<?php echo e($dt_st->id); ?>">
    <div class="col-6">
        <div class="form-group text-center">
            <label for="">Perial</label>
            <input type="text" class="form-control" name="perihal" value="<?php echo e($dt_st->perihal); ?>" required>
        </div>
    </div>
    <div class="col-6">
        <div class="form-group text-center">
            <label for="">Tempat Tujuan</label>
            <input type="text" class="form-control" name="tujuan" value="<?php echo e($dt_st->tujuan); ?>" required>
        </div>
    </div>
    <div class="col-4">
        <div class="form-group text-center">
            <label for="">Dari</label>
            <input type="date" class="form-control" name="tgl1" value="<?php echo e($dt_st->tgl1); ?>" required>
        </div>
    </div>
    <div class="col-4">
        <div class="form-group text-center">
            <label for="">Sampai</label>
            <input type="date" class="form-control" name="tgl2" value="<?php echo e($dt_st->tgl2); ?>" required>
        </div>
    </div>

    <div class="col-4">
        <div class="form-group text-center">
            <label for="">Dalam/Luar Kota</label>
            <select name="luar_kota" class="form-control" required>
                <option value="1" <?php echo e($dt_st->luar_kota ? 'selected' : ''); ?>>Luar Kota</option>
                <option value="0" <?php echo e(!$dt_st->luar_kota ? 'selected' : ''); ?>>Dalam Kota</option>
            </select>
        </div>
    </div>

    <div class="col-12">
        <table class="table table-sm" width="100%">
            <thead>
                <tr>
                    <th>Pegawai</th>
                    <th>#</th>
                </tr>                
            </thead>
            <tbody id="tb_pegawai_edit">
                <?php
                    $jml_pegawai = $dt_st->sppd->count();
                ?>
                <?php $__currentLoopData = $dt_st->sppd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <input type="hidden" name="id_sppd[]" value="<?php echo e($sp->id); ?>">
                            <select name="pegawai_id[]" class="form-control select2bs4" required>
                                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($sp->pegawai_id == $d->id ? 'selected' : ''); ?> value="<?php echo e($d->id); ?>"><?php echo e($d->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td><?php if($jml_pegawai > 1): ?>
                            <button type="button" class="btn btn-xs mt-2 btn-danger delete_sppd" id_sppd="<?php echo e($sp->id); ?>" id_st="<?php echo e($dt_st->id); ?>"><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
            </tbody>
            <tbody>
                <tr>
                    <td></td>
                    <td><button id="tambah_pegawai" class="btn btn-xs btn-primary rounded float-right" type="button"><i class="fas fa-plus"></i></button></td>
                </tr>
            </tbody>
        </table>
        
    </div>

</div>
<?php /**PATH /media/rahman/DATA D1/Programming/laravel/surat-keuar/resources/views/surat_tugas/edit.blade.php ENDPATH**/ ?>