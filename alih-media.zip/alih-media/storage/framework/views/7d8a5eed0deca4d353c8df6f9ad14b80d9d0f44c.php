<?php $__env->startSection('content'); ?>
    <!-- Content -->



<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

      <div class="col-12 mb-4 order-0">
        
        <div class="card">
            <div class="card-header">
                <h5 class="float-start">Data PPNPN</h5>
                <button type="button" class="btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#modal_add_pegawai"><i class='bx bxs-plus-circle'></i> Tambah Data</button>
            </div>
            
            <div class="table-responsive text-nowrap">
              <table class="table" id="table_user">
                <thead>
                  <tr>
                    <th>Nama</th>
                    <th>NIP/NRP</th>
                    <th>Seksi</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody class="table-border-bottom-0">                  
                 
                </tbody>
              </table>
            </div>
          </div>

      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->

  <form id="form_edit_user" enctype="multipart/form-data">
    <div class="modal fade" id="modal_edit_user" tabindex="-1" aria-labelledby="modal_edit_userLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modal_edit_userLabel">Tanda Tangan</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <input type="hidden" name="id" id="user_id">
                <div class="col-12">
                    <div class="form-group">
                        <input type="file" name="file_name" class="form-control" required>
                    </div>
                </div>    
                
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary" id="btn_edit_user">Save</button>
            </div>
          </div>
        </div>
      </div>
  </form>
  

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {


            function getUser(){
            var pTable = $('#table_user').dataTable(); //inialisasi datatable
            pTable.fnDraw(false); //reset datatable
            }

            $(document).on('click', '.edit_user', function() {

                var user_id = $(this).attr('user_id');

                $('#user_id').val(user_id);

                

            });

            $('#table_user').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataUser')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'name',
                        name: 'user.name'
                    },
                    {
                        data: 'nip',
                        name: 'user.nip'
                    },
                    {
                        data: 'seksi.nm_seksi',
                        name: 'seksi.nm_seksi'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    },
                    
                ],
                order: [],
            });


            $(document).on('submit', '#form_edit_user', function(event) {
                event.preventDefault();
                    $('#btn_edit_user').attr('disabled',true);
                    $('#btn_edit_user').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editUser')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_edit_user").removeAttr("disabled");
                                $('#btn_edit_user').html('Edit'); //tombol simpan
                  
                                $('#modal_edit_user').modal('hide'); //modal show

                                getUser();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_edit_user').html('Edit');
                                $("#btn_edit_user").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_edit_user').html('Edit');
                                    $("#btn_edit_user").removeAttr("disabled");

                                    $('#modal_edit_user').modal('hide'); //modal show
                                }
                    });
            });


            
        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/user/index.blade.php ENDPATH**/ ?>