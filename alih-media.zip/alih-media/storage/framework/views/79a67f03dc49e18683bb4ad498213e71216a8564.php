

<?php $__env->startSection('content'); ?>
    <!-- Content -->

<style>
    .th-atas {
	    position: -webkit-sticky; /* Safari */
        position: sticky;
        top:0;
        z-index: 9999;
		}

        .th-middle {
	    position: -webkit-sticky; /* Safari */
        position: sticky;
        top:40px;
        z-index: 9999;
		}

        div.scroll_horizontal {
            overflow-y: scroll;
            overflow-x: auto;
            white-space: nowrap;
            height:520px;
        }
  
</style>


<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

      <div class="col-12 mb-4 order-0">
        
        <div class="card">
            <h5 class="card-header">PPNPN Terbaik</h5>
            <div class="table-responsive text-nowrap">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Jabatan</th>
                    <th>Nilai</th>
                  </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php
                        $i=1;
                    ?>
                    <?php $__currentLoopData = $terbaik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <?php if($i == 2): ?>
                        <td><?php echo e($t->nama); ?> <i class="bx bxs-crown text-warning"></i></td>
                        <?php else: ?>
                        <td><?php echo e($t->nama); ?></td>
                        <?php endif; ?>
                         
                        <td><?php echo e($t->jabatan); ?></td>
                        <td><?php echo e($t->ttl_nilai); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                 
                </tbody>
              </table>
            </div>
          </div>

      </div>

      <div class="col-12 mb-4 order-0">
        
        <div class="card">
            <h5 class="card-header">PPNPN Terburuk</h5>
            <div class="table-responsive text-nowrap">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Jabatan</th>
                    <th>Banyak<br>Votes</th>
                  </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php
                        $i=1;
                    ?>
                    <?php $__currentLoopData = $terburuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <?php if($i == 2): ?>
                        <td><?php echo e($t->nama); ?> <i class='bx bxs-user-x text-danger'></i></td> 
                        <?php else: ?>
                        <td><?php echo e($t->nama); ?> </td> 
                        <?php endif; ?>
                        
                        <td><?php echo e($t->jabatan); ?></td>
                        <td><?php echo e($t->ttl_vote); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                 
                </tbody>
              </table>
            </div>
          </div>

      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->

  

  

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

         

        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/administrator/baik_buruk.blade.php ENDPATH**/ ?>