<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->

      <style>
        .dropdown-item:hover {
          background-color: #007BFF;
          color: white;
        }

        .blink {
          animation: blink 1s steps(1, end) infinite;
        }

        @keyframes  blink {
          0% {
            background-color: red;
            color: white;
          }
          50% {
            background-color: orange;
          }
          100% {
            background-color: yellow;
          }
        }

      </style>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">

            <div class="col-12">
                <div class="card">
                  
                    <div class="card-header">

                        <h4 class="float-left">Buat Surat Tugas</h4>
                        <?php if(Auth::user()->seksi_id == 1): ?>
                        <div class="dropdown float-right dropleft">
                          <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-folder"></i>  Backup
                          </button>
                          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="<?php echo e(route('backupFileSt')); ?>"><i class="fas fa-file-archive"></i> File Zip</a>
                            <a class="dropdown-item" href="<?php echo e(route('backupExcelSt')); ?>"><i class="fas fa-file-excel"></i> Excel</a>
                          </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                      <div id="message_error_pdf" style="display:none"></div>
                        <form id="form_add_surat">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group text-center">
                                        <label for="">Perihal</label>
                                        <input type="text" class="form-control" name="perihal" required>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group text-center">
                                        <label for="">Tempat Tujuan</label>
                                        <input type="text" class="form-control" name="tujuan" required>
                                    </div>
                                </div>

                                <div class="col-3">
                                    <div class="form-group text-center">
                                        <label for="">Dari</label>
                                        <input type="date" class="form-control" name="tgl1" required>
                                    </div>
                                </div>

                                <div class="col-3">
                                  <div class="form-group text-center">
                                      <label for="">Sampai</label>
                                      <input type="date" class="form-control" name="tgl2">
                                  </div>
                              </div>

                                <div class="col-6">
                                    <div class="form-group text-center">
                                        <label for="">Pegawai</label>
                                        <select name="pegawai_id[]" class="form-control select2bs4" multiple="multiple" required>
                                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-3">
                                  <div class="form-group text-center">
                                    <label for="">Luar/Dalam Kota</label>
                                        <select name="luar_kota" class="form-control" required>
                                            <option value="">Pilih..</option>
                                            <option value="1">Luar Kota</option>
                                            <option value="0">Dalam Kota</option>
                                        </select>
                                  </div>
                                </div>

                                <div class="col-3">
                                  <div class="form-group text-center">
                                    <label for="">File PDF</label>
                                    <input type="file" name="file_name" class="form-control" id="file_pdf">
                                  </div>                                  
                                </div>

                                <div class="col-3">
                                  <?php if(Auth::user()->seksi_id == 1): ?>
                                  <div class="form-group text-center">
                                      <label for="">Tanggal Surat</label>
                                      
                                      <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><input type="checkbox" id="hari_sebelumnya"></span>
                                        </div>
                                        <input type="date" min="<?php echo e($start_time->tgl); ?>" max="<?php echo e(date('Y-m-d', strtotime("-1 day", strtotime(date("Y-m-d"))))); ?>" id="input_tgl_sebelumnya" class="form-control" name="tgl_sebelumnya" disabled>                                        
                                      </div> 
                                  </div>
                                  <?php endif; ?>
                                </div>                                
                                <div class="col-3">
                                  <div class="row">

                                    <div class="col-6">

                                      <?php if(Auth::user()->seksi_id == 1): ?>
                                      <div class="form-group text-center">
                                        <label for="">Seksi</label>
                                            <select name="seksi_id" class="form-control" required>
                                               <?php $__currentLoopData = $seksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($d->id); ?>"><?php echo e($d->nm_seksi); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                      </div>
                                      <?php endif; ?>
                                      
                                    </div>

                                    <div class="col-6">
                                      <button class="btn btn-sm btn-primary float-right mt-4" id="btn_add_surat" type="submit"><i class="fas fa-envelope"></i> Simpan</button>
                                    </div>

                                  </div>                                  
                                </div>

                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                  <div class="card-header">
                    <h5 class="float-left">Data Surat Tugas</h5>
                    <?php if(Auth::user()->seksi_id == 1): ?>
                    <a href="#modal_export" data-toggle="modal" class="btn btn-primary btn-sm float-right"><i class="fas fa-file-excel"></i> Export</a>
                    <?php endif; ?>
                    
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-sm" id="table_surat_tugas" width="100%" style="font-size: 12px;">
                        <thead>
                          <tr>
                            
                            <th width="15%">No Surat</th>
                            <th>No SPPD</th>
                            <th width="23%">Nama</th>
                            <th>Perihal</th>
                            <th width="10%">Tanggal</th>
                            <th>Tempat Tujuan</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody></tbody>
                      </table>
                    </div>
                  </div>
                </div>
            </div>


        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <div class="modal fade" id="modal_no_surat" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">No Surat Tugas</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <table class="table table-sm">
              <thead>
                  <tr>
                      <th>No Surat</th>
                      <th>No SPPD</th>
                      <th>Pegawai</th>
                  </tr>
              </thead>
              <tbody id="generate_no_surat">
                  
              </tbody>
          </table>

          <h5 id="file_kosong" class="text-warning"></h5>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <form id="form_edit_surat">
    <div class="modal fade" id="modal-edit-surat" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Edit Surat</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body" id="data_edit">
                
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-edit-surat">Edit</button>
            </div>
        </div>
        </div>
    </div>
    </form>

    <div class="modal fade" id="modal-scan" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
          <div class="modal-header bg-primary">
          <h5 class="modal-title" id="exampleModalLabel">Scan Surat</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
          </div>
          <div class="modal-body">
            
            

          <div id="message_error" style="display:none"></div>
          <div id="div_form_scan">
            <form id="form-scan-surat" enctype="multipart/form-data">
              <div class="row">
                  <input type="hidden" name="id" id="id_surat_scan">
                  <div class="col-10">
                      <div class="form-group">
                          <input type="file" name="file_name" id="input_file" class="form-control" required>
                      </div>
                  </div>
                  <div class="col-2">
                    <button type="submit" class="btn btn-primary" id="btn-scan-surat"><i class="fas fa-upload"></i> Upload 
                    </button>
                    
                  </div>
              </div>
            </form>
          </div>

          <div id="display_pdf"></div>
              
          </div>
      </div>
      </div>
  </div>


  <div class="modal fade" id="modal_file_pdf" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
        <div class="modal-header bg-primary">
        <h5 class="modal-title" id="exampleModalLabel">Scan Surat</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body" id="display_file_pdf">
       
            
            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
    </div>
</div>

<form action="<?php echo e(route('exportLaporanSt')); ?>">
<div class="modal fade" id="modal_export" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
  <div class="modal-content">
      <div class="modal-header bg-primary">
      <h5 class="modal-title" id="exampleModalLabel">Export</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-6">
            <div class="form-group">
              <label for="">Dari</label>
              <input type="date" name="tgl1" class="form-control" required>
            </div>
          </div>
          <div class="col-6">
            <div class="form-group">
              <label for="">Sampai</label>
              <input type="date" name="tgl2" class="form-control" required>
            </div>
          </div>
        </div>          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" >Export</button>
      </div>
  </div>
  </div>
</div>
</form>

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {

    $(document).on('change', '#file_pdf', function() {
      const [file] = file_pdf.files
      if (file) {
        var url = URL.createObjectURL(file)
      }else{
        var url = '';
      }
            var pdf = '<object data="'+url+'" type="application/pdf" width="780" height="500"></object>';
            $("#display_file_pdf").html(pdf);

            $('#modal_file_pdf').modal('show'); //modal show

            $('#message_error_pdf').hide();
            
    });

    $(document).on('change', '#hari_sebelumnya', function() {
        if ($(this).is(':checked')) {
          $("#input_tgl_sebelumnya").removeAttr("disabled");
        }else{
          $('#input_tgl_sebelumnya').attr('disabled',true);
        }
    });

    $(document).on('change', '#input_file', function() {

      $('#message_error').hide();
    const [file] = input_file.files
    if (file) {
      var url = URL.createObjectURL(file)
    }else{
      var url = '';
    }
          // var url = $(this).val();
          var pdf = '<object data="'+url+'" type="application/pdf" width="780" height="500"></object>';
          $("#display_pdf").html(pdf);
          
    });

    $(document).on('click', '.btn_scan', function() {
            $('#message_error').hide();
            $('#input_file').val('');
            var id = $(this).data('id');
            $("#id_surat_scan").val(id);

            var seksi_id = "<?php echo e(Auth::user()->seksi_id); ?>"
            var file_name = $(this).attr('file_name');
            var url = "<?php echo e(asset('scan_st')); ?>/";
            var pdf = '<object data="'+url+file_name+'" type="application/pdf" width="780" height="500"></object>';
            if(file_name){
              $("#display_pdf").html(pdf);
            }else{
              $("#display_pdf").html('');
            }

            if(!file_name || seksi_id == 1){
              $('#div_form_scan').show();
            }else{
              $('#div_form_scan').hide();
            }
            
          });

          $(document).on('submit', '#form-scan-surat', function(event) {
                event.preventDefault();
                    $('#btn-scan-surat').attr('disabled',true);
                    $('#btn-scan-surat').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('uploadScanSt')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn-scan-surat").removeAttr("disabled");
                                $('#btn-scan-surat').html('<i class="fas fa-upload"></i> Upload'); //tombol simpan

                                $('#modal-scan').modal('hide'); //modal hide

                                $('#form-scan-surat').trigger("reset");
                                

                                var oTable = $('#table_surat_tugas').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data scan berhasil diupload'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn-scan-surat').html('<i class="fas fa-upload"></i> Upload');
                                $("#btn-scan-surat").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);

                                    var dt_error = '<div class="alert alert-danger">';
                                    jQuery.each(data.responseJSON.errors, function(key, message){
                                        
                                    dt_error += '<p>'+message+'</p>';
                                    // $('.alert-danger').append('<p>'+message+'</p>');
                                    });
                                    dt_error += '</div>';
                                    $('#message_error').html(dt_error);
                                    $('#message_error').show();
                                    $('#btn-scan-surat').html('<i class="fas fa-upload"></i> Upload');
                                    $("#btn-scan-surat").removeAttr("disabled");
                                }
                    });

    });

    $('#table_surat_tugas').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataSuratTugas')); ?>",
                    type: 'GET'
                },
                columns: [
                    // {
                    //     data: 'DT_RowIndex',
                    //     name: 'DT_RowIndex'
                    // },
                    {
                        data: 'no_surat',
                        name: 'no_surat'
                    },  
                    {
                        data: 'no_sppd',
                        name: 'no_sppd'
                    },                                           
                    {
                        data: 'pegawai',
                        name: 'pegawai'
                    },
                    {
                        data: 'perihal',
                        name: 'perihal'
                    },
                    {
                        data: 'tgl',
                        name: 'tgl'
                    },
                    {
                        data: 'tujuan',
                        name: 'tujuan'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: []
            });

    function getDataEdit(id){
      $.get('get-data-edit/' + id, function (data) {
                $('#data_edit').html(data);
                $('.select2bs4').select2({
                    theme: 'bootstrap4',
                    tags: true,
                });
            });

            
    }

    $(document).on('click', '.edit_surat', function() {
            var id = $(this).data('id');
            
            getDataEdit(id);
    });
    
    $(document).on('submit', '#form_add_surat', function(event) {
                event.preventDefault();
                    $('#btn_add_surat').attr('disabled',true);
                    $('#btn_add_surat').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addNoSuratTugas')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data.status == 'success'){
                                $("#btn_add_surat").removeAttr("disabled");
                                $('#btn_add_surat').html('<i class="fas fa-envelope"></i> Simpan'); //tombol simpan

                                $('#form_add_surat').trigger("reset");

                                $('.select2bs4').val('');
                                $('.select2bs4').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                                var html = '<tr>';
                                html += '<td>'+data.dt_surat.no_surat+'</td>';
                                
                                html += '<td>';
                                $.each(data.dt_surat.sppd, function(i, item) {
                                    html += item.no_sppd + '<br>';
                                });
                                html += '</td>';
                                html += '<td>';
                                  $.each(data.dt_surat.sppd, function(i, item) {
                                    html += item.pegawai.nama + '<br>';
                                });
                                html += '</td>';
                                html += '</tr>';
                                $('#generate_no_surat').html(html);

                                if(!data.dt_surat.file_name){
                                  $('#file_kosong').html("- File PDF belum diupload, Harap upload PDF sebelum 3 hari !! <br> - File surat yang di upload <span class'text-danger'><b>WAJIB</b></span> surat yang sudah bertandatangan !!");
                                }else{
                                  $('#file_kosong').html("");
                                }
                  
                                $('#modal_no_surat').modal('show'); //modal show

                                var oTable = $('#table_surat_tugas').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_add_surat').html('<i class="fas fa-envelope"></i> Simpan');
                                $("#btn_add_surat").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);

                                  var dt_error = '<div class="alert alert-danger">';
                                  jQuery.each(data.responseJSON.errors, function(key, message){
                                      
                                  dt_error += '<p>'+message+'</p>';
                                  // $('.alert-danger').append('<p>'+message+'</p>');
                                  });
                                  dt_error += '</div>';
                                  $('#message_error_pdf').html(dt_error);
                                  $('#message_error_pdf').show();

                                    $('#btn_add_surat').html('<i class="fas fa-envelope"></i> Simpan');
                                    $("#btn_add_surat").removeAttr("disabled");
                                }
                    });

    });

    $(document).on('submit', '#form_edit_surat', function(event) {
                event.preventDefault();
                    $('#btn-edit-surat').attr('disabled',true);
                    $('#btn-edit-surat').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editSuratTugas')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn-edit-surat").removeAttr("disabled");
                                $('#btn-edit-surat').html('Edit'); //tombol simpan
                  
                                $('#modal-edit-surat').modal('hide'); //modal show

                                var oTable = $('#table_surat_tugas').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn-edit-surat').html('Edit');
                                $("#btn-edit-surat").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn-edit-surat').html('Edit');
                                    $("#btn-edit-surat").removeAttr("disabled");
                                }
                    });
    });

    $(document).on('click', '.delete_sppd', function() {

    if (confirm('Apakah anda yakin ingin menghapus data?')) {
        var id = $(this).attr('id_sppd');
        var id_st = $(this).attr('id_st');
        $.get('drop-sppd/' + id, function (data) {

          getDataEdit(id_st);
            var oTable = $('#table_surat_tugas').dataTable(); //inialisasi datatable
                oTable.fnDraw(false); //reset datatable

            Swal.fire({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                icon: 'success',
                title: 'Data berhasil dihapus'
                });
        });
    }  

    });

    $(document).on('click', '.btn_delete', function() {

      if (confirm('Apakah anda yakin ingin menghapus data surat tugas?')) {
          var id = $(this).data('id');
          $.get('drop-st/' + id, function (data) {
              var oTable = $('#table_surat_tugas').dataTable(); //inialisasi datatable
                  oTable.fnDraw(false); //reset datatable

              Swal.fire({
                  toast: true,
                  position: 'top-end',
                  showConfirmButton: false,
                  timer: 3000,
                  icon: 'success',
                  title: 'Data berhasil dihapus'
                  });
          });
      }  

      });
      var count = 1;
      $(document).on('click', '#tambah_pegawai', function() {
        count = count + 1;
        // var no_nota_atk = $("#no_nota_atk").val();
        var html_code = "<tr id='row" + count + "'>";
        html_code += ' <td><select name="pegawai_id_add[]" class="form-control select2bs4" required><option value="">-Pilih-</option><?php foreach($pegawai as $d): ?><option value="<?php echo e($d->id); ?>"><?php echo e($d->nama); ?></option><?php endforeach; ?></select></td>';

        html_code += '<td><button type="button" name="remove" data-row="row' + count + '" class="btn btn-danger btn-xs remove"><i class="fas fa-minus"></i></button></td>';

        html_code += "</tr>";

        $('#tb_pegawai_edit').append(html_code);

        $('.select2bs4').select2({
                    theme: 'bootstrap4',
                    tags: true,
                });
      });

      $(document).on('click', '.remove', function() {
      var delete_row = $(this).data("row");
      $('#' + delete_row).remove();
    });
    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master_st', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/surat_tugas/index.blade.php ENDPATH**/ ?>