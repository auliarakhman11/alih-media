

<?php $__env->startSection('content'); ?>
    <!-- Content -->



<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

      <div class="col-12 mb-4 order-0">

        <form action="<?php echo e(route('addChecker')); ?>" method="post">
          <?php echo csrf_field(); ?>

          <div class="card">
            <div class="card-header">
                <h5 class="float-start">Deatil Checker <?php echo e($checker ? $checker[0]->kd_gabungan : ''); ?></h5>
                <button type="submit" class="btn btn-primary float-end ml-2"><i class="bx bxs-save"></i> Save</button>
                <a href="<?php echo e(route('pdfDetailMasuk',$checker[0]->kd_gabungan)); ?>" target="_blank" class="btn btn-primary float-end mr-3 ml-3"><i class='bx bxs-file-pdf'></i> Print</a>
                
                <input type="hidden" name="kd_gabungan" value="<?php echo e($checker ? $checker[0]->kd_gabungan : ''); ?>">
            </div>
            
            <div class="card-body">

              <div class="table-responsive text-nowrap">
                <table class="table" width="100%">
                  <thead>
                    <tr>
                        <th>#</th>
                        <th>Barang</th>
                        <th>Lokasi</th>
                        <th>QTY</th>                                       
                        <th>Terima</th>
                        <th width="20%">Ket</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $checker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($index+1); ?></td>
                    <td><?php echo e($c->barang->nm_barang); ?></td>
                    <td><?php echo e($c->block->nm_block); ?><br><?php echo e($c->cell->nm_cell); ?><br><?php echo e($c->rak->nm_rak); ?><br><?php echo e($c->pallet->nm_pallet); ?></td>
                    <td><?php echo e($c->debit_box); ?> Box<br><?php echo e($c->debit_pak); ?> Pak<br><?php echo e($c->debit_kg); ?> KG</td>           
                    <td><div class="form-check form-switch mb-2">
                        <input class="form-check-input terima" name="terima[]" checker_id="<?php echo e($c->id); ?>" value="<?php echo e($c->id); ?>" type="checkbox">
                      </div>
                    </td>
                    <td>
                        <textarea class="form-control" rows="3" cols="5" name="ket_checker[]" id="ket_<?php echo e($c->id); ?>" required></textarea>
                        <input type="hidden" id="tolak_<?php echo e($c->id); ?>" name="tolak[]" value="<?php echo e($c->id); ?>">
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>

            </div>
            
          </div>
        </form>
        
        


      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->

  
  

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {


          <?php if(session('success')): ?>
          Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    icon: 'success',
                    title: '<?= session('success'); ?>'
                  });            
          <?php endif; ?>

          <?php if(session('error_kota')): ?>
          Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    icon: 'error',
                    title: "<?php echo e(session('error_kota')); ?>"
                  });            
          <?php endif; ?>

          <?php if($errors->any()): ?>
          Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    icon: 'error',
                    title: ' Ada data yang tidak sesuai, periksa kembali'
                  });            
          <?php endif; ?>


          $(document).on('change', '.terima', function() {
                if ($(this).is(':checked')) {

                  var checker_id = $(this).attr("checker_id");
                    $("#ket_"+checker_id).attr('disabled',true);
                    $("#tolak_"+checker_id).attr('disabled',true);

                } else {
                  
                  var checker_id = $(this).attr("checker_id");
                    $("#ket_"+checker_id).removeAttr("disabled");
                    $("#tolak_"+checker_id).removeAttr("disabled");

                }
              

            });


            
        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\aplikasilayout\resources\views/stok_masuk/detail_masuk.blade.php ENDPATH**/ ?>