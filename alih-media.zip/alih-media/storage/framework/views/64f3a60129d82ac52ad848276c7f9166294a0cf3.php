<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>
        
        .hurufT {
            font-family: 'Times New Roman';
            font-size: 13px;
        }
        
        table, td, th {
        border: 1px solid;
        }
    
        table {
        border-collapse: collapse;
        }
        </style>
</head>
<body>
    <div class="content">
        <center><h4><b>PENILAIAN KINERJA PEGAWAI PEMERINTAH NON PEGAWAI NEGERI <br> ASPEK SIKAP PERILAKU</b></h4></center>
    <br>
    <table style="border: none;"">
        <tr>
            <td style="border: none;">Nama PPNPN</td>
            <td style="border: none;">: &nbsp;&nbsp; <?php echo e($dt_penilaian[0]->pegawai->nama); ?></td>
        </tr>
        <tr>
            <td style="border: none;">Jabatan</td>
            <td style="border: none;">: &nbsp;&nbsp; <?php echo e($dt_penilaian[0]->pegawai->jabatan); ?></td>
        </tr>
        <tr>
            <td style="border: none;" colspan="2">Jangka Waktu Penilaian</td>
        </tr>
        <tr>
            <td style="border: none;" colspan="2">02 Januari 2022 s/d 30 November 2022</td>
        </tr>
    </table>
    <br>

    <table width="100%">
        <thead>
            <tr>
                <th width="5%">NO</th>
                <th width="35%">SASARAN KERJA</th>
                <th width="20%">SUB BOBOT</th>
                <th width="20%">NILAI</th>
                <th width="20%">TOTAL</th>
            </tr>
            <tr>
                <th style="background-color: grey; font-size: 10px;">(1)</th>
                <th style="background-color: grey; font-size: 10px;">(2)</th>
                <th style="background-color: grey; font-size: 10px;">(3)</th>
                <th style="background-color: grey; font-size: 10px;">(4)</th>
                <th style="background-color: grey; font-size: 10px;">(5)=(3)x(4)</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i = 1;
                $tnilai = 0;
                $tbobot = 0;
                $ttotal = 0;
            ?>
            <?php for($count = 0; $count<count($dt_penilaian); $count++): ?>
            <tr>
                <td style="text-align:center; height: 40px;"><?php echo e($i++); ?></td>
                <td style="height: 40px;"><?php echo e($dt_penilaian[$count]->pertanyaanAspek->sasaran_kerja); ?></td>
                <td style="text-align:center; height: 40px;"><?php echo e($dt_penilaian[$count]->bobot); ?>%</td>
                <td style="text-align:center; height: 40px;"><?php echo e(($dt_penilaian[$count]->nilai + $dt_penilaian2[$count]->nilai)/2); ?></td>
                <td style="text-align:center; height: 40px;"><?php echo e(($dt_penilaian[$count]->total_nilai + $dt_penilaian2[$count]->total_nilai)/2); ?></td>
            </tr>
            <?php
                $tnilai += ($dt_penilaian[$count]->nilai + $dt_penilaian2[$count]->nilai)/2;
                $tbobot += $dt_penilaian[$count]->bobot;
                $ttotal += ($dt_penilaian[$count]->total_nilai + $dt_penilaian2[$count]->total_nilai)/2;
            ?>
            <?php endfor; ?>
            
            <tr>
                <td style="text-align:center; height: 40px;"></td>
                <td style="height: 40px;"><b>TOTAL</b></td>
                <td style="text-align:center; height: 40px;"><b><?php echo e($tbobot); ?>%</b></td>
                <td style="text-align:center; height: 40px;"><b><?php echo e($tnilai); ?></b></td>
                <td style="text-align:center; height: 40px;"><b><?php echo e($ttotal); ?></b></td>
            </tr>
            
        </tbody>
    </table>

    <br>
    <br>

    <div class="ttd" style="float: right;">
        <table style="border: none; margin-right: 30px;">
            <tr>
                <td style="text-align: center; border: none;">Martapura, <?php echo e($tanggal); ?></td>
            </tr>
            <tr>
                <td style="text-align: center; border: none;"><?php echo e($perihal); ?></td>
            </tr>
            
            <?php if($dt_penilaian[0]->user->tanda_tangan): ?>
            <tr>
                <td style="border:none;"><center><img src="<?php echo e(public_path('tanda_tangan')); ?>/<?php echo e($dt_penilaian[0]->user->tanda_tangan); ?>" alt="" width="100px;"></center></td>
            </tr>
            <?php else: ?>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <tr>
                <td style="color: white; border: none;">space</td>
            </tr>
            <?php endif; ?>

            <?php if($jenis): ?>
            <tr>
                <td style="text-align: center; border: none;"><?php echo e($dt_penilaian[0]->pegawai->kasi->name); ?></td>
            </tr>
            <tr>
                <td style="text-align: center; border: none;"><?php echo e($dt_penilaian[0]->pegawai->kasi->nip); ?></td>
            </tr>
            <?php else: ?>
            <tr>
                <td style="text-align: center; border: none;"><?php echo e($dt_penilaian[0]->user->name); ?></td>
            </tr>
            <tr>
                <td style="text-align: center; border: none;"><?php echo e($dt_penilaian[0]->user->nip); ?></td>
            </tr>
            <?php endif; ?>
            
        </table>
        
    </div>

    </div>
</body>
</html><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/administrator/pdfSikapPerilaku3.blade.php ENDPATH**/ ?>