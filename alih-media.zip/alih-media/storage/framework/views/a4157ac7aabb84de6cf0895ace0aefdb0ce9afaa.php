

<?php $__env->startSection('content'); ?>


<!-- Content -->



<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">

    <div class="col-12 mb-4 order-0">
      
      <div class="card">
          <div class="card-header">
              <h5 class="float-start">Input Stok Masuk</h5>
              
          </div>
          
          <div class="card-body">

            <form id="form_input_stok_masuk">
              <div class="row">

                <div class="col-4">
                  <div class="form-group">
                    <label for="">Tanggal</label>
                    <input type="date" name="tgl" class="form-control" required>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Barang</label>
                    <select name="barang_id" class="form-control select2bs4" required>
                      <option value="">Pilih Barang</option>
                      <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($b->id); ?>|<?php echo e($b->nm_barang); ?>"><?php echo e($b->nm_barang); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Exprired Date</label>
                    <input type="date" name="tgl_exp" class="form-control"  required>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Jumlah Box</label>
                    <input type="number" name="debit_box" class="form-control" id="debit_box" required>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Jumlah PAK</label>
                    <input type="number" name="debit_pak" class="form-control" id="debit_pak" required>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Jumlah KG</label>
                    <input type="number" name="debit_kg" class="form-control" id="debit_kg" required>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Block</label>
                    <select name="block_id" class="form-control" id="block">
                      <option value="">Pilih Block</option>
                      <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($b->id); ?>|<?php echo e($b->nm_block); ?>"><?php echo e($b->nm_block); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Cell</label>
                    <select name="cell_id" class="form-control" id="cell">
                      <option value="">Pilih Cell</option>
                    </select>
                  </div>
                </div>
  
                <div class="col-4">
                  <div class="form-group">
                    <label for="">Rak</label>
                    <select name="rak_id" class="form-control" id="rak">
                      <option value="">Pilih Rak</option>
                    </select>
                  </div>
                </div>

                <div class="col-6 mb-2 mt-2"></div>
  
                <div class="col-6 mb-2 mt-2">
                  <button type="submit" id="btn_add_cart" class="btn btn-sm btn-primary float-end">
                    <i class='bx bxs-right-arrow-circle'></i> Lanjut
                  </button>
                </div>
                
              </div>
            </form>

          </div>
          
        </div>

        <div class="card">
          <div class="card-header">
              <h5 class="float-start">Batch Stok Masuk</h5>
              
          </div>
          <div class="card-body" id="cart">

          </div>
          <div class="card-footer">
            <button type="button" id="btn_input_data" class="btn btn-sm btn-primary float-end"><i class="bx bxs-save"></i> Input Stok</button>
          </div>
        </div>


    </div>

    <!-- Total Revenue -->

    <!--/ Total Revenue -->
    
  </div>

</div>
<!-- / Content -->

    

  <!-- Modal -->


<form id="form_input_penilaian">
  <div class="modal fade" id="input_penilaian" tabindex="-1" aria-labelledby="input_penilaianLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="input_penilaianLabel">Input Penilaian <span id="nm_pegawai_input"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
  
          
  
          
  
          
          
          
  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_simpan_penilaian">Simpan</button>
        </div>
      </div>
    </div>
  </div>
</form>





  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

            <?php if(session('success')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: '<?= session('success'); ?>'
            });            
            <?php endif; ?>

            <?php if(session('error')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: '<?= session('error'); ?>'
            });            
            <?php endif; ?>

            function getCart() {
              $.get('get-cart-masuk', function (data) {        
                  $('#cart').html(data);
                });
            }

            getCart();

            $(document).on('change', '#block', function() {
              var block_id = $(this).val();
              $('#cell').html('');
              $.get('get-cell/'+block_id, function (data) {        
                  $('#cell').html(data);
                });

            });

            $(document).on('change', '#cell', function() {
              var cell_id = $(this).val();
              $('#rak').html('');
              $.get('get-rak/'+cell_id, function (data) {        
                  $('#rak').html(data);
                });

            });

            $(document).on('click', '.btn_hapus_cart', function() {
              var id = $(this).attr('cart_id');

              $.get('delete-cart-masuk/'+id, function (data) {        
                  getCart();
                });

            });

            $(document).on('click', '#btn_input_data', function() {

              $.get('save-stok-masuk', function (data) {        
                  getCart();

                  Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Stok Masuk Berhasil Diinput'
                                });

                });

            });

            

            

            $(document).on('submit', '#form_input_stok_masuk', function(event) {
                event.preventDefault();

                    $('#btn_add_cart').attr('disabled',true);
                    $('#btn_add_cart').html('Loading..');

                    
                    $.ajax({
                        url:"<?php echo e(route('addCartMasuk')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            
                            
                            $('#btn_add_cart').html('<i class="bx bxs-right-arrow-circle"></i> Lanjut'); //tombol
                            getCart();
 
                            
                            $('.select2bs4').val('');
                            $('.select2bs4').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                            $("#debit_box").val('');
                            $("#debit_pak").val('');
                            $("#debit_kg").val('');

                            $("#block").val('');

                            $("#cell").html('<option value="">Pilih Cell</option>');
                            $("#rak").html('<option value="">Pilih Rak</option>');

                            Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data Berhasil Diinput'
                                });
                                                        
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    alert('Error:', data);
                                    $("#btn_add_cart").removeAttr("disabled");
                            $('#btn_add_cart').html('<i class="bx bxs-right-arrow-circle"></i> Lanjut'); //tombol
                                }
                    });

                });


        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\warehouse\resources\views/stok_masuk/input_stok_masuk.blade.php ENDPATH**/ ?>