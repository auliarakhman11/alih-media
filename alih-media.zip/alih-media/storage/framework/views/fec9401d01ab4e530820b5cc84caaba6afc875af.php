<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <div class="app-brand demo">
    <a href="" class="app-brand-link">
      <span class="app-brand-logo demo">
        <img src="<?php echo e(asset('img')); ?>/cp.jpeg" alt="" width="30"
        viewBox="0 0 25 42"
        version="1.1">

        
          
      </span>
      <span class="demo menu-text fw-bolder ms-2">PT. CHAROEN POKPHAND INDONESIA</span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
      <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    


  

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text"><i class='bx bxs-user-pin'></i> <?php echo e(Auth::user()->name); ?></span>
    </li>

    <li class="menu-item <?php echo e(Request::is(['data-block']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bx-line-chart"></i>
        <div data-i18n="Dashboard">Dashboard</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('data-block') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('dataBlock')); ?>" class="menu-link">
            <div data-i18n="Data Block">Data Block</div>
          </a>
        </li>



      </ul>
    </li>

    <li class="menu-item <?php echo e(Request::is(['input-stok-masuk','checker-masuk']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-package"></i>
        <div data-i18n="Penerimaan">Penerimaan</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('input-stok-masuk') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('inputStokMasuk')); ?>" class="menu-link">
            <div data-i18n="Input Stok Masuk">Input Stok Masuk</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('checker-masuk') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('checkerMasuk')); ?>" class="menu-link">
            <div data-i18n="Checker">Checker</div>
          </a>
        </li>


      </ul>
    </li>

    <li class="menu-item <?php echo e(Request::is(['input-stok-Keluar']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-truck"></i>
        <div data-i18n="Pendistribusian">Pendistribusian</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('input-stok-Keluar') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('inputStokKeluar')); ?>" class="menu-link">
            <div data-i18n="Input Stok Keluar">Input Stok Keluar</div>
          </a>
        </li>


      </ul>
    </li>

    <li class="menu-item <?php echo e(Request::is(['user','barang','mitra']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bxs-data"></i>
        <div data-i18n="Data Master">Data Master</div>
      </a>
      <ul class="menu-sub">

        <li class="menu-item <?php echo e(Request::is('barang') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('barang')); ?>" class="menu-link">
            <div data-i18n="Data Barang">Data Barang</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('user') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('user')); ?>" class="menu-link">
            <div data-i18n="Data User">Data User</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('mitra') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('mitra')); ?>" class="menu-link">
            <div data-i18n="Data mitra">Data mitra</div>
          </a>
        </li>

      </ul>
    </li>

    


    

    <li class="menu-item">
      <a href="<?php echo e(route('logout')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-log-out-circle'></i>
        <div data-i18n="Analytics">Logout</div>
      </a>
    </li>

    




  </ul>
</aside><?php /**PATH D:\programming\Laravel\warehouse\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>