<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">

            <div class="col-12">
                <div class="card">
                  
                    <div class="card-header">
                        <h4 class="float-left">Tunjangan Kinerja</h4>
                        
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('importTukin')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-4">
                                <div class="form-group">
                                    <label for="">Bulan</label>
                                    <select name="bulan" class="form-control select2bs4" required>
                                        <option value="">Pilih Bulan</option>
                                        <option value="01">Januari</option>
                                        <option value="02">Februari</option>
                                        <option value="03">Maret</option>
                                        <option value="04">April</option>
                                        <option value="05">Mei</option>
                                        <option value="06">Juni</option>
                                        <option value="07">Juli</option>
                                        <option value="08">Agustus</option>
                                        <option value="09">September</option>
                                        <option value="10">Oktober</option>
                                        <option value="11">November</option>
                                        <option value="12">Desember</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="form-group">
                                    <label for="">Tahun</label>
                                    <input type="number" class="form-control" name="tahun" required>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="form-group">
                                    <label for="">File</label>
                                    <input type="file" class="form-control" name="file_excel" required>
                                </div>
                            </div>

                            <div class="col-2 mt-2">
                              <a href="#modal_urutan_pegawai" data-toggle="modal" class="btn btn-sm btn-info mt-4">Cek Urutan</a>
                                <button type="submit" class="btn btn-sm btn-primary mt-4">Import</button>

                            </div>

                        </div>
                    </form>
                    </div>
                </div>

                <div class="card">
                  <div class="card-header">
                    <h5>List Tunjangan</h5>
                  </div>
                  <div class="card-body">
                    <div class="table-resposive">
                      <table class="table table-sm" id="table_tukin">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Bulan</th>
                            <th>Jumlah Pegawai</th>
                            <th>Jumlah Tunjangan</th>
                            <th>Jumlah Potongan</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                      </table>
                    </div>
                  </div>
                </div>

            </div>


        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <style>
    .scroll {
      height:400px;
      overflow-y: scroll;
    }

    .th-atas {
			top: 0px;
      background: white;
		}
  </style>
          
    <div class="modal fade" id="modal_urutan_pegawai" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Urutan Pegawai</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <table class="table table-sm">
                  <thead>
                    <tr>
                      <th>Urutan</th>
                      <th>Pegawai</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($i + 1); ?></td>
                          <td><?php echo e($d->nama); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
<form id="form_detail_tukin">
    <div class="modal fade" id="modal_detail_tukin" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Detail Tunjangan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body" id="dt_detail_tunjangan">
                
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" id="btn_edit_absen" class="btn btn-primary" >Edit</button>
            </div>
        </div>
        </div>
    </div>
</form>

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {

    $(document).on('click', '.detail_tukin', function() {
            var id = $(this).data('id');
            var id_pegawai = $(this).attr('id_pegawai');

            if(id_pegawai){
              $.get('get-detail-tunjangan1/' + id + '/' + id_pegawai, function (data) {
                $('#table_detail_tukin').html(data);
              });
            }else{
              $.get('get-detail-tunjangan/' + id , function (data) {
                  $('#dt_detail_tunjangan').html(data);
              });
            }

            
        });
    
    $('#table_tukin').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getListTukin')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'bulan',
                        name: 'bulan'
                    },  
                    {
                        data: 'jml_pegawai',
                        name: 'jml_pegawai'
                    },
                    {
                        data: 'jumlah_tunjangan',
                        name: 'jumlah_tunjangan'
                    },
                    {
                        data: 'jumlah_potongan',
                        name: 'jumlah_potongan'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: [
                    [0, 'asc']
                ]
            });

            $(document).on('submit', '#form_detail_tukin', function(event) {
                event.preventDefault();
                    $('#btn_edit_absen').attr('disabled',true);
                    $('#btn_edit_absen').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editDetailAbsen')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_edit_absen").removeAttr("disabled");
                                $('#btn_edit_absen').html('Edit'); //tombol simpan

                                $.get('get-detail-tunjangan1/' + data.id + '/' + data.id_pegawai, function (dt) {
                                  $('#table_detail_tukin').html(dt);
                                });

                                var oTable = $('#table_tukin').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_edit_absen').html('Edit');
                                $("#btn_edit_absen").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_edit_absen').html('Edit');
                                    $("#btn_edit_absen").removeAttr("disabled");
                                }
                    });
            });

    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/tukin/index.blade.php ENDPATH**/ ?>