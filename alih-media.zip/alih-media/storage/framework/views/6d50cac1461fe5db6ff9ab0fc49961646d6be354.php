<?php if($berkas): ?>
<div class="row">
    <div class="col-12 col-md-6 mt-2">
        <table width="100%">
            <tr>
                <td><b>Kecamatan</b></td>
                <td><b>:</b></td>
                <td><b><?php echo e($berkas->kecamatan->nm_kecamatan); ?></b></td>
            </tr>
            <tr>
                <td><b>Kelurahan</b></td>
                <td><b>:</b></td>
                <td><b><?php echo e($berkas->kelurahan->nm_kelurahan); ?></b></td>
            </tr>
            <tr>
                <td><b>Nomor Hak</b></td>
                <td><b>:</b></td>
                <td><b><?php echo e($berkas->jenis_hak->kode_hak); ?> - <?php echo e($berkas->no_hak); ?></b></td>
            </tr>
            <tr>
                <td><b>Peta</b></td>
                <td><b>:</b></td>
                <td><b> 
                    <?php if($berkas->jenis_peta): ?>
                    <?php echo e($berkas->jenis_peta->nm_jenis_peta); ?> - <?php echo e($berkas->no_peta); ?>/<?php echo e($berkas->tahun_peta); ?>

                    <?php else: ?>
                        -
                    <?php endif; ?>
                    
                </b></td>
            </tr>
            <tr>
                <td><b>NIB</b></td>
                <td><b>:</b></td>
                <td><b><?php echo e($berkas->nib ? $berkas->nib : '-'); ?></b></td>
            </tr>
            <tr>
                <td colspan="3">
                    <?php if($berkas->selesai != 2 && Auth::id() == 1 || Auth::id() == 29): ?>
                    
                    <button class="btn btn-primary mt-2" id="btn_tutup_berkas" berkas_id="<?php echo e($berkas->id); ?>" type="button">Tutup Berkas</button>
                    <?php else: ?>
                    <p class="text-danger"><strong>Berkas Sudah Ditutup!</strong></p>
                    <?php endif; ?>
                    
                </td>
            </tr>
        </table>
    </div>

    <div class="col-12 col-md-6 mt-2">
        <?php
            $dtProses
        ?>
        <?php $__currentLoopData = $berkas->history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $dtProses [] = $a->proses_id
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <table class="table table-sm" width="100%">
            <thead>
                <tr class="text-center">
                    <th><b>Proses</b></th>
                    <th><b>Status</b></th>
                    <th><b>Petugas</b></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dt_proses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p['nm_proses']); ?></td>
                    <td>
                        <?php if($p['ada'] && $p['selesai']): ?>
                        <button type="button" class="btn-success btn-xs btn-rounded"><i class='bx bxs-check-circle'></i> Selesai</button>
                        <?php elseif($p['ada'] && !$p['selesai']): ?>
                        <button type="button" class="btn-warning btn-xs btn-rounded"><i class='bx bx-loader'></i> Proses</button>
                        <?php else: ?>
                        <button type="button" class="btn-primary btn-xs btn-rounded"><i class='bx bxs-x-circle'></i> Belum</button>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($p['petugas']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
    </div>

</div>
<?php else: ?>
    <h3>Berkas tidak ditemukan</h3>
<?php endif; ?><?php /**PATH /home/u1721841/alih-media/resources/views/laporan/dt_info_berkas.blade.php ENDPATH**/ ?>