<div class="row">
    <div class="col-12">
        <div class="form-group">
            <div class="form-floating">
                <input type="hidden" name="history_id" value="<?php echo e($history_id); ?>">
                <textarea class="form-control" placeholder="Masukan keterangan disini" name="ket"><?php echo e($dt_history->ket); ?></textarea>
                <label for="floatingTextarea">Keterangan</label>
              </div>
            
        </div>
    </div>

    <div class="col-12 mt-2">
        <h4>List Keterangan</h4>
        <table class="table table-sm mt-2">
            <thead>
                <tr>
                    <th>Proses</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dt_berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($d->proses->nm_proses); ?></td>
                        <td><?php echo e($d->ket); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH /home/u1721841/alih-media/resources/views/berkas/get_keterangan.blade.php ENDPATH**/ ?>