<div class="row">
<input type="hidden" name="id" value="<?php echo e($stok->id); ?>">
    <div class="col-4">
        <div class="form-group">
          <label for="">Barang</label>
          <select name="barang_id" class="form-control select2bs4" required>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>" <?php echo e($stok->barang_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->nm_barang); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="col-4">
        <div class="form-group">
          <label for="">Exprired Date</label>
          <input type="date" name="tgl_exp" class="form-control" value="<?php echo e($stok->tgl_exp); ?>"  required>
        </div>
      </div>

      <div class="col-4"></div>

      <div class="mt-2 col-6 col-md-3">
        <div class="form-group">
          <label for="">Block</label>
          <select name="block_id" class="form-control" id="block" required>
            <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>" <?php echo e($stok->block_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->nm_block); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="mt-2 col-6 col-md-3">
        <div class="form-group">
          <label for="">Cell</label>
          <select name="cell_id" class="form-control" id="cell" required>
            <?php $__currentLoopData = $cell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>" <?php echo e($stok->cell_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->nm_cell); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="mt-2 col-6 col-md-3">
        <div class="form-group">
          <label for="">Lantai</label>
          <select name="rak_id" class="form-control" id="rak" required>
            <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>" <?php echo e($stok->rak_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->nm_rak); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="mt-2 col-6 col-md-3">
        <div class="form-group">
          <label for="">Pallet</label>
          <select name="pallet_id" class="form-control" id="pallet" required>
            <?php $__currentLoopData = $pallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>" <?php echo e($stok->pallet_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->nm_pallet); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="col-4 mt-2">
        <div class="form-group">
          <label for="">Jumlah Box</label>
          <input type="number" name="debit_box" class="form-control" value="<?php echo e($stok->debit_box); ?>" required>
        </div>
      </div>

      <div class="mt-2 col-4">
        <div class="form-group">
          <label for="">Jumlah PAK</label>
          <input type="number" name="debit_pak" class="form-control" value="<?php echo e($stok->debit_pak); ?>" required>
        </div>
      </div>

      <div class="mt-2 col-4">
        <div class="form-group">
          <label for="">Jumlah KG</label>
          <input type="number" name="debit_kg" class="form-control" value="<?php echo e($stok->debit_kg); ?>" required>
        </div>
      </div>

</div><?php /**PATH /home/u376106710/domains/cpibandung.com/aplikasilayout/resources/views/stok_masuk/get_stok_masuk.blade.php ENDPATH**/ ?>