<div class="row">
    <?php $__currentLoopData = $dashboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-3">

        <p><i class="fas fa-dot-circle text-info"></i> <?php echo e(ucwords($d->jenis_history)); ?> : <?php echo e($d->jml); ?></p>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

</div><?php /**PATH /media/rahman/DATA D1/Programming/laravel/arsip/resources/views/peminjaman/dashboard.blade.php ENDPATH**/ ?>