<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table border="solid 1px">
        <thead>
            <tr>
                <th>Nama</th>
                <?php $__currentLoopData = $jml_jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($p->sasaran_kerja); ?> <?php echo e($jj->jenisPenilai->nm_jenis); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th>Total</th>
                <th>Penilai</th>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pg->nama); ?></td>

                
                                    
                    <?php $__currentLoopData = $jml_jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $total = 0;
                    $penilai = '';
                    
                    ?>
                    
                    

                        <?php $__currentLoopData = $pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $ada = 0;
                        ?>
                            <?php $__currentLoopData = $dt_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($dp->pegawai_id == $pg->id && $dp->jenis_penilai == $jj->jenis_penilai && $dp->pertanyaan_id == $p->id): ?>
                                <td><?php echo e($dp->nilai); ?></td>
                                <?php
                                    $total += $dp->nilai;
                                    $penilai = $dp->user->name;
                                    $ada ++;
                                ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ada <= 0): ?>
                            <td>Belum Diisi</td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        

                        
                        <td><?php echo e($total); ?></td>
                        <td><?php echo e($penilai); ?></td>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/administrator/test_export.blade.php ENDPATH**/ ?>