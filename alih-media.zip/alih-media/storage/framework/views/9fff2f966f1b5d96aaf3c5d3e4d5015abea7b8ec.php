<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <div class="app-brand demo">
    <a href="" class="app-brand-link">
      <span class="app-brand-logo demo">
        <img src="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png" alt="" width="30"
        viewBox="0 0 25 42"
        version="1.1">

        
          
      </span>
      
      <span class="demo menu-text fw-bolder ms-2" style="font-size: 11px;">Alih Media</span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
      <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    


  

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text"><i class='bx bxs-user-pin'></i> <?php echo e(Auth::user()->name); ?></span>
    </li>

      <li class="menu-item <?php echo e(Request::is(['berkas','list-berkas','buka-validasi']) ? 'active open' : ''); ?>">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bxs-folder-open"></i>
          <div data-i18n="Berkas">Berkas</div>
        </a>
        <ul class="menu-sub">


          <li class="menu-item <?php echo e(Request::is('berkas') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('berkas')); ?>" class="menu-link">
              <div data-i18n="Input Berkas">Input Berkas</div>
            </a>
          </li>

          <li class="menu-item <?php echo e(Request::is('list-berkas') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('listBerkas')); ?>" class="menu-link">
              <div data-i18n="List Berkas">List Berkas</div>
            </a>
          </li>

          

          
    

        </ul>
      </li>


    

    


    


    <li class="menu-item">
      <a href="<?php echo e(route('logout')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-log-out-circle'></i>
        <div data-i18n="Analytics">Logout</div>
      </a>
    </li>

    




  </ul>
</aside><?php /**PATH D:\programming\alih media\alih-media\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>