

<?php $__env->startSection('content'); ?>
    <!-- Content -->

<style>
    div.scroll_horizontal table {
        display: inline-block;
        
    }

    div.scroll_horizontal {
        overflow-y: scroll;
        overflow-x: auto;
        white-space: nowrap;
        height:500px;
    }

</style>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

      <div class="col-12 mb-4 order-0">
        
        <div class="card">
            <div class="card-header">
                <h5 class="float-start">Data Block</h5>
            </div>
            
            <div class="card-body">

              <div class="scroll_horizontal">
                
                <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table border="1px solid" style="font-size: 20px;">
                    <thead>
                        <tr>
                            <th style="background-color: tomato"><b><a href="#modal_detail_block" data-bs-toggle="modal" style="text-decoration: none; color: black;" class="btn_detail_block" block_id="<?php echo e($b->id); ?>"><?php echo e($b->nm_block); ?></a></b></th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $b->cell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="background-color: skyblue"><b><a href="#modal_detail_cell" data-bs-toggle="modal" style="text-decoration: none; color: black;" class="btn_detail_cell" cell_id="<?php echo e($c->id); ?>"><?php echo e($c->nm_cell); ?></a></b></td>
                        </tr>
                            <?php $__currentLoopData = $c->rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="#modal_detail_rak" data-bs-toggle="modal" style="text-decoration: none; color: black;" class="btn_detail_rak" rak_id="<?php echo e($r->id); ?>"><?php echo e($r->nm_rak); ?></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

              </div>

            </div>
            
          </div>



      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->

  <div class="modal fade" id="modal_detail_block" tabindex="-1" aria-labelledby="modal_detail_blockLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal_detail_blockLabel">Stok Block</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="table_detail_block">
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal_detail_cell" tabindex="-1" aria-labelledby="modal_detail_cellLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal_detail_cellLabel">Stok Cell</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="table_detail_cell">
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="modal_detail_rak" tabindex="-1" aria-labelledby="modal_detail_rakLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal_detail_rakLabel">Stok Lantai</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="table_detail_rak">
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>
  </div>

  
  

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {


          <?php if(session('success')): ?>
          Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    icon: 'success',
                    title: '<?= session('success'); ?>'
                  });            
          <?php endif; ?>

          <?php if(session('error_kota')): ?>
          Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    icon: 'error',
                    title: "<?php echo e(session('error_kota')); ?>"
                  });            
          <?php endif; ?>

          <?php if($errors->any()): ?>
          Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    icon: 'error',
                    title: ' Ada data yang tidak sesuai, periksa kembali'
                  });            
          <?php endif; ?>


          $(document).on('click', '.btn_detail_block', function() {
              var block_id = $(this).attr('block_id');

              $("#table_detail_block").html('<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>');
              
              $.get('detail-block/'+block_id, function (data) {        
                  $('#table_detail_block').html(data);
                });

            });

            $(document).on('click', '.btn_detail_cell', function() {
              var cell_id = $(this).attr('cell_id');

              $("#table_detail_cell").html('<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>');
              
              $.get('detail-cell/'+cell_id, function (data) {        
                  $('#table_detail_cell').html(data);
                });

            });

            $(document).on('click', '.btn_detail_rak', function() {
              var rak_id = $(this).attr('rak_id');

              $("#table_detail_rak").html('<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>');
              
              $.get('detail-rak/'+rak_id, function (data) {        
                  $('#table_detail_rak').html(data);
                });

            });


            
        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u376106710/domains/cpibandung.com/aplikasilayout/resources/views/dashboard/data_block.blade.php ENDPATH**/ ?>