<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <div class="app-brand demo">
    <a href="" class="app-brand-link">
      <span class="app-brand-logo demo">
        <img src="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png" alt="" width="30"
        viewBox="0 0 25 42"
        version="1.1">

        
          
      </span>
      
      <span class="demo menu-text fw-bolder ms-2" style="font-size: 11px;">Alih Media</span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
      <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    


  

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text"><i class='bx bxs-user-pin'></i> <?php echo e(Session::get('name')); ?></span>
    </li>

    <li class="menu-item <?php echo e(Request::is(['info-berkas','berkas-tunggakan','berkas-selesai','laporan-perhari','laporan-perproses']) ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class='menu-icon tf-icons bx bx-line-chart'></i>
        <div data-i18n="Laporan">Laporan</div>
      </a>
      <ul class="menu-sub">


        <li class="menu-item <?php echo e(Request::is('info-berkas') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('infoBerkas')); ?>" class="menu-link">
            <div data-i18n="Informasi Berkas">Informasi Berkas</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('berkas-tunggakan') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('berkasTunggakan')); ?>" class="menu-link">
            <div data-i18n="List Tunggakan">List Tunggakan</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('berkas-selesai') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('berkasSelesai')); ?>" class="menu-link">
            <div data-i18n="Berkas Selesai">Berkas Selesai</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('laporan-perhari') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('laporanPerhari')); ?>" class="menu-link">
            <div data-i18n="Laporan Perhari">Laporan Perhari</div>
          </a>
        </li>

        <li class="menu-item <?php echo e(Request::is('laporan-perproses') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('laporanPerproses')); ?>" class="menu-link">
            <div data-i18n="Laporan Perproses">Laporan Perproses</div>
          </a>
        </li>

      </ul>
    </li>

      <li class="menu-item <?php echo e(Request::is(['berkas','list-berkas','buka-validasi']) ? 'active open' : ''); ?>">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons bx bxs-folder-open"></i>
          <div data-i18n="Berkas">Berkas</div>
        </a>
        <ul class="menu-sub">


          <li class="menu-item <?php echo e(Request::is('berkas') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('berkas')); ?>" class="menu-link">
              <div data-i18n="Input Berkas">Input Berkas</div>
            </a>
          </li>

          <li class="menu-item <?php echo e(Request::is('list-berkas') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('listBerkas')); ?>" class="menu-link">
              <div data-i18n="List Berkas">List Berkas</div>
            </a>
          </li>

          

          
    

        </ul>
      </li>

      <?php if(Session::get('jenis_user_id') == 1): ?>
      <li class="menu-item <?php echo e(Request::is(['user']) ? 'active open' : ''); ?>">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class='menu-icon tf-icons bx bxs-book-content'></i>
          <div data-i18n="Data Master">Data Master</div>
        </a>
        <ul class="menu-sub">


          <li class="menu-item <?php echo e(Request::is('user') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('user')); ?>" class="menu-link">
              <div data-i18n="Data User">Data User</div>
            </a>
          </li>

        </ul>
      </li>
      <?php endif; ?>
    
      

      


    

    

    <li class="menu-item">
      <a href="<?php echo e(route('gantiPassword')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-key'></i>
        <div data-i18n="Analytics">Ganti Password</div>
      </a>
    </li>

    <li class="menu-item">
      <a href="<?php echo e(route('logout')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-log-out-circle'></i>
        <div data-i18n="Analytics">Logout</div>
      </a>
    </li>

    

    




  </ul>
</aside><?php /**PATH /home/u1721841/alih-media/resources/views/template/_sidebar.blade.php ENDPATH**/ ?>