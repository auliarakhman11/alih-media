<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
  <div class="app-brand demo">
    <a href="" class="app-brand-link">
      <span class="app-brand-logo demo">
        <img src="<?php echo e(asset('img')); ?>/cp.jpeg" alt="" width="30"
        viewBox="0 0 25 42"
        version="1.1">

        
          
      </span>
      
      <span class="demo menu-text fw-bolder ms-2" style="font-size: 11px;">PT CHAROEN POKHPAND INDONESIA PLANT BANDUNG WAREHOUSE <?php echo e(Session::get('nm_gudang')); ?></span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
      <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    <!-- Dashboard -->
    


  

    <li class="menu-header small text-uppercase">
      <span class="menu-header-text"><i class='bx bxs-user-pin'></i> <?php echo e(Auth::user()->name); ?></span>
    </li>

    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
          $dt_submenu = $submenu->where('menu_id',$m->id)->all();
          $dt_url = [];
          foreach ($dt_submenu as $s) {
            $dt_url [] = $s->url;
          }
      ?>
      <li class="menu-item <?php echo e(Request::is($dt_url) ? 'active open' : ''); ?>">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons <?php echo e($m->icon); ?>"></i>
          <div data-i18n="<?php echo e($m->nm_menu); ?>"><?php echo e($m->nm_menu); ?></div>
        </a>
        <ul class="menu-sub">

          <?php $__currentLoopData = $dt_submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item <?php echo e(Request::is($s->url) ? 'active' : ''); ?>">
            <a href="/<?php echo e($s->url); ?>" class="menu-link">
              <div data-i18n="<?php echo e($s->nm_submenu); ?>"><?php echo e($s->nm_submenu); ?></div>
            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          

        </ul>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

    


    

    <li class="menu-item">
      <a href="<?php echo e(route('menu')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-arrow-back'></i>
        <div data-i18n="Analytics">Ganti Warehouse</div>
      </a>
    </li>

    <li class="menu-item">
      <a href="<?php echo e(route('logout')); ?>" class="menu-link">
        <i class='menu-icon tf-icons bx bx-log-out-circle'></i>
        <div data-i18n="Analytics">Logout</div>
      </a>
    </li>

    




  </ul>
</aside><?php /**PATH D:\programming\Laravel\aplikasilayout\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>