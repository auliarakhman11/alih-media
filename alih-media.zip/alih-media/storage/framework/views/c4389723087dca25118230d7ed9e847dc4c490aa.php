<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">

            <div class="col-12">
                <div class="card">
                  
                    <div class="card-header">
                        <h4 class="float-left">Data Pegawai</h4>
                        <button type="button" id="btn-add-pegawai" class="btn btn-sm btn-primary float-right" data-toggle="modal" data-target="#modal-add-pegawai">
                            <i class="fas fa-plus-circle"></i> 
                            Tambah Pegawai
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm" id="table_pegawai" width="100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>NIP</th>
                                        <th>Nama</th>
                                        <th>Gol</th>
                                        <th>Eselon</th>
                                        <th>Jabatan</th>
                                        <th>Kordinator</th>
                                        <th>Jenis</th>
                                        <th>Keterangan</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <form id="form-add-pegawai">
    <div class="modal fade" id="modal-add-pegawai" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Pegawai</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    
                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">NIP</label>
                            <input type="text" class="form-control" name="nip" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                      <div class="form-group">
                          <label for="">Nama</label>
                          <input type="text" class="form-control" name="nama" required>
                      </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Gol</label>
                            
                            <select name="golongan_id" class="form-control select2bs4">
                                <option value="">-Pilih Golongan-</option>
                                <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->golongan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Eselon</label>
                            <input type="text" class="form-control" name="eselon" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Jabatan</label>
                            
                            <select name="jabatan_pegawai_id" class="form-control select2bs4">
                                <option value="">-Pilih Jabatan-</option>
                                <?php $__currentLoopData = $jabatan_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->jabatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Kordinator</label>
                            <input type="text" class="form-control" name="kordinator" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Kelas Jabatan</label>
                            
                            <select name="jabatan_id" class="form-control select2bs4">
                                <option value="">-Pilih Jabatan-</option>
                                <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->jabatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Jenis</label>
                            <select name="jenis" class="form-control" required>
                                <option value="">Pilih..</option>
                                <option value="ASN">ASN</option>
                                <option value="PPNPN">PPNPN</option>
                                <option value="ASK SUKWAN">ASK SUKWAN</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Keterangan</label>
                            <input type="text" class="form-control" name="keterangan" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">NPWP</label>
                            <input type="text" class="form-control" name="npwp" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Nama Rekening</label>
                            <input type="text" class="form-control" name="nm_rek" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">No Rekening</label>
                            <input type="text" class="form-control" name="no_rek" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <div class="form-group">
                            <label for="">Kode Post</label>
                            <input type="text" class="form-control" name="kode_pos" >
                        </div>
                    </div>

                    <div class="col-6 col-md-4">
                        <br>
                        <label for=""><input name="cpns" value="1" type="checkbox"> CPNS</label><br>
                        <label for=""><input name="tugas_belajar" value="1" type="checkbox"> Tugas Belajar</label>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn-input-pegawai">Tambah</button>
            </div>
        </div>
        </div>
    </div>
    </form>

    <form id="form-edit-pegawai">
        <div class="modal fade" id="modal-edit-pegawai" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                <h5 class="modal-title" id="exampleModalLabel">Edit Pegawai</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <input type="hidden" name="id" id="id_pegawai">
                        
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">NIP</label>
                                <input type="text" class="form-control" name="nip" id="nip">
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                          <div class="form-group">
                              <label for="">Nama</label>
                              <input type="text" class="form-control" name="nama" id="nama" required>
                          </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Gol</label>
                                
                                <select name="golongan_id" id="golongan_id" class="form-control select2bs4">
                                    <option value="">-Pilih Golongan-</option>
                                    <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->golongan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Eselon</label>
                                <input type="text" class="form-control" name="eselon" id="eselon" >
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Jabatan</label>
                                
                                <select name="jabatan_pegawai_id" id="jabatan_pegawai_id" class="form-control select2bs4">
                                    <option value="">-Pilih Jabatan-</option>
                                    <?php $__currentLoopData = $jabatan_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->jabatan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Kordinator</label>
                                <input type="text" class="form-control" name="kordinator" id="kordinator" >
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Jenis</label>
                                <select name="jenis" class="form-control" id="jenis" required>
                                    <option value="">Pilih..</option>
                                    <option value="ASN">ASN</option>
                                    <option value="PPNPN">PPNPN</option>
                                    <option value="ASK SUKWAN">ASK SUKWAN</option>
                                </select>
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Keterangan</label>
                                <input type="text" class="form-control" name="keterangan" id="keterangan" >
                            </div>
                        </div>


                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">NPWP</label>
                                <input type="text" class="form-control" name="npwp" id="npwp">
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Nama Rekening</label>
                                <input type="text" class="form-control" name="nm_rek" id="nm_rek" >
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">No Rekening</label>
                                <input type="text" class="form-control" name="no_rek" id="no_rek" >
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <div class="form-group">
                                <label for="">Kode Post</label>
                                <input type="text" class="form-control" name="kode_pos" id="kode_pos" >
                            </div>
                        </div>
    
                        <div class="col-6 col-md-4">
                            <br>
                            <label for=""><input name="cpns" id="cpns" value="1" type="checkbox"> CPNS</label><br>
                            <label for=""><input name="tugas_belajar" id="tugas_belajar" value="1" type="checkbox"> Tugas Belajar</label>
                        </div>
    
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="btn-edit-pegawai">Edit</button>
                </div>
            </div>
            </div>
        </div>
        </form>

          

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {
    
    $('#table_pegawai').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getDataPegawai')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'nip',
                        name: 'nip'
                    },  
                    {
                        data: 'nama',
                        name: 'nama'
                    },
                    {
                        data: 'dt_golongan',
                        name: 'dt_golongan'
                    },
                    {
                        data: 'eselon',
                        name: 'eselon'
                    },
                    {
                        data: 'jabatan_pegawai',
                        name: 'jabatan_pegawai'
                    },
                    {
                        data: 'kordinator',
                        name: 'kordinator'
                    },
                    {
                        data: 'jenis',
                        name: 'jenis'
                    },
                    {
                        data: 'keterangan',
                        name: 'keterangan'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    }
                ],
                order: [
                    [0, 'asc']
                ]
            });

        $(document).on('click', '.edit_pegawai', function() {
            var id = $(this).data('id');

            // console.log(id);
            
            $.get('get-pegawai/' + id, function (data) {
                //set value masing-masing id berdasarkan data yg diperoleh dari ajax get request diatas               
                $('#id_pegawai').val(data.id);
                $('#nip').val(data.nip);
                $('#nama').val(data.nama);
                $('#gol').val(data.gol);
                $('#eselon').val(data.eselon);
                $('#jabatan').val(data.jabatan);
                $('#kordinator').val(data.kordinator);
                $('#jenis').val(data.jenis);
                $('#keterangan').val(data.keterangan);

                $('#npwp').val(data.npwp);
                $('#nm_rek').val(data.nm_rek);
                $('#no_rek').val(data.no_rek);
                $('#kode_pos').val(data.kode_pos);

                $('#jabatan_id').val(data.jabatan_id);
                $('#jabatan_id').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                $('#jabatan_pegawai_id').val(data.jabatan_pegawai_id);
                $('#jabatan_pegawai_id').select2({theme: 'bootstrap4', tags: true,}).trigger('change');
                
                $('#golongan_id').val(data.golongan_id);
                $('#golongan_id').select2({theme: 'bootstrap4', tags: true,}).trigger('change');

                if(data.cpns){
                    $('#cpns').prop('checked', true);
                }else{
                    $('#cpns').prop('checked', false);
                }

                if(data.tugas_belajar){
                    $('#tugas_belajar').prop('checked', true);
                }else{
                    $('#tugas_belajar').prop('checked', false);
                }

                
            });
        });

        $(document).on('submit', '#form-add-pegawai', function(event) {
                event.preventDefault();
                    $('#btn-input-pegawai').attr('disabled',true);
                    $('#btn-input-pegawai').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addPegawai')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            
                            if(data){
                                $('#form-add-pegawai').trigger('reset');
                                $('#modal-add-pegawai').modal('hide'); //modal hide
                                $("#btn-input-pegawai").removeAttr("disabled");
                                $('#btn-input-pegawai').html('Tambah'); //tombol simpan

                                var oTable = $('#table_pegawai').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable
                                
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Nama pegawai sudah ada'
                                });
                                $('#btn-input-pegawai').html('Tambah');
                                $("#btn-input-pegawai").removeAttr("disabled");
                            }
                                                        
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log(data);
                                    $('#btn-input-pegawai').html('Tambah');
                                    $("#btn-input-pegawai").removeAttr("disabled");
                                }
                    });

                });

                $(document).on('submit', '#form-edit-pegawai', function(event) {
                event.preventDefault();
                    $('#btn-edit-pegawai').attr('disabled',true);
                    $('#btn-edit-pegawai').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editPegawai')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            
                            if(data){
                                $('#form-edit-pegawai').trigger('reset');
                                $('#modal-edit-pegawai').modal('hide'); //modal hide
                                $("#btn-edit-pegawai").removeAttr("disabled");
                                $('#btn-edit-pegawai').html('Edit'); //tombol simpan

                                var oTable = $('#table_pegawai').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable
                                
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Nama pegawai sudah ada'
                                });
                                $('#btn-edit-pegawai').html('Edit');
                                $("#btn-edit-pegawai").removeAttr("disabled");
                            }
                                                        
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log(data);
                                    $('#btn-edit-pegawai').html('Edit');
                                    $("#btn-edit-pegawai").removeAttr("disabled");
                                }
                    });

                });

                $(document).on('click', '.delete_pegawai', function() {

                    if (confirm('Apakah anda yakin ingin menghapus pegawai?')) {
                        var id = $(this).data('id');
                        $.get('drop-pegawai/' + id, function (data) {
                            var oTable = $('#table_pegawai').dataTable(); //inialisasi datatable
                                oTable.fnDraw(false); //reset datatable

                            Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil dihapus'
                                });
                        });
                    }  
                    
                });
    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/pegawai/index.blade.php ENDPATH**/ ?>