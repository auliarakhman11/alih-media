<table class="table table-sm text-center">
    <thead>
        <tr>
            <th>#</th>
            <th>Status</th>
            <th>Pelayanan</th>
            <th>Seksi</th>
            <th>Waktu</th>
            <th>User</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $i=1;
        ?>
        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($d->status); ?></td>
                <td><?php echo e($d->pelayanan->nm_pelayanan); ?></td>
                <td><?php echo e($d->seksi->nm_seksi); ?></td>
                <td><?php echo e(date("d-M-Y H:i", strtotime($d->created_at))); ?></td>
                <td><?php echo e($d->user->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /media/rahman/DATA D1/Programming/laravel/arsip/resources/views/peminjaman/history.blade.php ENDPATH**/ ?>