<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        table, th, td {
            border: 3px solid;
            border-collapse: collapse;
            font-size: 14px;
            }

            td {
                padding: 10px;
            }
    </style>
</head>
<body>
    <table>
        <tbody>            
        <?php $__currentLoopData = $cell->rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $r->pallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="font-size: 40px;"><b><?php echo e($cell->block->nm_block); ?></b></td>
                <td style="font-size: 40px;"><b><?php echo e($cell->nm_cell); ?></b></td>
                <td style="font-size: 40px;"><b><?php echo e($r->nm_rak); ?></b></td>
                <td style="font-size: 40px;"><b><?php echo e($p->nm_pallet); ?></b></td>
                <td><?php echo DNS2D::getBarcodeHTML("$p->id", 'QRCODE', '3','3'); ?></td>
                
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\programming\Laravel\aplikasilayout\resources\views/dashboard/generate_qr.blade.php ENDPATH**/ ?>