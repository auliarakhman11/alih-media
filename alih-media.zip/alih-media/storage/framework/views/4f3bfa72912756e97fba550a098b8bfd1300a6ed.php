

<?php $__env->startSection('content'); ?>


<!-- Content -->

<style>
    /* .blick {
        background-color: #ed1a3a;
    }
    .blink-soft {
        animation: blinker 1.5s linear infinite;
    }
    @keyframes blinker {
        50% {
            opacity: 0;
        }
    } */

    .blink {
        animation: blink 1.5s linear infinite;
    }

    @keyframes blink {
        0% {
            background-color: red;
            color: white;
        }
        50% {
            background-color: orange;
            color: white;
        }
        100% {
            background-color: rgb(223, 195, 9);
            color: white;
        }
    }

</style>



<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">

    <div class="col-12 mb-4 order-0">
      
      <div class="card">
          <div class="card-header">
              <h5 class="float-start">List Berkas</h5>
              
          </div>
          
          <div class="card-body">

            <div class="table-responsive">
                <table class="table table-sm text-center" width="100%" id="table_berkas" style="font-size: 12px;">
                  <thead>
                    <tr>
                      <th style="font-size: 10px;">#</th>
                      <th style="font-size: 10px;">Kecamatan</th>
                      <th style="font-size: 10px;">Kelurahan</th>
                      <th style="font-size: 10px;">Jenis Hak</th>
                      <th style="font-size: 10px;">No Hak</th>
                      <th style="font-size: 10px;">Nama Pemohonan</th>
                      <th style="font-size: 10px;">Peoses</th>
                      <th style="font-size: 10px;">Tanggal</th>
                      <th style="font-size: 10px;">Aksi</th>
                  </tr>
                  </thead>
                  <tbody></tbody>
                </table>
              </div>

          </div>
          
        </div>

        


    </div>

    <!-- Total Revenue -->

    <!--/ Total Revenue -->
    
  </div>

</div>
<!-- / Content -->

    

  <!-- Modal -->

    <div class="modal fade" id="modal_loading" tabindex="-1" aria-labelledby="modal_loadingLabel" aria-hidden="true" >
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          
          <div class="modal-body" >
            <div class="spinner-border text-danger" role="status"><span class="visually-hidden">Loading...</span></div> Loading...
          </div>

        </div>
      </div>
    </div>
  

  <form id="form_kembali_berkas">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="modal_kembali" tabindex="-1" aria-labelledby="modal_kembaliLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modal_kembaliLabel">Digitalisasi Induk</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" id="table_kembali">
    
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary" id="btn_kembali">Kirim</button>
          </div>
        </div>
      </div>
    </div>
  </form>





  <?php $__env->startSection('script'); ?>

  <script src="<?php echo e(asset('js')); ?>/qrcode.js" type="text/javascript"></script>

  <script>
    


  </script>

      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

            $('#table_berkas').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getListBerkas')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'nm_kecamatan',
                        name: 'dt_berkas.nm_kecamatan'
                    },
                    {
                        data: 'nm_kelurahan',
                        name: 'dt_berkas.nm_kelurahan'
                    },
                    {
                        data: 'nm_hak',
                        name: 'dt_berkas.nm_hak'
                    },
                    {
                        data: 'no_hak',
                        name: 'dt_berkas.no_hak'
                    },
                    {
                        data: 'nm_pemohon',
                        name: 'dt_berkas.nm_pemohon'
                    },
                    {
                        data: 'proses.nm_proses',
                        name: 'proses.nm_proses'
                    },
                    {
                        data: 'tanggal',
                        name: 'dt_berkas.tanggal'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    },
                ],
                order: [],
                columnDefs: [ 
                {
                "targets": 0,
                "orderable": false
                },
                { "searchable": false, "targets": 0 }
               ],
            });

            function reload(){
                var oTable = $('#table_berkas').dataTable(); //inialisasi datatable
                oTable.fnDraw(false); //reset datatable
            }


            $(document).on('click', '.kirim', function() {

              if (confirm("Apakah anda yakin ingin mengirim berkas??") == true) {
                var berkas_id = $(this).attr('berkas_id');
                // $('#berkas_id').val(berkas_id);
                var jenis = $(this).attr('jenis');
                var history_id = $(this).attr('history_id');
                var proses_id = $(this).attr('proses_id');
                // $('#proses_id').val(proses_id);
                
                // $('#modal_loading').modal('show');
                $.get('krimBerkas/' + jenis+'/'+history_id+'/'+berkas_id+'/'+proses_id, function (data) {
                reload();
                // $('#modal_loading').modal('hide');
                  Swal.fire({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    icon: 'success',
                    title: 'Data berhasil dikirim'
                  });

                  

                });
              }

              
              
            });

            


            $(document).on('click', '.kembali', function() {

              var berkas_id = $(this).attr('berkas_id');
              $('#table_kembali').html('<div class="spinner-border text-danger" role="status"><span class="visually-hidden">Loading...</span></div>');
              $.get('getKembali/' + berkas_id, function (data) {
                  $('#table_kembali').html(data);
              });

            });


            $(document).on('submit', '#form_kembali_berkas', function(event) {
                event.preventDefault();
                    $('#btn_kembali').attr('disabled',true);
                    $('#btn_kembali').html('Loading...');
                    $.ajax({
                        url:"<?php echo e(route('kembaliBerkas')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_kembali").removeAttr("disabled");
                                $('#btn_kembali').html('Kirim'); //tombol simpan
                                
                                $('#modal_kembali').modal('hide');

                                reload();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil dikirim'
                                });
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_kembali').html('Kirim');
                                $("#btn_kembali").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    Swal.fire({
                                      toast: true,
                                      position: 'top-end',
                                      showConfirmButton: false,
                                      timer: 3000,
                                      icon: 'error',
                                      title: 'Ada masalah'
                                    });
                                    $('#btn_kembali').html('Kirim');
                                    $("#btn_kembali").removeAttr("disabled");
                          }
                    });

            });


        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\alih media\alih-media\resources\views/berkas/list_berkas.blade.php ENDPATH**/ ?>