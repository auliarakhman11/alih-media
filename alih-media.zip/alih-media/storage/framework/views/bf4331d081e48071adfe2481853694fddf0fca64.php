<table class="table table-sm">
    <thead>
        <tr>
            <th>#</th>
            <th>Barang</th>
            <th>Sisa Stok</th>
            <th>Expired Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dt_stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($index+1); ?></td>
            <td><?php echo e($d->barang->nm_barang); ?></td>
            <td><?php echo e($d->sisa_box); ?> Box<br><?php echo e($d->sisa_pak); ?> Pak<br><?php echo e($d->sisa_kg); ?> Kg</td>
            <td><?php echo e(date("d/M/Y", strtotime($d->tgl_exp))); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table><?php /**PATH /home/u376106710/domains/cpibandung.com/aplikasilayout/resources/views/dashboard/detail_block.blade.php ENDPATH**/ ?>