<?php if($count != 0): ?>
<div class="table-responsive text-nowrap">
    <table class="table table-sm">
        <thead>
            <tr>
                <th>#</th>
                <th>Tanggal</th>
                <th>Expired Date</th>
                <th>Barang</th>
                <th>QTY Box</th>
                <th>QTY PAK</th>
                <th>QTy KG</th>
                <th>Block</th>
                <th>Cell</th>
                <th>Rak</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i=1;
            ?>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($c->options->tgl_edit); ?></td>
                <td><?php echo e($c->options->tgl_exp_edit); ?></td>
                <td><?php echo e($c->options->barang); ?></td>
                <td><?php echo e($c->options->debit_box); ?></td>
                <td><?php echo e($c->options->debit_pak); ?></td>
                <td><?php echo e($c->options->debit_kg); ?></td>
                <td><?php echo e($c->options->block); ?></td>
                <td><?php echo e($c->options->cell); ?></td>
                <td><?php echo e($c->options->rak); ?></td>
                <td><button class="btn btn-sm btn-primary btn_hapus_cart" type="button" cart_id="<?php echo e($c->rowId); ?>"><i class='bx bxs-trash-alt'></i></button></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php /**PATH D:\programming\Laravel\warehouse\resources\views/stok_masuk/get_cart.blade.php ENDPATH**/ ?>