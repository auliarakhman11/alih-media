

<?php $__env->startSection('content'); ?>
    <!-- Content -->

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
      <div class="col-lg-12 mb-4 order-0">
        <div class="card">
          <div class="d-flex align-items-end row">
            <div class="col-12">
              <div class="card-header">
                <div class="row">

                  <div class="col-md-6 col-12"><h4 class="text-primary">Penilaian Aspek Pembelajaran</h4></div>

                  <div class="col-md-6 col-12">
                    <div class="navbar-nav align-items-center">
                      <div class="nav-item d-flex align-items-center">
                        <i class="bx bx-search fs-4 lh-0"></i>
                        <input
                          type="text"
                          class="form-control border-0 shadow-none"
                          placeholder="Search..."
                          aria-label="Search..."
                          id="search_field"
                        />
                      </div>
                    </div>
                  </div>

                </div>
                
                
               
              </div>

              <div class="row" id="data_penilaian">

                
              </div>

            </div>

          </div>
        </div>
      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->


<form id="form_input_penilaian">
  <div class="modal fade" id="input_penilaian" tabindex="-1" aria-labelledby="input_penilaianLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="input_penilaianLabel">Input Penilaian <span id="nm_pegawai_input"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
  
          <input type="hidden" name="pegawai_id" id="pegawai_id">
          <input type="hidden" name="seksi_id" id="seksi_id">
  
          <?php $__currentLoopData = $pertanyaan_aspek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card mb-4 bg-primary" >
            <h5 class="card-header text-white"><?php echo e($pa->sasaran_kerja); ?></h5>
            <div class="card-body">
  
              <p class="text-white" style="text-align: justify;">
                <b><?php echo e($pa->pertanyaan); ?></b>
              </p>
  
              <div class="form-floating">
                <input type="hidden" name="pertanyaan_id[]" value="<?php echo e($pa->id); ?>">
                <input type="hidden" name="bobot[]" value="<?php echo e($pa->bobot); ?>">
                <input type="number" class="form-control" placeholder="Masukan nilai..." min="1" max="100" name="nilai[]" required>
                <label for="floatingInput">Nilai</label>
                <div class="form-text text-white">
                  Masukan nilai dari 1 - 100
                </div>
              </div>
             
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
          
  
          
          
          
  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_simpan_penilaian">Simpan</button>
        </div>
      </div>
    </div>
  </div>
</form>



<form id="form_edit_penilaian">
  <div class="modal fade" id="edit_penilaian" tabindex="-1" aria-labelledby="edit_penilaianLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="edit_penilaianLabel">Edit Penilaian <span id="nm_pegawai_edit"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="editPenilaian">
            
  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_ubah_penilaian">Edit</button>
        </div>
      </div>
    </div>
  </div>
</form>


<form id="form_input_terbaik" class="terbaik">
  <div class="modal fade" id="modal_terbaik" aria-labelledby="input_terbaikLabel" aria-hidden="true">
    <div class="modal-dialog ">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="input_terbaikLabel">Input pegawai kinerja terbaik</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            
          <div class="row">

            <div class="col-12 mb-2">

              <input type="hidden" name="id" id="terbaik_id">

              <div class="form-group">
                <label for="">Pegawai</label>
                <select name="pegawai_id" id="pegawai_id_edit" class="form-control select2bs4" required>
                  <option value="">Pilih pegawai</option>
                  <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>

            </div>
            
            

          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_input_terbaik">Save</button>
        </div>
      </div>
    </div>
  </div>
</form>


<form id="form_input_terburuk" class="terburuk">
  <div class="modal fade" id="modal_terburuk" tabindex="-1" aria-labelledby="input_terburukLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="input_terburukLabel">Input pegawai kinerja terendah</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            
          <div class="row">
            <input type="hidden" name="id" id="terburuk_id">

            <div class="col-12">
              <div class="form-group">
                <label for="">Pegawai</label>
                <select name="pegawai_id" id="pegawai_id_terburuk" class="form-control select2bs4" required>
                  <option value="">Pilih pegawai</option>
                  <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>                
            </div>

          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="btn_input_terburuk">Save</button>
        </div>
      </div>
    </div>
  </div>
</form>

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

          function getDataPenilaian(){
            $('#data_penilaian').html('<div class="col-12">"<div class="spinner-border spinner-border-lg text-primary ml-5" role="status"><span class="visually-hidden">Loading...</span></div></div>');
            $.get('get-data-penilaian', function (data) {
                      $('#data_penilaian').html(data);
                      
                  });

                  $('#search_field').val('');

                  
          }

          getDataPenilaian();


          $(document).on('click', '.btn_edit_penilaian', function() {

          var pegawai_id = $(this).attr('pegawai_id');
          var nm_pegawai = $(this).attr('nm_pegawai');

          $('#nm_pegawai_edit').html(nm_pegawai);

          $('#editPenilaian').html('<div class="col-12">"<div class="spinner-border spinner-border-lg text-primary ml-5" role="status"><span class="visually-hidden">Loading...</span></div></div>');
            $.get('get-edit-penilaian/'+pegawai_id, function (data) {
                      $('#editPenilaian').html(data);
                      
                  });

          });

          $(document).on('submit', '#form_edit_penilaian', function(event) {
                event.preventDefault();
                    $('#btn_ubah_penilaian').attr('disabled',true);
                    $('#btn_ubah_penilaian').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editPenilaian')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_ubah_penilaian").removeAttr("disabled");
                                $('#btn_ubah_penilaian').html('Edit'); //tombol simpan
                  
                                $('#edit_penilaian').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_ubah_penilaian').html('Edit');
                                $("#btn_ubah_penilaian").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_ubah_penilaian').html('Edit');
                                    $("#btn_ubah_penilaian").removeAttr("disabled");

                                    $('#edit_penilaian').modal('hide'); //modal show
                                }
                    });
          });


          $(document).on('click', '.btn_input_penilaian', function() {

            var pegawai_id = $(this).attr('pegawai_id');
            var seksi_id = $(this).attr('seksi_id');

            $('#pegawai_id').val(pegawai_id);
            $('#seksi_id').val(seksi_id);

            var nm_pegawai = $(this).attr('nm_pegawai');

          $('#nm_pegawai_input').html(nm_pegawai);

          });

          $(document).on('submit', '#form_input_penilaian', function(event) {
                event.preventDefault();
                    $('#btn_simpan_penilaian').attr('disabled',true);
                    $('#btn_simpan_penilaian').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('inputPenilaian')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_simpan_penilaian").removeAttr("disabled");
                                $('#btn_simpan_penilaian').html('Edit'); //tombol simpan
                  
                                $('#input_penilaian').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                                $('#form_input_penilaian').trigger("reset");
                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_simpan_penilaian').html('Edit');
                                $("#btn_simpan_penilaian").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_simpan_penilaian').html('Edit');
                                    $("#btn_simpan_penilaian").removeAttr("disabled");

                                    $('#input_penilaian').modal('hide'); //modal show
                                }
                    });
          });


          var btsearch = {
          init: function(search_field, searchable_elements, searchable_text_class) {
            $(search_field).keyup(function(e) {
              e.preventDefault();
              var query = $(this).val().toLowerCase();
              if (query) {
                // loop through all elements to find match
                $.each($(searchable_elements), function() {
                  var title = $(this).find(searchable_text_class).text().toLowerCase();
                  if (title.indexOf(query) == -1) {
                    $(this).hide();
                  } else {
                    $(this).show();
                  }
                });
                
              } else {
                // empty query so show everything
                $(searchable_elements).show();
                
              }
            });
          }
        }

        // INIT
        $(function() {

          btsearch.init('#search_field', '#data_penilaian div', '.demoname');
          
        });


         //terbaik
         $(document).on('click', '.btn_input_terbaik', function() {
            $('.terbaik').attr('id','form_input_terbaik');
            $('#input_terbaikLabel').html('Input pegawai terbaik');
            
          });

          $(document).on('click', '.btn_edit_terbaik', function() {
            $('.terbaik').attr('id','form_edit_terbaik');

            $('#input_terbaikLabel').html('Edit pegawai terbaik');

            var terbaik_id = $(this).attr('terbaik_id');

            $.get('get-data-terbaik/'+terbaik_id, function (data) {
                        
                $('#terbaik_id').val(data.id);
                $('#nilai_terbaik').val(data.nilai);
                $('#pegawai_id_edit').val(data.pegawai_id);
                

                $("#pegawai_id_edit").select2({
                    dropdownParent: $('#modal_terbaik .modal-content'),
                    theme: 'bootstrap4',
                    tags: true,
                }).trigger('change');
                        
              });

          });

          $(document).on('submit', '#form_input_terbaik', function(event) {
                event.preventDefault();
                    $('#btn_input_terbaik').attr('disabled',true);
                    $('#btn_input_terbaik').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addTerbaik')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terbaik").removeAttr("disabled");
                                $('#btn_input_terbaik').html('Edit'); //tombol simpan
                  
                                $('#modal_terbaik').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terbaik').html('Edit');
                                $("#btn_input_terbaik").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terbaik').html('Edit');
                                    $("#btn_input_terbaik").removeAttr("disabled");

                                    $('#modal_terbaik').modal('hide'); //modal show
                                }
                    });
          });


          $(document).on('submit', '#form_edit_terbaik', function(event) {
                event.preventDefault();
                    $('#btn_input_terbaik').attr('disabled',true);
                    $('#btn_input_terbaik').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editTerbaik')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terbaik").removeAttr("disabled");
                                $('#btn_input_terbaik').html('Edit'); //tombol simpan
                  
                                $('#modal_terbaik').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terbaik').html('Edit');
                                $("#btn_input_terbaik").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terbaik').html('Edit');
                                    $("#btn_input_terbaik").removeAttr("disabled");

                                    $('#modal_terbaik').modal('hide'); //modal show
                                }
                    });
          });

          $("#pegawai_id_edit").select2({
              dropdownParent: $('#modal_terbaik .modal-content'),
              theme: 'bootstrap4',
              tags: true,
          });

          //endterbaik

          //terburuk

          $(document).on('click', '.btn_input_terburuk', function() {
            $('.terburuk').attr('id','form_input_terburuk');
            $('#input_terburukLabel').html('Input pegawai terburuk');
            
          });

          $(document).on('click', '.btn_edit_terburuk', function() {
            $('.terburuk').attr('id','form_edit_terburuk');

            $('#input_terburukLabel').html('Edit pegawai terburuk');

            var terburuk_id = $(this).attr('terburuk_id');

            $.get('get-data-terburuk/'+terburuk_id, function (data) {
                        
                $('#terburuk_id').val(data.id);
                $('#pegawai_id_terburuk').val(data.pegawai_id);
                

                $("#pegawai_id_terburuk").select2({
                    dropdownParent: $('#modal_terburuk .modal-content'),
                    theme: 'bootstrap4',
                    tags: true,
                }).trigger('change');
                        
              });

          });


          $(document).on('submit', '#form_input_terburuk', function(event) {
                event.preventDefault();
                    $('#btn_input_terburuk').attr('disabled',true);
                    $('#btn_input_terburuk').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addTerburuk')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terburuk").removeAttr("disabled");
                                $('#btn_input_terburuk').html('Edit'); //tombol simpan
                  
                                $('#modal_terburuk').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terburuk').html('Edit');
                                $("#btn_input_terburuk").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terburuk').html('Edit');
                                    $("#btn_input_terburuk").removeAttr("disabled");

                                    $('#modal_terburuk').modal('hide'); //modal show
                                }
                    });
          });


          $(document).on('submit', '#form_edit_terburuk', function(event) {
                event.preventDefault();
                    $('#btn_input_terburuk').attr('disabled',true);
                    $('#btn_input_terburuk').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editTerburuk')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_input_terburuk").removeAttr("disabled");
                                $('#btn_input_terburuk').html('Edit'); //tombol simpan
                  
                                $('#modal_terburuk').modal('hide'); //modal show

                                getDataPenilaian();

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diedit'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_input_terburuk').html('Edit');
                                $("#btn_input_terburuk").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_input_terburuk').html('Edit');
                                    $("#btn_input_terburuk").removeAttr("disabled");

                                    $('#modal_terburuk').modal('hide'); //modal show
                                }
                    });
          });


          $("#pegawai_id_terburuk").select2({
              dropdownParent: $('#modal_terburuk .modal-content'),
              theme: 'bootstrap4',
              tags: true,
          });
          //endterbaik

        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/penilaian/index.blade.php ENDPATH**/ ?>