<style>
    .scrollme {
    overflow-y: auto;
    height: 600px;
    }

    th {
    position: sticky;
    top: 0px;  /* 0px if you don't have a navbar, but something is required */
    background: white;
    }
</style>
<div class="table-responsive scrollme">
    <table class="table table-sm">
        <thead>
            <tr>
                <th class="bg-white">#</th>
                <th class="bg-white">Kecamatan</th>
                <th class="bg-white">Kelurahan</th>
                <th class="bg-white">Hak</th>
                <th class="bg-white">SU/GS</th>
                <th class="bg-white">NIB</th>
                <th class="bg-white">Tanggal</th>
                <th class="bg-white">Keterangan</th>
                <th class="bg-white">Petugas</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i = 1;
            ?>
            <?php $__currentLoopData = $dt_berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($d->berkas->kecamatan->nm_kecamatan); ?></td>
                    <td><?php echo e($d->berkas->kelurahan->nm_kelurahan); ?></td>
                    <td><?php echo e($d->berkas->jenis_hak->kode_hak); ?>-<?php echo e($d->berkas->no_hak); ?></td>
                    <td><?php echo e($d->berkas->jenis_peta ? $d->berkas->jenis_peta->nm_jenis_peta : ''); ?>-<?php echo e($d->berkas->no_peta); ?>-<?php echo e($d->berkas->tahun_peta); ?></td>
                    <td><?php echo e($d->berkas->nib); ?></td>
                    <td><?php echo e(date("d/m/Y", strtotime($d->berkas->created_at))); ?></td>
                    <td><?php echo e($d->ket); ?></td>
                    <td><?php echo e($d->petugas ? $d->petugas->name : ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>      
    </table>
</div><?php /**PATH /home/u1721841/alih-media/resources/views/laporan/dt_info_perproses.blade.php ENDPATH**/ ?>