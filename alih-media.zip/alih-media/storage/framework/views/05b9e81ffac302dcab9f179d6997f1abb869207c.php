<div class="col-md-4 col-12">
    <div class="card text-start mb-3">
        <div class="card-body">
          <h5 class="card-title"><u>Penilaian Rekan Kerja</u></h5>
          <h5 class="card-title"><?php echo e($data_penilaian->pegawai->nama); ?></h5>
          <p class="card-text"><?php echo e($data_penilaian->pegawai->jabatan); ?></p>
            
            <?php if($data_penilaian->nilai == 0): ?>
            <button type="button" class="btn btn-primary float-end btn_edit_penilaian" data-bs-toggle="modal" data-bs-target="#edit_penilaian" pegawai_id="<?php echo e($data_penilaian->pegawai_id); ?>">
                <i class='bx bxs-right-arrow-circle'></i> Input
            </button>
            <?php else: ?>
            <button type="button" class="btn btn-success float-end btn_edit_penilaian" data-bs-toggle="modal" data-bs-target="#edit_penilaian" pegawai_id="<?php echo e($data_penilaian->pegawai_id); ?>">
                <i class='bx bxs-right-arrow-circle'></i> Lihat
            </button>
            <?php endif; ?>
            
            
            
            
          
          
        </div>
    </div>
</div>

<div class="col-md-4 col-12">
    <div class="card text-start mb-3">
        <div class="card-body">
          <h5 class="card-title"><u>Pegawai Kinerja Terbaik</u></h5>
            
          <?php if($data_pegawai_terbaik): ?>
          <h5 class="card-title"><?php echo e($data_pegawai_terbaik->pegawai->nama); ?></h5>
          <p class="card-text"><?php echo e($data_pegawai_terbaik->pegawai->jabatan); ?></p>
          <button type="button" class="btn btn-success float-end btn_edit_terbaik" data-bs-toggle="modal" data-bs-target="#modal_terbaik" terbaik_id="<?php echo e($data_pegawai_terbaik->id); ?>">
            <i class='bx bxs-right-arrow-circle'></i> Lihat
          </button>
          <?php else: ?>
          <h5 class="card-title">-</h5>
          <p class="card-text">-</p>
          <button type="button" class="btn btn-primary float-end btn_input_terbaik" data-bs-toggle="modal" data-bs-target="#modal_terbaik">
            <i class='bx bxs-right-arrow-circle'></i> Input
          </button>
          <?php endif; ?>  
          
          
        </div>
    </div>
</div>

<div class="col-md-4 col-12">
    <div class="card text-start mb-3">
        <div class="card-body">
          <h5 class="card-title"><u>Pegawai Kinerja Terendah</u></h5>
          
            
          <?php if($data_pegawai_terburuk): ?>
          <h5 class="card-title"><?php echo e($data_pegawai_terburuk->pegawai->nama); ?></h5>
          <p class="card-text"><?php echo e($data_pegawai_terburuk->pegawai->jabatan); ?></p>
          <button type="button" class="btn btn-success float-end btn_edit_terburuk" data-bs-toggle="modal" data-bs-target="#modal_terburuk" terburuk_id="<?php echo e($data_pegawai_terburuk->id); ?>">
            <i class='bx bxs-right-arrow-circle'></i> Lihat
          </button>
          <?php else: ?>
          <h5 class="card-title">-</h5>
          <p class="card-text">-</p>
          <button type="button" class="btn btn-primary float-end btn_input_terburuk" data-bs-toggle="modal" data-bs-target="#modal_terburuk">
            <i class='bx bxs-right-arrow-circle'></i> Input
          </button>
          <?php endif; ?>
            
        </div>
    </div>
</div><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/penilaian_pegawai/data_penilaian.blade.php ENDPATH**/ ?>