

<?php $__env->startSection('content'); ?>
    <!-- Content -->



<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

      <div class="col-12 mb-4 order-0">
        
        <div class="card">
            <div class="card-header">
                <h5 class="float-start">Data PPNPN</h5>
                <button type="button" class="btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#modal_add_pegawai"><i class='bx bxs-plus-circle'></i> Tambah Data</button>
            </div>
            
            <div class="table-responsive text-nowrap">
              <table class="table" id="table_pegawai">
                <thead>
                  <tr>
                    <th>Nama</th>
                    <th>Jabatan</th>
                    <th>Seksi</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody class="table-border-bottom-0">                  
                 
                </tbody>
              </table>
            </div>
          </div>

      </div>

      <!-- Total Revenue -->

      <!--/ Total Revenue -->
      
    </div>

  </div>
  <!-- / Content -->

  <!-- Modal -->

  
  <form id="form_edit_pegawai">
    <div class="modal fade" id="modal_edit_pegawai" tabindex="-1" aria-labelledby="modal_edit_pegawaiLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modal_edit_pegawaiLabel">Edit data</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <input type="hidden" name="id" id="pegawai_id">
                <input type="hidden" name="user_id" id="user_id">
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" class="form-control" name="nama" id="nama" required>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">NRP</label>
                        <input type="text" class="form-control" name="nip" id="nip" required>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Jabatan</label>
                        <input type="text" class="form-control" name="jabatan" id="jabatan" required>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Seksi</label>
                        <select name="seksi_id" id="seksi_id" class="form-control" required>
                            <?php $__currentLoopData = $seksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nm_seksi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        </select>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Atasan Langsung</label>
                        <select name="atasan" id="atasan" class="form-control" required>
                            <?php $__currentLoopData = $kasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        </select>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Rekan Kerja</label>
                        <select name="rekan_kerja" id="rekan_kerja" class="form-control" required>
                            <?php $__currentLoopData = $korsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        </select>
                    </div>
                </div>

                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Aktif</label>
                        <select name="aktif" id="aktif" class="form-control" required>
                            
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                                                    
                        </select>
                    </div>
                </div>
    
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary" id="btn_save_pegawai">Save</button>
            </div>
          </div>
        </div>
      </div>
  </form>


  <form id="form_add_pegawai">
    <div class="modal fade" id="modal_add_pegawai" tabindex="-1" aria-labelledby="modal_add_pegawaiLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modal_add_pegawaiLabel">Tambah data PPNPN</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" class="form-control" name="nama" id="nama_add" required>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">NRP</label>
                        <input type="text" class="form-control" name="nip" id="nip_add" required>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Jabatan</label>
                        <input type="text" class="form-control" name="jabatan" id="jabatan_add" required>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Seksi</label>
                        <select name="seksi_id" id="seksi_id_add" class="form-control" required>
                            <option value="">Pilih</option>
                            <?php $__currentLoopData = $seksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nm_seksi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        </select>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Atasan Langsung</label>
                        <select name="atasan" id="atasan_add" class="form-control" required>
                            <option value="">Pilih</option>
                            <?php $__currentLoopData = $kasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        </select>
                    </div>
                </div>
    
                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Rekan Kerja</label>
                        <select name="rekan_kerja" id="rekan_kerja_add" class="form-control" required>
                            <option value="">Pilih</option>
                            <?php $__currentLoopData = $korsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        </select>
                    </div>
                </div>

                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" class="form-control" name="username"  required>
                    </div>
                </div>

                <div class="col-md-6 col-12">
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" class="form-control" name="password"  required>
                    </div>
                </div>
    
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary" id="btn_add_pegawai">Save</button>
            </div>
          </div>
        </div>
      </div>
  </form>

  

  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

            $('#table_pegawai').DataTable({
                processing: true,
                serverSide: true, //aktifkan server-side 
                ajax: {
                    url: "<?php echo e(route('getPegawai')); ?>",
                    type: 'GET'
                },
                columns: [
                    {
                        data: 'nama',
                        name: 'pegawai.nama'
                    },
                    {
                        data: 'jabatan',
                        name: 'pegawai.jabatan'
                    },
                    {
                        data: 'seksi.nm_seksi',
                        name: 'seksi.nm_seksi'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    },
                    
                ],
                order: [],
            });


            $(document).on('click', '.edit_pegawai', function() {

                var pegawai_id = $(this).attr('pegawai_id');

                $.get('get-data-pegawai/'+pegawai_id, function (data) {
                    $('#pegawai_id').val(data.id);
                    $('#nama').val(data.nama);
                    $('#nip').val(data.user.nip);
                    $('#jabatan').val(data.jabatan);
                    $('#seksi_id').val(data.seksi_id);
                    $('#atasan').val(data.atasan);
                    $('#rekan_kerja').val(data.rekan_kerja);
                    $('#user_id').val(data.user_id);
                    $('#aktif').val(data.user.aktif);
                      
                  });

                

            });

            function getPegawai(){
            var pTable = $('#table_pegawai').dataTable(); //inialisasi datatable
            pTable.fnDraw(false); //reset datatable
            }

            $(document).on('submit', '#form_edit_pegawai', function(event) {
                event.preventDefault();
                    $('#btn_save_pegawai').attr('disabled',true);
                    $('#btn_save_pegawai').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('editPegawai')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_save_pegawai").removeAttr("disabled");
                                $('#btn_save_pegawai').html('Edit'); //tombol simpan
                  
                                $('#modal_edit_pegawai').modal('hide'); //modal show

                                getPegawai();

                                $('#form_edit_pegawai').trigger("reset");

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Ada masalah'
                                });
                                $('#btn_save_pegawai').html('Edit');
                                $("#btn_save_pegawai").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_save_pegawai').html('Edit');
                                    $("#btn_save_pegawai").removeAttr("disabled");

                                    $('#modal_edit_pegawai').modal('hide'); //modal show
                                }
                    });
          });


          $(document).on('submit', '#form_add_pegawai', function(event) {
                event.preventDefault();
                    $('#btn_add_pegawai').attr('disabled',true);
                    $('#btn_add_pegawai').html('Loading <div class="ld"><div></div><div></div><div></div></div>');
                    $.ajax({
                        url:"<?php echo e(route('addPegawai')); ?>",
                        method: 'POST',
                        data: new FormData(this),
                        contentType: false,
                        processData: false,
                        success: function(data) {

                            if(data){
                                $("#btn_add_pegawai").removeAttr("disabled");
                                $('#btn_add_pegawai').html('add'); //tombol simpan
                  
                                $('#modal_add_pegawai').modal('hide'); //modal show

                                getPegawai();

                                $('#form_add_pegawai').trigger("reset");

                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'success',
                                title: 'Data berhasil diinput'
                                });

                            }else{
                                Swal.fire({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                icon: 'error',
                                title: 'Username sudah digunakan PPNPN lain'
                                });
                                $('#btn_add_pegawai').html('add');
                                $("#btn_add_pegawai").removeAttr("disabled");
                            }   
                            
                        },
                        error: function (data) { //jika error tampilkan error pada console
                                    console.log('Error:', data);
                                    $('#btn_add_pegawai').html('add');
                                    $("#btn_add_pegawai").removeAttr("disabled");

                                    $('#modal_add_pegawai').modal('hide'); //modal show
                                }
                    });
          });


        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/administrator/pegawai.blade.php ENDPATH**/ ?>