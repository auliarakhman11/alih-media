<?php $__currentLoopData = $dt_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card mb-4 bg-primary" >
            <h5 class="card-header text-white"><?php echo e($dp->pertanyaanAspek->sasaran_kerja); ?></h5>
            <div class="card-body">
  
              <p class="text-white" style="text-align: justify;">
                <b><?php echo e($dp->pertanyaanAspek->pertanyaan); ?></b>
              </p>
  
              <div class="form-floating">
                <input type="hidden" name="id[]" value="<?php echo e($dp->id); ?>">
                <input type="hidden" name="bobot[]" value="<?php echo e($dp->bobot); ?>">
                <input type="hidden" name="total_nilai[]" value="<?php echo e($dp->total_nilai); ?>">
                <input type="hidden" name="nilai_old[]" value="<?php echo e($dp->nilai); ?>">
                <input type="number" class="form-control" placeholder="Masukan nilai..." min="1" max="100" name="nilai[]" value="<?php echo e($dp->nilai == 0 ? '' : $dp->nilai); ?>" required>
                <label for="floatingInput">Nilai</label>
                <div class="form-text text-white">
                  Masukan nilai dari 1 - 100
                </div>
              </div>
             
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/penilaian/data_edit.blade.php ENDPATH**/ ?>