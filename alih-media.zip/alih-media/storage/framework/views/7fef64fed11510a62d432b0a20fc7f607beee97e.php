
<table class="table table-sm table-striped">
    <input type="hidden" name="id" value="<?php echo e($id); ?>">
    <input type="hidden" name="id_pegawai" value="<?php echo e($id_pegawai); ?>">
    <input type="hidden" name="tunjangan" value="<?php echo e($tunjangan); ?>">
    <thead>
        <tr>
            <th class="sticky-top th-atas">Tanggal</th>
            <th class="sticky-top th-atas">Jam Masuk</th>
            <th class="sticky-top th-atas">Jam Keluar</th>
            <th class="sticky-top th-atas">Scan Masuk</th>
            <th class="sticky-top th-atas">Scan Keluar</th>
            <th class="sticky-top th-atas">Keterangan</th>
        </tr>
    </thead>
    <tbody>
        <?php
                $iterasi = 0;
            ?>
        <?php for($i=1; $i <= $last_day; $i++): ?>
      <?php
          $tanggal = date("Y-m-d", strtotime($bulan_tahun.$i));
      ?>
        <?php if(date('N', strtotime($tanggal)) >= 6): ?>
                <tr>
                  <td><?php echo e(date("d/M/Y", strtotime($tanggal))); ?></td>
                  <td>08:30</td>
                  <td>16:30</td>
                  <?php if(date('N', strtotime($tanggal)) == 6): ?>
                  <td><center>SABTU</center></td>
                  <td><center>SABTU</center></td>
                  <?php else: ?>
                  <td><center>MINGGU</center></td>
                  <td><center>MINGGU</center></td>
                  <?php endif; ?>
                  <td></td>
                </tr>                  
        <?php else: ?>
            
            <?php $__currentLoopData = $dt_absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($da->tgl == $tanggal): ?>
                    <?php if($da->luar_kota): ?>
                    <tr>
                        <td><?php echo e(date("d/M/Y", strtotime($tanggal))); ?></td>
                        <td><?php echo e(date('H:i', strtotime($da->jam_masuk))); ?></td>
                        <td><?php echo e(date('H:i', strtotime($da->jam_pulang))); ?></td>
                        <td><center>DINAS</center></td>
                        <td><center>LUAR</center></td>
                        <td></td>
                    </tr>
                    <?php else: ?>
                    <input type="hidden" name="detail_id[]" value="<?php echo e($da->id); ?>">
                    <input type="hidden" name="tgl[]" value="<?php echo e($da->tgl); ?>">
                    <input type="hidden" name="jam_masuk[]" value="<?php echo e($da->jam_masuk); ?>">
                    <input type="hidden" name="jam_pulang[]" value="<?php echo e($da->jam_pulang); ?>">
                    <tr>
                        <td class="align-middle"><?php echo e(date("d/M/Y", strtotime($tanggal))); ?></td>
                        <td class="align-middle"><?php echo e(date('H:i', strtotime($da->jam_masuk))); ?></td>
                        <td class="align-middle"><?php echo e(date('H:i', strtotime($da->jam_pulang))); ?></td>
                        <td class="align-middle"><input type="time" name="scan_masuk[]" class="form-control form-control-sm <?php echo e((!$da->scan_masuk || $da->scan_masuk > $da->jam_masuk) && (!$da->ket && !$da->luar_kota) && (!$da->sakit && !$da->cuti && !$da->izin && !$da->diklat) ? 'is-invalid' : ''); ?>" value="<?php echo e($da->scan_masuk); ?>"></td>
                        <td class="align-middle"><input type="time" name="scan_pulang[]" class="form-control form-control-sm <?php echo e((!$da->scan_pulang || $da->scan_pulang < $da->jam_pulang) && (!$da->ket && !$da->luar_kota) && (!$da->sakit && !$da->cuti && !$da->izin && !$da->diklat) ? 'is-invalid' : ''); ?>" value="<?php echo e($da->scan_pulang); ?>"></td>
                        <td class="align-middle"><label for=""> <input type="radio" name="alasan[<?php echo e($iterasi); ?>]" value="sakit" <?php echo e($da->sakit ? 'checked' : ''); ?>> Sakit</label> <label for=""> <input name="alasan[<?php echo e($iterasi); ?>]" value="izin" type="radio" <?php echo e($da->izin ? 'checked' : ''); ?>> Izin</label> <label for=""> <input name="alasan[<?php echo e($iterasi); ?>]" value="cuti" type="radio" <?php echo e($da->cuti ? 'checked' : ''); ?>> Cuti</label> <label for=""> <input name="alasan[<?php echo e($iterasi); ?>]" value="diklat" type="radio" <?php echo e($da->diklat ? 'checked' : ''); ?>> Diklat</label> <br>
                            <input type="text" name="ket[]" class="form-control form-control-sm" value="<?php echo e($da->ket); ?>"></td>
                    </tr>
                    <?php
                        $iterasi ++;
                    ?>
                    <?php endif; ?>
                         
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
            
        <?php endfor; ?>
    </tbody>
</table><?php /**PATH D:\programming\Laravel\surat-keuar\resources\views/tukin/detail1.blade.php ENDPATH**/ ?>