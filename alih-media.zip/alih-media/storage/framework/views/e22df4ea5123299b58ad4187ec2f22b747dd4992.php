<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checker Stok Keluar</title>

    <style>
        
        table, th, td, th {
        border: 1px solid black;
        border-collapse: collapse;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="container">
        <img class="float-start" width="50 px;" src="<?php echo e(asset('img')); ?>/cp.jpeg">
        <center><h4 style="margin-top: -50px;">PT. CHAROEN POKPHAND INDONESIA</h4></center><br>
        <center><h4 style="margin-top: -40px;">PLANT BANDUNG</h4></center>

        <hr style="border-top: 1px;">
    </div>

    <div class="container">
        <table style="border: none !important;">
            <tbody>
                <tr>
                    <td style="border: none !important;" width="100px;">Tanggal</td>
                    <td style="border: none !important;">:</td>
                    <td style="border: none !important;"><?php echo e($stok ? date("d-m-Y", strtotime($stok[0]->tgl)) : ''); ?></td>
                </tr>
                <tr>
                    <td style="border: none !important;" width="100px;">Jam Muat</td>
                    <td style="border: none !important;">:</td>
                    <td style="border: none !important;"><?php echo e($stok ? date("H:i", strtotime($stok[0]->created_at)) : ''); ?></td>
                </tr>
                <tr>
                    <td style="border: none !important;" width="100px;">Warehouse</td>
                    <td style="border: none !important;">:</td>
                    <td style="border: none !important;">CR01</td>
                </tr>
                <tr>
                    <td style="border: none !important;" width="100px;">Tujuan</td>
                    <td style="border: none !important;">:</td>
                    <td style="border: none !important;"><?php echo e($stok ? $stok[0]->mitra->nm_mitra : ''); ?></td>
                </tr>
                <tr>
                    <td style="border: none !important;" width="100px;">Checker</td>
                    <td style="border: none !important;">:</td>
                    <td style="border: none !important;"></td>
                </tr>
            </tbody>
        </table>

        <center><h5>FORM CHECKER BARANG KELUAR</h5></center>
    </div>
    

    <div class="container">
        <table class="table table-sm table-bordered" style="font-size: 12px;" width="100%">
            <thead style="text-align: center;">
                <tr>
                    <th>Nama Barang</th>
                    <th>Batch</th>
                    <th>Kode Barang</th>
                    <th>Tanggal Kadaluarsa</th>
                    <th>QTY</th>
                    <th>Lokasi</th>
                    <th width="20%">Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($d->barang->nm_barang); ?></td>
                        <td><?php echo e($d->kd_gabungan); ?></td>
                        <td><?php echo e($d->barang->kode_barang); ?></td>
                        <td><?php echo e(date("d/m/Y", strtotime($d->tgl_exp))); ?></td>
                        <td style="text-align: center;"><?php echo e($d->kredit_box); ?> Box<br><?php echo e($d->kredit_pak); ?> Pack<br><?php echo e($d->kredit_kg); ?> Kg</td>
                        <td style="text-align: center;"><?php echo e($d->block->nm_block); ?> <br><?php echo e($d->cell->nm_cell); ?> <br><?php echo e($d->rak->nm_rak); ?> <br><?php echo e($d->pallet->nm_pallet); ?></td>
                        <td></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>
    


</body>
</html><?php /**PATH /home/u376106710/domains/cpibandung.com/aplikasilayout/resources/views/stok_keluar/pdf_detail_keluar.blade.php ENDPATH**/ ?>