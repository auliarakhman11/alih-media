<?php if($count != 0): ?>

<form id="form_save_return_barang">

    <div class="card">
        <div class="card-header">
            <h5 class="float-start">Batch Return Barang</h5>
            
        </div>
        <div class="card-body">
    
            <div class="row mb-3">
    
                <div class="col-4">
                    <div class="form-group">
                      <label for="">Tanggal</label>
                      <input type="date" name="tgl" class="form-control" required>
                    </div>
                </div>
            
                <div class="col-4">
                    <div class="form-group">
                      <label for="">Shift</label>
                      <select name="shift_id" class="form-control" required>
                        <option value="">Pilih Shift</option>
                        <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nm_shift); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>

                <div class="col-4">
                    <div class="form-group">
                      <label for="">Mitra</label>
                      <select name="mitra_id" class="form-control" required>
                        <option value="">Pilih mitra</option>
                        <?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"><?php echo e($m->nm_mitra); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>
            
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Expired Date</th>
                            <th>Barang</th>
                            <th>QTY</th>
                            <th>Lokasi</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i=1;
                        ?>
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($c->options->tgl_exp_edit); ?></td>
                            <td><?php echo e($c->options->barang); ?></td>
                            <td><?php echo e($c->options->debit_box); ?> Box<br><?php echo e($c->options->debit_pak); ?> Pak<br><?php echo e($c->options->debit_kg); ?></td>
                            <td><?php echo e($c->options->block); ?><br><?php echo e($c->options->cell); ?><br><?php echo e($c->options->rak); ?><br><?php echo e($c->options->pallet); ?></td>
                            <td><button class="btn btn-sm btn-primary btn_hapus_cart" type="button" cart_id="<?php echo e($c->rowId); ?>"><i class='bx bxs-trash-alt'></i></button></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                    </tbody>
                </table>
            </div>
    
        </div>
        <div class="card-footer">
          <button type="submit" id="btn_input_data" class="btn btn-sm btn-primary float-end"><i class="bx bxs-save"></i> Input Stok</button>
        </div>
      </div>

</form>




<?php endif; ?>

<?php /**PATH D:\programming\Laravel\aplikasilayout\resources\views/dashboard/get_cart.blade.php ENDPATH**/ ?>