                
                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$p->jml_input): ?>
                <div class="col-md-4 col-12">
                  <div class="card text-start mb-3">
                      <div class="card-body">
                        <h5 class="card-title demoname"><?php echo e($p->nama); ?></h5>
                        <p class="card-text"><?php echo e($p->jabatan); ?></p>
                                                      <button type="button" class="btn btn-primary float-end btn_input_penilaian" data-bs-toggle="modal" data-bs-target="#input_penilaian" pegawai_id="<?php echo e($p->id); ?>" seksi_id="<?php echo e($p->seksi_id); ?>" nm_pegawai="<?php echo e($p->nama); ?>">
                            <i class='bx bxs-right-arrow-circle'></i> Input
                          </button>
                      </div>
                  </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-4 col-12">
                  <div class="card text-start mb-3 shadow-none bg-transparent border border-primary">
                      <div class="card-body">
                        <h5 class="card-title"><u>Pegawai Kinerja Terbaik (Boleh dari seksi mana saja)</u></h5>
                          
                        <?php if($data_pegawai_terbaik): ?>
                        <h5 class="card-title"><?php echo e($data_pegawai_terbaik->pegawai->nama); ?></h5>
                        <p class="card-text"><?php echo e($data_pegawai_terbaik->pegawai->jabatan); ?></p>
                        <button type="button" class="btn btn-success float-end btn_edit_terbaik" data-bs-toggle="modal" data-bs-target="#modal_terbaik" terbaik_id="<?php echo e($data_pegawai_terbaik->id); ?>">
                          <i class='bx bxs-right-arrow-circle'></i> Lihat
                        </button>
                        <?php else: ?>
                        <h5 class="card-title">-</h5>
                        <p class="card-text">-</p>
                        <button type="button" class="btn btn-primary float-end btn_input_terbaik" data-bs-toggle="modal" data-bs-target="#modal_terbaik">
                          <i class='bx bxs-right-arrow-circle'></i> Input
                        </button>
                        <?php endif; ?>  
                        
                        
                      </div>
                  </div>
                </div>
                
                

                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($p->jml_input): ?>
                <div class="col-md-4 col-12">
                    <div class="card text-start mb-3">
                        <div class="card-body">
                          <h5 class="card-title demoname"><?php echo e($p->nama); ?></h5>
                          <p class="card-text"><?php echo e($p->jabatan); ?></p>
                            
                            <button type="button" class="btn btn-success float-end btn_edit_penilaian" data-bs-toggle="modal" data-bs-target="#edit_penilaian" pegawai_id="<?php echo e($p->id); ?>" seksi_id="<?php echo e($p->seksi_id); ?>" nm_pegawai="<?php echo e($p->nama); ?>">
                                <i class='bx bxs-right-arrow-circle'></i> Lihat
                              </button>
                        </div>
                    </div>
                </div>
                <?php endif; ?>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php /**PATH D:\programming\Laravel\penilaian-kinerja\resources\views/penilaian/data_penilaian.blade.php ENDPATH**/ ?>