<div class="row">
    <div class="col-6">
        <div class="form-group">
            <label for="">Proses</label>
            <p><b><?php echo e($proses->nm_proses); ?></b></p>
        </div>
    </div>
    <?php if($user): ?>
    <div class="col-6">
        <div class="form-group">
            <label for="">Petugas</label>
            <select name="user_id" class="form-control" required>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php endif; ?>
    
</div><?php /**PATH D:\programming\alih media\alih-media\resources\views/berkas/get_kirim.blade.php ENDPATH**/ ?>