<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row justify-content-center">

            <div class="col-12">
                <div class="card">
                  
                    <div class="card-header">
                        <h4 class="float-left">Import Data</h4>
                        
                    </div>
                    <div class="card-body">

                        <div class="row">
                            <div class="col-4">
                                <form action="<?php echo e(route('importDataPegawai')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="">Pegawai</label>
                                        <input type="file" class="form-control" name="pegawai" required>
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary">Import</button>
                                </form>
                            </div>

                            <div class="col-4">
                              <form action="<?php echo e(route('importSuratKeluar')); ?>" method="post" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                  <div class="form-group">
                                      <label for="">Surat Keluar</label>
                                      <input type="file" class="form-control" name="surat" required>
                                  </div>
                                  <button type="submit" class="btn btn-sm btn-primary">Import</button>
                              </form>
                          </div>

                          <div class="col-4">
                            <form action="<?php echo e(route('importSuratTugas')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="">Surat Tugas11</label>
                                    <input type="file" class="form-control" name="surat_tugas" required>
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary">Import</button>
                            </form>
                        </div>

                        </div>
                        
                    </div>
                </div>
            </div>


        </div>
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

          

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

  $(document).ready(function() {
    
    
    
  });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rahman/DATA D1/Programming/laravel/surat-keuar/resources/views/import/index.blade.php ENDPATH**/ ?>