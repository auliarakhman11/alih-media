

<?php $__env->startSection('content'); ?>


<!-- Content -->



<div class="container-xxl flex-grow-1 container-p-y">
  <div class="row">

    <div class="col-12 mb-4 order-0">

        <div class="card">
          <div class="card-header">
            <form action="" method="get">
              <div class="row">

                <div class="col-12 col-md-5">
                  <h5 class="float-start">Laporan Stok Keluar</h5>
                </div>
                <div class="col-5 col-md-3">
                    <div class="form-group">
                        <label for="">Dari</label>
                        <input type="date" class="form-control" value="<?php echo e($tgl1); ?>" name="tgl1" required>
                    </div>
                </div>
                <div class="col-5 col-md-3">
                    <div class="form-group">
                        <label for="">Sampai</label>
                        <input type="date" class="form-control" value="<?php echo e($tgl2); ?>" name="tgl2" required>
                    </div>
                </div>
  
                <div class="col-2 col-md-1">
                  <button class="btn btn-sm btn-primary mt-4" type="submit"><i class='bx bx-search-alt'></i></button>
                </div>
  
              </div>
            </form>              
              
          </div>
          <div class="card-body">

            <div class="table-responsive text-nowrap">
                <table class="table" id="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Batch</th>
                            <th>Tanggal</th>
                            <th>Mitra</th>
                            <th>Shift</th>
                            <th>Admin</th>
                            <th>Checker</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($index+1); ?></td>
                            <td><?php echo e($s->kd_gabungan); ?></td>
                            <td><?php echo e(date("d/M/Y", strtotime($s->tgl))); ?></td>
                            <td><?php echo e($s->mitra->nm_mitra); ?></td>
                            <td><?php echo e($s->shift->nm_shift); ?></td>
                            <td><?php echo e($s->user->name); ?></td>
                            <td><?php echo e($s->userChecker->name); ?></td>
                            <td><a href="<?php echo e(route('pdfStokKeluar',$s->kd_gabungan)); ?>" target="_blank" class="btn btn-primary btn-sm"><i class='bx bxs-file-pdf'></i></a></td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

          </div>
        </div>


    </div>

    <!-- Total Revenue -->

    <!--/ Total Revenue -->
    
  </div>

</div>
<!-- / Content -->

    

  <!-- Modal -->







  <?php $__env->startSection('script'); ?>
      <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {

            <?php if(session('success')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: '<?= session('success'); ?>'
            });            
            <?php endif; ?>

            <?php if(session('error')): ?>
            Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: '<?= session('error'); ?>'
            });            
            <?php endif; ?>

            


        });

        

      </script>
  <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\Laravel\aplikasilayout\resources\views/laporan/stok_keluar.blade.php ENDPATH**/ ?>